﻿using Microsoft.AspNetCore.Mvc;
using DataGap.Jellog.AspNetCore.Mvc;

namespace MyCompanyName.MyProjectName.Blazor.Server.Tiered.Components.Toolbar.LoginLink;

public class LoginLinkViewComponent : JellogViewComponent
{
    public virtual IViewComponentResult Invoke()
    {
        return View("~/Components/Toolbar/LoginLink/Default.cshtml");
    }
}
