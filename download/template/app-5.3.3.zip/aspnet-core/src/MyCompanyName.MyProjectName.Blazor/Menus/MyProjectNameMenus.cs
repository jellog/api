﻿namespace MyCompanyName.MyProjectName.Blazor.Menus;

public class MyProjectNameMenus
{
    private const string Prefix = "MyProjectName";
    public const string Home = Prefix + ".Home";

    //Add your menu items here...

}
