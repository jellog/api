$(function () {
    jellog.log.debug('Index.js initialized!');
});