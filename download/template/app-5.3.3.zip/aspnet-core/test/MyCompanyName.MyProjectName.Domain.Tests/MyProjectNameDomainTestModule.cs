﻿using MyCompanyName.MyProjectName.EntityFrameworkCore;
using DataGap.Jellog.Modularity;

namespace MyCompanyName.MyProjectName;

[DependsOn(
    typeof(MyProjectNameEntityFrameworkCoreTestModule)
    )]
public class MyProjectNameDomainTestModule : JellogModule
{

}
