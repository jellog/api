﻿using Microsoft.Extensions.DependencyInjection;
using DataGap.Jellog;
using DataGap.Jellog.Authorization;
using DataGap.Jellog.Autofac;
using DataGap.Jellog.BackgroundJobs;
using DataGap.Jellog.Data;
using DataGap.Jellog.IdentityServer;
using DataGap.Jellog.Modularity;
using DataGap.Jellog.Threading;

namespace MyCompanyName.MyProjectName;

[DependsOn(
    typeof(JellogAutofacModule),
    typeof(JellogTestBaseModule),
    typeof(JellogAuthorizationModule),
    typeof(MyProjectNameDomainModule)
    )]
public class MyProjectNameTestBaseModule : JellogModule
{
    public override void PreConfigureServices(ServiceConfigurationContext context)
    {
        PreConfigure<JellogIdentityServerBuilderOptions>(options =>
        {
            options.AddDeveloperSigningCredential = false;
        });

        PreConfigure<IIdentityServerBuilder>(identityServerBuilder =>
        {
            identityServerBuilder.AddDeveloperSigningCredential(false, System.Guid.NewGuid().ToString());
        });
    }

    public override void ConfigureServices(ServiceConfigurationContext context)
    {
        Configure<JellogBackgroundJobOptions>(options =>
        {
            options.IsJobExecutionEnabled = false;
        });

        context.Services.AddAlwaysAllowAuthorization();
    }

    public override void OnApplicationInitialization(ApplicationInitializationContext context)
    {
        SeedTestData(context);
    }

    private static void SeedTestData(ApplicationInitializationContext context)
    {
        AsyncHelper.RunSync(async () =>
        {
            using (var scope = context.ServiceProvider.CreateScope())
            {
                await scope.ServiceProvider
                    .GetRequiredService<IDataSeeder>()
                    .SeedAsync();
            }
        });
    }
}
