﻿using DataGap.Jellog.Account;
using DataGap.Jellog.FeatureManagement;
using DataGap.Jellog.Identity;
using DataGap.Jellog.Modularity;
using DataGap.Jellog.ObjectExtending;
using DataGap.Jellog.PermissionManagement;
using DataGap.Jellog.SettingManagement;
using DataGap.Jellog.TenantManagement;

namespace MyCompanyName.MyProjectName;

[DependsOn(
    typeof(MyProjectNameDomainSharedModule),
    typeof(JellogAccountApplicationContractsModule),
    typeof(JellogFeatureManagementApplicationContractsModule),
    typeof(JellogIdentityApplicationContractsModule),
    typeof(JellogPermissionManagementApplicationContractsModule),
    typeof(JellogSettingManagementApplicationContractsModule),
    typeof(JellogTenantManagementApplicationContractsModule),
    typeof(JellogObjectExtendingModule)
)]
public class MyProjectNameApplicationContractsModule : JellogModule
{
    public override void PreConfigureServices(ServiceConfigurationContext context)
    {
        MyProjectNameDtoExtensions.Configure();
    }
}
