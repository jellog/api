﻿using DataGap.Jellog.Account;
using DataGap.Jellog.AutoMapper;
using DataGap.Jellog.FeatureManagement;
using DataGap.Jellog.Identity;
using DataGap.Jellog.Modularity;
using DataGap.Jellog.PermissionManagement;
using DataGap.Jellog.SettingManagement;
using DataGap.Jellog.TenantManagement;

namespace MyCompanyName.MyProjectName;

[DependsOn(
    typeof(MyProjectNameDomainModule),
    typeof(JellogAccountApplicationModule),
    typeof(MyProjectNameApplicationContractsModule),
    typeof(JellogIdentityApplicationModule),
    typeof(JellogPermissionManagementApplicationModule),
    typeof(JellogTenantManagementApplicationModule),
    typeof(JellogFeatureManagementApplicationModule),
    typeof(JellogSettingManagementApplicationModule)
    )]
public class MyProjectNameApplicationModule : JellogModule
{
    public override void ConfigureServices(ServiceConfigurationContext context)
    {
        Configure<JellogAutoMapperOptions>(options =>
        {
            options.AddMaps<MyProjectNameApplicationModule>();
        });
    }
}
