﻿using MyCompanyName.MyProjectName.Localization;
using DataGap.Jellog.AuditLogging;
using DataGap.Jellog.BackgroundJobs;
using DataGap.Jellog.FeatureManagement;
using DataGap.Jellog.Identity;
using DataGap.Jellog.Localization;
using DataGap.Jellog.Localization.ExceptionHandling;
using DataGap.Jellog.Modularity;
using DataGap.Jellog.OpenIddict;
using DataGap.Jellog.PermissionManagement;
using DataGap.Jellog.SettingManagement;
using DataGap.Jellog.TenantManagement;
using DataGap.Jellog.Validation.Localization;
using DataGap.Jellog.VirtualFileSystem;

namespace MyCompanyName.MyProjectName;

[DependsOn(
    typeof(JellogAuditLoggingDomainSharedModule),
    typeof(JellogBackgroundJobsDomainSharedModule),
    typeof(JellogFeatureManagementDomainSharedModule),
    typeof(JellogIdentityDomainSharedModule),
    typeof(JellogOpenIddictDomainSharedModule),
    typeof(JellogPermissionManagementDomainSharedModule),
    typeof(JellogSettingManagementDomainSharedModule),
    typeof(JellogTenantManagementDomainSharedModule)    
    )]
public class MyProjectNameDomainSharedModule : JellogModule
{
    public override void PreConfigureServices(ServiceConfigurationContext context)
    {
        MyProjectNameGlobalFeatureConfigurator.Configure();
        MyProjectNameModuleExtensionConfigurator.Configure();
    }

    public override void ConfigureServices(ServiceConfigurationContext context)
    {
        Configure<JellogVirtualFileSystemOptions>(options =>
        {
            options.FileSets.AddEmbedded<MyProjectNameDomainSharedModule>();
        });

        Configure<JellogLocalizationOptions>(options =>
        {
            options.Resources
                .Add<MyProjectNameResource>("en")
                .AddBaseTypes(typeof(JellogValidationResource))
                .AddVirtualJson("/Localization/MyProjectName");

            options.DefaultResourceType = typeof(MyProjectNameResource);
        });

        Configure<JellogExceptionLocalizationOptions>(options =>
        {
            options.MapCodeNamespace("MyProjectName", typeof(MyProjectNameResource));
        });
    }
}
