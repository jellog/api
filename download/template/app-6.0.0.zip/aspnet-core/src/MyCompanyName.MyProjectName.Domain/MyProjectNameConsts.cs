﻿namespace MyCompanyName.MyProjectName;

public static class MyProjectNameConsts
{
    public const string DbTablePrefix = "App";

    public const string DbSchema = null;
}
