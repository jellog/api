﻿using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.DependencyInjection.Extensions;
using MyCompanyName.MyProjectName.MultiTenancy;
using DataGap.Jellog.AuditLogging;
using DataGap.Jellog.BackgroundJobs;
using DataGap.Jellog.Emailing;
using DataGap.Jellog.FeatureManagement;
using DataGap.Jellog.Identity;
using DataGap.Jellog.Modularity;
using DataGap.Jellog.MultiTenancy;
using DataGap.Jellog.OpenIddict;
using DataGap.Jellog.PermissionManagement.Identity;
using DataGap.Jellog.PermissionManagement.OpenIddict;
using DataGap.Jellog.SettingManagement;
using DataGap.Jellog.TenantManagement;

namespace MyCompanyName.MyProjectName;

[DependsOn(
    typeof(MyProjectNameDomainSharedModule),
    typeof(JellogAuditLoggingDomainModule),
    typeof(JellogBackgroundJobsDomainModule),
    typeof(JellogFeatureManagementDomainModule),
    typeof(JellogIdentityDomainModule),
    typeof(JellogOpenIddictDomainModule),
    typeof(JellogPermissionManagementDomainOpenIddictModule),
    typeof(JellogPermissionManagementDomainIdentityModule),
    typeof(JellogSettingManagementDomainModule),
    typeof(JellogTenantManagementDomainModule),
    typeof(JellogEmailingModule)
)]
public class MyProjectNameDomainModule : JellogModule
{
    public override void ConfigureServices(ServiceConfigurationContext context)
    {
        Configure<JellogMultiTenancyOptions>(options =>
        {
            options.IsEnabled = MultiTenancyConsts.IsEnabled;
        });

#if DEBUG
        context.Services.Replace(ServiceDescriptor.Singleton<IEmailSender, NullEmailSender>());
#endif
    }
}
