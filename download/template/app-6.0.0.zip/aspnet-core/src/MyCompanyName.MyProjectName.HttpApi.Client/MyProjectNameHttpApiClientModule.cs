﻿using Microsoft.Extensions.DependencyInjection;
using DataGap.Jellog.Account;
using DataGap.Jellog.FeatureManagement;
using DataGap.Jellog.Identity;
using DataGap.Jellog.Modularity;
using DataGap.Jellog.PermissionManagement;
using DataGap.Jellog.TenantManagement;
using DataGap.Jellog.SettingManagement;
using DataGap.Jellog.VirtualFileSystem;

namespace MyCompanyName.MyProjectName;

[DependsOn(
    typeof(MyProjectNameApplicationContractsModule),
    typeof(JellogAccountHttpApiClientModule),
    typeof(JellogIdentityHttpApiClientModule),
    typeof(JellogPermissionManagementHttpApiClientModule),
    typeof(JellogTenantManagementHttpApiClientModule),
    typeof(JellogFeatureManagementHttpApiClientModule),
    typeof(JellogSettingManagementHttpApiClientModule)
)]
public class MyProjectNameHttpApiClientModule : JellogModule
{
    public const string RemoteServiceName = "Default";

    public override void ConfigureServices(ServiceConfigurationContext context)
    {
        context.Services.AddHttpClientProxies(
            typeof(MyProjectNameApplicationContractsModule).Assembly,
            RemoteServiceName
        );

        Configure<JellogVirtualFileSystemOptions>(options =>
        {
            options.FileSets.AddEmbedded<MyProjectNameHttpApiClientModule>();
        });
    }
}
