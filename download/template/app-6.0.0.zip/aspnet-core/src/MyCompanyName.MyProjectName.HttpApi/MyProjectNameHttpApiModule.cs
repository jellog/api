﻿using Localization.Resources.JellogUi;
using MyCompanyName.MyProjectName.Localization;
using DataGap.Jellog.Account;
using DataGap.Jellog.FeatureManagement;
using DataGap.Jellog.Identity;
using DataGap.Jellog.Localization;
using DataGap.Jellog.Modularity;
using DataGap.Jellog.PermissionManagement.HttpApi;
using DataGap.Jellog.SettingManagement;
using DataGap.Jellog.TenantManagement;

namespace MyCompanyName.MyProjectName;

[DependsOn(
    typeof(MyProjectNameApplicationContractsModule),
    typeof(JellogAccountHttpApiModule),
    typeof(JellogIdentityHttpApiModule),
    typeof(JellogPermissionManagementHttpApiModule),
    typeof(JellogTenantManagementHttpApiModule),
    typeof(JellogFeatureManagementHttpApiModule),
    typeof(JellogSettingManagementHttpApiModule)
    )]
public class MyProjectNameHttpApiModule : JellogModule
{
    public override void ConfigureServices(ServiceConfigurationContext context)
    {
        ConfigureLocalization();
    }

    private void ConfigureLocalization()
    {
        Configure<JellogLocalizationOptions>(options =>
        {
            options.Resources
                .Get<MyProjectNameResource>()
                .AddBaseTypes(
                    typeof(JellogUiResource)
                );
        });
    }
}
