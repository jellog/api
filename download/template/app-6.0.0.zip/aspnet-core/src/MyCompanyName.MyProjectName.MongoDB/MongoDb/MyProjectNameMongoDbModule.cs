﻿using Microsoft.Extensions.DependencyInjection;
using DataGap.Jellog.AuditLogging.MongoDB;
using DataGap.Jellog.BackgroundJobs.MongoDB;
using DataGap.Jellog.FeatureManagement.MongoDB;
using DataGap.Jellog.Identity.MongoDB;
using DataGap.Jellog.Modularity;
using DataGap.Jellog.OpenIddict.MongoDB;
using DataGap.Jellog.PermissionManagement.MongoDB;
using DataGap.Jellog.SettingManagement.MongoDB;
using DataGap.Jellog.TenantManagement.MongoDB;
using DataGap.Jellog.Uow;

namespace MyCompanyName.MyProjectName.MongoDB;

[DependsOn(
    typeof(MyProjectNameDomainModule),
    typeof(JellogPermissionManagementMongoDbModule),
    typeof(JellogSettingManagementMongoDbModule),
    typeof(JellogIdentityMongoDbModule),
    typeof(JellogOpenIddictMongoDbModule),
    typeof(JellogBackgroundJobsMongoDbModule),
    typeof(JellogAuditLoggingMongoDbModule),
    typeof(JellogTenantManagementMongoDbModule),
    typeof(JellogFeatureManagementMongoDbModule)
    )]
public class MyProjectNameMongoDbModule : JellogModule
{
    public override void ConfigureServices(ServiceConfigurationContext context)
    {
        context.Services.AddMongoDbContext<MyProjectNameMongoDbContext>(options =>
        {
            options.AddDefaultRepositories();
        });

        Configure<JellogUnitOfWorkDefaultOptions>(options =>
        {
            options.TransactionBehavior = UnitOfWorkTransactionBehavior.Disabled;
        });
    }
}
