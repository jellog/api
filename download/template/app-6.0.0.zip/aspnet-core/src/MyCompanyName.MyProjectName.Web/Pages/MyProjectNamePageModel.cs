﻿using MyCompanyName.MyProjectName.Localization;
using DataGap.Jellog.AspNetCore.Mvc.UI.RazorPages;

namespace MyCompanyName.MyProjectName.Web.Pages;

/* Inherit your PageModel classes from this class.
 */
public abstract class MyProjectNamePageModel : JellogPageModel
{
    protected MyProjectNamePageModel()
    {
        LocalizationResourceType = typeof(MyProjectNameResource);
    }
}
