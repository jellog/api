﻿using MyCompanyName.MyProjectName.EntityFrameworkCore;
using Xunit;

namespace MyCompanyName.MyProjectName.EntityFrameworkCore;

public class MyProjectNameEntityFrameworkCoreCollectionFixtureBase : ICollectionFixture<MyProjectNameEntityFrameworkCoreFixture>
{

}
