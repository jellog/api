﻿using System;
using Microsoft.Extensions.DependencyInjection;
using Polly;
using DataGap.Jellog.Autofac;
using DataGap.Jellog.Http.Client;
using DataGap.Jellog.Http.Client.IdentityModel;
using DataGap.Jellog.Modularity;

namespace MyCompanyName.MyProjectName.HttpApi.Client.ConsoleTestApp;

[DependsOn(
    typeof(JellogAutofacModule),
    typeof(MyProjectNameHttpApiClientModule),
    typeof(JellogHttpClientIdentityModelModule)
    )]
public class MyProjectNameConsoleApiClientModule : JellogModule
{
    public override void PreConfigureServices(ServiceConfigurationContext context)
    {
        PreConfigure<JellogHttpClientBuilderOptions>(options =>
        {
            options.ProxyClientBuildActions.Add((remoteServiceName, clientBuilder) =>
            {
                clientBuilder.AddTransientHttpErrorPolicy(
                    policyBuilder => policyBuilder.WaitAndRetryAsync(3, i => TimeSpan.FromSeconds(Math.Pow(2, i)))
                );
            });
        });
    }
}
