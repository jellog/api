using Blazorise.Bootstrap5;
using Blazorise.Icons.FontAwesome;
using Microsoft.AspNetCore.Extensions.DependencyInjection;
using Microsoft.Extensions.DependencyInjection.Extensions;
using Microsoft.OpenApi.Models;
using MyCompanyName.MyProjectName.Data;
using MyCompanyName.MyProjectName.Localization;
using MyCompanyName.MyProjectName.Menus;
using DataGap.Jellog;
using DataGap.Jellog.Account;
using DataGap.Jellog.Account.Web;
using DataGap.Jellog.AspNetCore.Authentication.JwtBearer;
using DataGap.Jellog.AspNetCore.Components.Server.BasicTheme;
using DataGap.Jellog.AspNetCore.Components.Server.BasicTheme.Bundling;
using DataGap.Jellog.AspNetCore.Components.Web.Theming.Routing;
using DataGap.Jellog.AspNetCore.Mvc;
using DataGap.Jellog.AspNetCore.Mvc.Localization;
using DataGap.Jellog.AspNetCore.Mvc.UI.Bundling;
using DataGap.Jellog.AspNetCore.Mvc.UI.Theme.Basic;
using DataGap.Jellog.AspNetCore.Mvc.UI.Theme.Basic.Bundling;
using DataGap.Jellog.AspNetCore.Serilog;
using DataGap.Jellog.AuditLogging.EntityFrameworkCore;
using DataGap.Jellog.Autofac;
using DataGap.Jellog.AutoMapper;
using DataGap.Jellog.Emailing;
using DataGap.Jellog.EntityFrameworkCore;
using DataGap.Jellog.EntityFrameworkCore.SqlServer;
using DataGap.Jellog.FeatureManagement;
using DataGap.Jellog.FeatureManagement.Blazor.Server;
using DataGap.Jellog.FeatureManagement.EntityFrameworkCore;
using DataGap.Jellog.Identity;
using DataGap.Jellog.Identity.Blazor.Server;
using DataGap.Jellog.Identity.EntityFrameworkCore;
using DataGap.Jellog.IdentityServer.EntityFrameworkCore;
using DataGap.Jellog.Localization;
using DataGap.Jellog.Localization.ExceptionHandling;
using DataGap.Jellog.Modularity;
using DataGap.Jellog.PermissionManagement;
using DataGap.Jellog.PermissionManagement.EntityFrameworkCore;
using DataGap.Jellog.PermissionManagement.HttpApi;
using DataGap.Jellog.PermissionManagement.Identity;
using DataGap.Jellog.PermissionManagement.IdentityServer;
using DataGap.Jellog.SettingManagement;
using DataGap.Jellog.SettingManagement.Blazor.Server;
using DataGap.Jellog.SettingManagement.EntityFrameworkCore;
using DataGap.Jellog.Swashbuckle;
using DataGap.Jellog.TenantManagement;
using DataGap.Jellog.TenantManagement.Blazor.Server;
using DataGap.Jellog.TenantManagement.EntityFrameworkCore;
using DataGap.Jellog.UI.Navigation;
using DataGap.Jellog.UI.Navigation.Urls;
using DataGap.Jellog.Validation.Localization;
using DataGap.Jellog.VirtualFileSystem;

namespace MyCompanyName.MyProjectName;

[DependsOn(
    // JELLOG Framework packages
    typeof(JellogAspNetCoreMvcModule),
    typeof(JellogAutofacModule),
    typeof(JellogAutoMapperModule),
    typeof(JellogEntityFrameworkCoreSqlServerModule),
    typeof(JellogSwashbuckleModule),
    typeof(JellogAspNetCoreAuthenticationJwtBearerModule),
    typeof(JellogAspNetCoreSerilogModule),
    typeof(JellogAspNetCoreMvcUiBasicThemeModule),
    typeof(JellogAspNetCoreComponentsServerBasicThemeModule),

    // Account module packages
    typeof(JellogAccountApplicationModule),
    typeof(JellogAccountHttpApiModule),
    typeof(JellogAccountWebIdentityServerModule),

    // Identity module packages
    typeof(JellogPermissionManagementDomainIdentityModule),
    typeof(JellogPermissionManagementDomainIdentityServerModule),
    typeof(JellogIdentityApplicationModule),
    typeof(JellogIdentityHttpApiModule),
    typeof(JellogIdentityEntityFrameworkCoreModule),
    typeof(JellogIdentityServerEntityFrameworkCoreModule),
    typeof(JellogIdentityBlazorServerModule),

    // Audit logging module packages
    typeof(JellogAuditLoggingEntityFrameworkCoreModule),

    // Permission Management module packages
    typeof(JellogPermissionManagementApplicationModule),
    typeof(JellogPermissionManagementHttpApiModule),
    typeof(JellogPermissionManagementEntityFrameworkCoreModule),

    // Tenant Management module packages
    typeof(JellogTenantManagementApplicationModule),
    typeof(JellogTenantManagementHttpApiModule),
    typeof(JellogTenantManagementEntityFrameworkCoreModule),
    typeof(JellogTenantManagementBlazorServerModule),

    // Feature Management module packages
    typeof(JellogFeatureManagementApplicationModule),
    typeof(JellogFeatureManagementEntityFrameworkCoreModule),
    typeof(JellogFeatureManagementHttpApiModule),
    typeof(JellogFeatureManagementBlazorServerModule),

    // Setting Management module packages
    typeof(JellogSettingManagementApplicationModule),
    typeof(JellogSettingManagementEntityFrameworkCoreModule),
    typeof(JellogSettingManagementHttpApiModule),
    typeof(JellogSettingManagementBlazorServerModule)
)]
public class MyProjectNameModule : JellogModule
{
    /* Single point to enable/disable multi-tenancy */
    public const bool IsMultiTenant = true;

    public override void PreConfigureServices(ServiceConfigurationContext context)
    {
        context.Services.PreConfigure<JellogMvcDataAnnotationsLocalizationOptions>(options =>
        {
            options.AddAssemblyResource(
                typeof(MyProjectNameResource),
                typeof(MyProjectNameModule).Assembly
            );
        });
    }

    public override void ConfigureServices(ServiceConfigurationContext context)
    {
        var hostingEnvironment = context.Services.GetHostingEnvironment();
        var configuration = context.Services.GetConfiguration();

        if (hostingEnvironment.IsDevelopment())
        {
            context.Services.Replace(ServiceDescriptor.Singleton<IEmailSender, NullEmailSender>());
        }

        ConfigureUrls(configuration);
        ConfigureBundles();
        ConfigureAutoMapper(context);
        ConfigureVirtualFiles(hostingEnvironment);
        ConfigureLocalizationServices();
        ConfigureSwaggerServices(context.Services);
        ConfigureNavigationServices();
        ConfigureAutoApiControllers();
        ConfigureBlazorise(context);
        ConfigureRouter(context);
        ConfigureAuthentication(context, configuration);
        ConfigureEfCore(context);
    }

    private void ConfigureUrls(IConfiguration configuration)
    {
        Configure<AppUrlOptions>(options =>
        {
            options.Applications["MVC"].RootUrl = configuration["App:SelfUrl"];
            options.RedirectAllowedUrls.AddRange(configuration["App:RedirectAllowedUrls"].Split(','));
        });
    }

    private void ConfigureBundles()
    {
        Configure<JellogBundlingOptions>(options =>
        {
            // MVC UI
            options.StyleBundles.Configure(
                BasicThemeBundles.Styles.Global,
                bundle =>
                {
                    bundle.AddFiles("/global-styles.css");
                }
            );

            //BLAZOR UI
            options.StyleBundles.Configure(
                BlazorBasicThemeBundles.Styles.Global,
                bundle =>
                {
                    bundle.AddFiles("/blazor-global-styles.css");
                    //You can remove the following line if you don't use Blazor CSS isolation for components
                    bundle.AddFiles("/MyCompanyName.MyProjectName.Blazor.Server.styles.css");
                }
            );
        });
    }

    private void ConfigureAuthentication(ServiceConfigurationContext context, IConfiguration configuration)
    {
        context.Services.AddAuthentication()
            .AddJwtBearer(options =>
            {
                options.Authority = configuration["AuthServer:Authority"];
                options.RequireHttpsMetadata = Convert.ToBoolean(configuration["AuthServer:RequireHttpsMetadata"]);
                options.Audience = "MyProjectName";
            });

        context.Services.ForwardIdentityAuthenticationForBearer();
    }

    private void ConfigureLocalizationServices()
    {
        Configure<JellogLocalizationOptions>(options =>
        {
            options.Resources
                .Add<MyProjectNameResource>("en")
                .AddBaseTypes(typeof(JellogValidationResource))
                .AddVirtualJson("/Localization/MyProjectName");

            options.DefaultResourceType = typeof(MyProjectNameResource);

            options.Languages.Add(new LanguageInfo("en", "en", "English"));
            options.Languages.Add(new LanguageInfo("tr", "tr", "Türkçe"));
            options.Languages.Add(new LanguageInfo("ar", "ar", "العربية"));
            options.Languages.Add(new LanguageInfo("cs", "cs", "Čeština"));
            options.Languages.Add(new LanguageInfo("en-GB", "en-GB", "English (UK)"));
            options.Languages.Add(new LanguageInfo("hu", "hu", "Magyar"));
            options.Languages.Add(new LanguageInfo("fi", "fi", "Finnish"));
            options.Languages.Add(new LanguageInfo("fr", "fr", "Français"));
            options.Languages.Add(new LanguageInfo("hi", "hi", "Hindi", "in"));
            options.Languages.Add(new LanguageInfo("is", "is", "Icelandic", "is"));
            options.Languages.Add(new LanguageInfo("it", "it", "Italiano", "it"));
            options.Languages.Add(new LanguageInfo("pt-BR", "pt-BR", "Português"));
            options.Languages.Add(new LanguageInfo("ro-RO", "ro-RO", "Română"));
            options.Languages.Add(new LanguageInfo("ru", "ru", "Русский"));
            options.Languages.Add(new LanguageInfo("sk", "sk", "Slovak"));
            options.Languages.Add(new LanguageInfo("zh-Hans", "zh-Hans", "简体中文"));
            options.Languages.Add(new LanguageInfo("zh-Hant", "zh-Hant", "繁體中文"));
            options.Languages.Add(new LanguageInfo("de-DE", "de-DE", "Deutsch", "de"));
            options.Languages.Add(new LanguageInfo("es", "es", "Español"));
        });

        Configure<JellogExceptionLocalizationOptions>(options =>
        {
            options.MapCodeNamespace("MyProjectName", typeof(MyProjectNameResource));
        });
    }

    private void ConfigureVirtualFiles(IWebHostEnvironment hostingEnvironment)
    {
        Configure<JellogVirtualFileSystemOptions>(options =>
        {
            options.FileSets.AddEmbedded<MyProjectNameModule>();
            if (hostingEnvironment.IsDevelopment())
            {
                /* Using physical files in development, so we don't need to recompile on changes */
                options.FileSets.ReplaceEmbeddedByPhysical<MyProjectNameModule>(hostingEnvironment.ContentRootPath);
            }
        });
    }

    private void ConfigureSwaggerServices(IServiceCollection services)
    {
        services.AddJellogSwaggerGen(
            options =>
            {
                options.SwaggerDoc("v1", new OpenApiInfo { Title = "MyProjectName API", Version = "v1" });
                options.DocInclusionPredicate((docName, description) => true);
                options.CustomSchemaIds(type => type.FullName);
            }
        );
    }

    private void ConfigureBlazorise(ServiceConfigurationContext context)
    {
        context.Services
            .AddBootstrap5Providers()
            .AddFontAwesomeIcons();
    }

    private void ConfigureRouter(ServiceConfigurationContext context)
    {
        Configure<JellogRouterOptions>(options =>
        {
            options.AppAssembly = typeof(MyProjectNameModule).Assembly;
        });
    }

    private void ConfigureNavigationServices()
    {
        Configure<JellogNavigationOptions>(options =>
        {
            options.MenuContributors.Add(new MyProjectNameMenuContributor());
        });
    }

    private void ConfigureAutoApiControllers()
    {
        Configure<JellogAspNetCoreMvcOptions>(options =>
        {
            options.ConventionalControllers.Create(typeof(MyProjectNameModule).Assembly);
        });
    }

    private void ConfigureAutoMapper(ServiceConfigurationContext context)
    {
        context.Services.AddAutoMapperObjectMapper<MyProjectNameModule>();
        Configure<JellogAutoMapperOptions>(options =>
        {
            options.AddMaps<MyProjectNameModule>();
        });
    }

    private void ConfigureEfCore(ServiceConfigurationContext context)
    {
        context.Services.AddJellogDbContext<MyProjectNameDbContext>(options =>
        {
            /* You can remove "includeAllEntities: true" to create
             * default repositories only for aggregate roots
             * Documentation: https://docs.jellog.io/en/jellog/latest/Entity-Framework-Core#add-default-repositories
             */
            options.AddDefaultRepositories(includeAllEntities: true);
        });

        Configure<JellogDbContextOptions>(options =>
        {
            options.Configure(configurationContext =>
            {
                configurationContext.UseSqlServer();
            });
        });
    }

    public override void OnApplicationInitialization(ApplicationInitializationContext context)
    {
        var env = context.GetEnvironment();
        var app = context.GetApplicationBuilder();

        app.UseJellogRequestLocalization();

        if (env.IsDevelopment())
        {
            app.UseDeveloperExceptionPage();
        }
        else
        {
            app.UseExceptionHandler("/Error");
            app.UseHsts();
        }

        app.UseHttpsRedirection();
        app.UseCorrelationId();
        app.UseStaticFiles();
        app.UseRouting();
        app.UseAuthentication();
        app.UseJwtTokenMiddleware();

        if (IsMultiTenant)
        {
            app.UseMultiTenancy();
        }

        app.UseUnitOfWork();
        app.UseIdentityServer();
        app.UseAuthorization();

        app.UseSwagger();
        app.UseJellogSwaggerUI(options =>
        {
            options.SwaggerEndpoint("/swagger/v1/swagger.json", "MyProjectName API");
        });

        app.UseAuditing();
        app.UseJellogSerilogEnrichers();
        app.UseConfiguredEndpoints();
    }
}
