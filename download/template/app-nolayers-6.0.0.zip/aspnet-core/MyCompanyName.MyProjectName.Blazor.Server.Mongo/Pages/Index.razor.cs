﻿namespace MyCompanyName.MyProjectName.Blazor.Server.Pages;

public partial class Index
{

}
