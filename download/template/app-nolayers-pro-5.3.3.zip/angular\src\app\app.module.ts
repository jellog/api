import { CoreModule } from '@jellog/ng.core';
import { GdprConfigModule } from '@dataGap/jellog.ng.gdpr/config';
import { SettingManagementConfigModule } from '@jellog/ng.setting-management/config';
import { ThemeSharedModule } from '@jellog/ng.theme.shared';
import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { CommercialUiConfigModule } from '@dataGap/jellog.commercial.ng.ui/config';
import { AccountAdminConfigModule } from '@dataGap/jellog.ng.account/admin/config';
import { AccountPublicConfigModule } from '@dataGap/jellog.ng.account/public/config';
import { AuditLoggingConfigModule } from '@dataGap/jellog.ng.audit-logging/config';
import { IdentityServerConfigModule } from '@dataGap/jellog.ng.identity-server/config';
import { IdentityConfigModule } from '@dataGap/jellog.ng.identity/config';
import { LanguageManagementConfigModule } from '@dataGap/jellog.ng.language-management/config';
import { registerLocale } from '@dataGap/jellog.ng.language-management/locale';
import { SaasConfigModule } from '@dataGap/jellog.ng.saas/config';
import { TextTemplateManagementConfigModule } from '@dataGap/jellog.ng.text-template-management/config';
import { HttpErrorComponent, ThemeLeptonModule } from '@dataGap/jellog.ng.theme.lepton';
import { environment } from '../environments/environment';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { APP_ROUTE_PROVIDER } from './route.provider';

@NgModule({
  declarations: [AppComponent],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    AppRoutingModule,
    CoreModule.forRoot({
      environment,
      registerLocaleFn: registerLocale(),
    }),
    ThemeSharedModule.forRoot({
      httpErrorConfig: {
        errorScreen: {
          component: HttpErrorComponent,
          forWhichErrors: [401, 403, 404, 500],
          hideCloseIcon: true,
        },
      },
    }),
    AccountAdminConfigModule.forRoot(),
    AccountPublicConfigModule.forRoot(),
    IdentityConfigModule.forRoot(),
    LanguageManagementConfigModule.forRoot(),
    SaasConfigModule.forRoot(),
    AuditLoggingConfigModule.forRoot(),
    IdentityServerConfigModule.forRoot(),
    TextTemplateManagementConfigModule.forRoot(),
    SettingManagementConfigModule.forRoot(),
    ThemeLeptonModule.forRoot(),
    CommercialUiConfigModule.forRoot(),
    GdprConfigModule.forRoot(),
  ],
  providers: [APP_ROUTE_PROVIDER],
  bootstrap: [AppComponent],
})
export class AppModule {}
