using Blazorise.Bootstrap5;
using Blazorise.Icons.FontAwesome;
using Microsoft.AspNetCore.Extensions.DependencyInjection;
using Microsoft.Extensions.DependencyInjection.Extensions;
using Microsoft.OpenApi.Models;
using MyCompanyName.MyProjectName.Data;
using MyCompanyName.MyProjectName.Localization;
using MyCompanyName.MyProjectName.Menus;
using DataGap.Jellog;
using DataGap.Jellog.Account;
using DataGap.Jellog.Account.Pro.Admin.Blazor.Server;
using DataGap.Jellog.Account.Web;
using DataGap.Jellog.AspNetCore.Authentication.JwtBearer;
using DataGap.Jellog.AspNetCore.Components.Server.LeptonTheme;
using DataGap.Jellog.AspNetCore.Components.Server.LeptonTheme.Bundling;
using DataGap.Jellog.AspNetCore.Components.Web.Theming.Routing;
using DataGap.Jellog.AspNetCore.Mvc;
using DataGap.Jellog.AspNetCore.Mvc.Localization;
using DataGap.Jellog.AspNetCore.Mvc.UI.Bundling;
using DataGap.Jellog.AspNetCore.Mvc.UI.Theme.Lepton;
using DataGap.Jellog.AspNetCore.Mvc.UI.Theme.Lepton.Bundling;
using DataGap.Jellog.AspNetCore.Mvc.UI.Theme.Shared;
using DataGap.Jellog.AspNetCore.Serilog;
using DataGap.Jellog.AuditLogging;
using DataGap.Jellog.AuditLogging.Blazor.Server;
using DataGap.Jellog.AuditLogging.MongoDB;
using DataGap.Jellog.Autofac;
using DataGap.Jellog.AutoMapper;
using DataGap.Jellog.BlobStoring.Database.MongoDB;
using DataGap.Jellog.FeatureManagement;
using DataGap.Jellog.FeatureManagement.Blazor.Server;
using DataGap.Jellog.FeatureManagement.MongoDB;
using DataGap.Jellog.Identity;
using DataGap.Jellog.Identity.MongoDB;
using DataGap.Jellog.Identity.Pro.Blazor.Server;
using DataGap.Jellog.IdentityServer;
using DataGap.Jellog.IdentityServer.Blazor.Server;
using DataGap.Jellog.IdentityServer.MongoDB;
//using DataGap.Jellog.Commercial.SuiteTemplates;
using DataGap.Jellog.Gdpr;
using DataGap.Jellog.Gdpr.Blazor.Server;
using DataGap.Jellog.Emailing;
using DataGap.Jellog.LanguageManagement;
using DataGap.Jellog.LanguageManagement.Blazor.Server;
using DataGap.Jellog.LanguageManagement.MongoDB;
using DataGap.Jellog.LeptonTheme;
using DataGap.Jellog.LeptonTheme.Management;
using DataGap.Jellog.LeptonTheme.Management.Blazor.Server;
using DataGap.Jellog.Localization;
using DataGap.Jellog.Localization.ExceptionHandling;
using DataGap.Jellog.Modularity;
using DataGap.Jellog.MultiTenancy;
using DataGap.Jellog.PermissionManagement;
using DataGap.Jellog.PermissionManagement.Blazor.Server;
using DataGap.Jellog.PermissionManagement.MongoDB;
using DataGap.Jellog.PermissionManagement.HttpApi;
using DataGap.Jellog.PermissionManagement.Identity;
using DataGap.Jellog.PermissionManagement.IdentityServer;
using DataGap.Jellog.SettingManagement;
using DataGap.Jellog.SettingManagement.Blazor.Server;
using DataGap.Jellog.SettingManagement.MongoDB;
using DataGap.Jellog.Swashbuckle;
using DataGap.Jellog.TextTemplateManagement;
using DataGap.Jellog.TextTemplateManagement.Blazor.Server;
using DataGap.Jellog.TextTemplateManagement.MongoDB;
using DataGap.Jellog.UI.Navigation;
using DataGap.Jellog.UI.Navigation.Urls;
using DataGap.Jellog.Uow;
using DataGap.Jellog.Validation.Localization;
using DataGap.Jellog.VirtualFileSystem;
using DataGap.Saas.MongoDB;
using DataGap.Saas.Host;
using DataGap.Saas.Host.Blazor.Server;

namespace MyCompanyName.MyProjectName;

[DependsOn(
    // JELLOG Framework packages
    typeof(JellogAspNetCoreMvcModule),
    typeof(JellogAutofacModule),
    typeof(JellogAutoMapperModule),
    typeof(JellogSwashbuckleModule),
    typeof(JellogAspNetCoreSerilogModule),
    typeof(JellogAspNetCoreAuthenticationJwtBearerModule),

    // Suite templates package
    //typeof(DataGapJellogCommercialSuiteTemplatesModule),

    // Lepton Theme module packages
    typeof(JellogAspNetCoreMvcUiLeptonThemeModule),
    typeof(LeptonThemeManagementHttpApiModule),
    typeof(LeptonThemeManagementApplicationModule),
    typeof(LeptonThemeManagementBlazorServerModule),
    typeof(JellogAspNetCoreComponentsServerLeptonThemeModule),

    // Account module packages
    typeof(JellogAccountPublicWebIdentityServerModule),
    typeof(JellogAccountPublicHttpApiModule),
    typeof(JellogAccountPublicApplicationModule),

    typeof(JellogAccountAdminBlazorServerModule),
    typeof(JellogAccountAdminHttpApiModule),
    typeof(JellogAccountAdminApplicationModule),

    // Identity module packages
    typeof(JellogPermissionManagementDomainIdentityModule),
    typeof(JellogPermissionManagementDomainIdentityServerModule),
    typeof(JellogIdentityProBlazorServerModule),
    typeof(JellogIdentityHttpApiModule),
    typeof(JellogIdentityApplicationModule),
    typeof(JellogIdentityProMongoDbModule),

    typeof(JellogIdentityServerBlazorServerModule),
    typeof(JellogIdentityServerHttpApiModule),
    typeof(JellogIdentityServerApplicationModule),
    typeof(JellogIdentityServerMongoDbModule),

    // Audit logging module packages
    typeof(JellogAuditLoggingBlazorServerModule),
    typeof(JellogAuditLoggingHttpApiModule),
    typeof(JellogAuditLoggingApplicationModule),
    typeof(JellogAuditLoggingMongoDbModule),

    // Permission Management module packages
    typeof(JellogPermissionManagementBlazorServerModule),
    typeof(JellogPermissionManagementApplicationModule),
    typeof(JellogPermissionManagementHttpApiModule),
    typeof(JellogPermissionManagementMongoDbModule),

    // Saas Management module packages
    typeof(SaasHostBlazorServerModule),
    typeof(SaasHostHttpApiModule),
    typeof(SaasHostApplicationModule),
    typeof(SaasMongoDbModule),

    // Feature Management module packages
    typeof(JellogFeatureManagementBlazorServerModule),
    typeof(JellogFeatureManagementHttpApiModule),
    typeof(JellogFeatureManagementApplicationModule),
    typeof(JellogFeatureManagementMongoDbModule),

    // Setting Management module packages
    typeof(JellogSettingManagementBlazorServerModule),
    typeof(JellogSettingManagementHttpApiModule),
    typeof(JellogSettingManagementApplicationModule),
    typeof(JellogSettingManagementMongoDbModule),

    // Text Template Management module packages
    typeof(TextTemplateManagementBlazorServerModule),
    typeof(TextTemplateManagementHttpApiModule),
    typeof(TextTemplateManagementApplicationModule),
    typeof(TextTemplateManagementMongoDbModule),

    // Language Management module packages
    typeof(LanguageManagementBlazorServerModule),
    typeof(LanguageManagementHttpApiModule),
    typeof(LanguageManagementApplicationModule),
    typeof(LanguageManagementMongoDbModule),

    // GDPR module packages
    typeof(JellogGdprBlazorServerModule),
    typeof(JellogGdprHttpApiModule),
    typeof(JellogGdprApplicationModule),
    typeof(JellogGdprMongoDbModule),

    // Blob Storing
    typeof(BlobStoringDatabaseMongoDbModule)
)]
public class MyProjectNameModule : JellogModule
{
    /* Single point to enable/disable multi-tenancy */
    private const bool IsMultiTenant = true;

    public override void PreConfigureServices(ServiceConfigurationContext context)
    {
        context.Services.PreConfigure<JellogMvcDataAnnotationsLocalizationOptions>(options =>
        {
            options.AddAssemblyResource(
                typeof(MyProjectNameResource)
            );
        });
    }

    public override void ConfigureServices(ServiceConfigurationContext context)
    {
        var hostingEnvironment = context.Services.GetHostingEnvironment();
        var configuration = context.Services.GetConfiguration();

        if (hostingEnvironment.IsDevelopment())
        {
            context.Services.Replace(ServiceDescriptor.Singleton<IEmailSender, NullEmailSender>());
        }

        ConfigureBundles();
        ConfigureBlazorise(context);
        ConfigureRouter(context);
        ConfigureMultiTenancy();
        ConfigureMenu(context);
        ConfigureUrls(configuration);
        ConfigureAutoMapper(context);
        ConfigureSwagger(context.Services);
        ConfigureAutoApiControllers();
        ConfigureLocalization();
        ConfigureAuthentication(context.Services, configuration);
        ConfigureVirtualFiles(hostingEnvironment);
        ConfigureMongoDB(context);
    }

    private void ConfigureBundles()
    {
        Configure<JellogBundlingOptions>(options =>
        {
            // MVC UI
            options.StyleBundles.Configure(
                LeptonThemeBundles.Styles.Global,
                bundle =>
                {
                    bundle.AddFiles("/global-styles.css");
                }
            );

            //BLAZOR UI
            options.StyleBundles.Configure(
                BlazorLeptonThemeBundles.Styles.Global,
                bundle =>
                {
                    bundle.AddFiles("/blazor-global-styles.css");
                    //You can remove the following line if you don't use Blazor CSS isolation for components
                    bundle.AddFiles("/MyCompanyName.MyProjectName.Blazor.Server.styles.css");
                }
            );
        });
    }

    private void ConfigureBlazorise(ServiceConfigurationContext context)
    {
        context.Services
            .AddBootstrap5Providers()
            .AddFontAwesomeIcons();
    }

    private void ConfigureRouter(ServiceConfigurationContext context)
    {
        Configure<JellogRouterOptions>(options =>
        {
            options.AppAssembly = typeof(MyProjectNameModule).Assembly;
        });
    }

    private void ConfigureMultiTenancy()
    {
        Configure<JellogMultiTenancyOptions>(options =>
        {
            options.IsEnabled = IsMultiTenant;
        });
    }

    private void ConfigureMenu(ServiceConfigurationContext context)
    {
        Configure<JellogNavigationOptions>(options =>
        {
            options.MenuContributors.Add(new MyProjectNameMenuContributor());
        });
    }

    private void ConfigureUrls(IConfiguration configuration)
    {
        Configure<AppUrlOptions>(options =>
        {
            options.Applications["MVC"].RootUrl = configuration["App:SelfUrl"];
            options.RedirectAllowedUrls.AddRange(configuration["App:RedirectAllowedUrls"].Split(','));
        });
    }

    private void ConfigureAuthentication(IServiceCollection services, IConfiguration configuration)
    {
        services.AddAuthentication()
            .AddJwtBearer(options =>
            {
                options.Authority = configuration["AuthServer:Authority"];
                options.RequireHttpsMetadata = Convert.ToBoolean(configuration["AuthServer:RequireHttpsMetadata"]);
                options.Audience = "MyProjectName";
            });

        services.ForwardIdentityAuthenticationForBearer();
    }

    private void ConfigureVirtualFiles(IWebHostEnvironment hostingEnvironment)
    {
        Configure<JellogVirtualFileSystemOptions>(options =>
        {
            options.FileSets.AddEmbedded<MyProjectNameModule>();
            if (hostingEnvironment.IsDevelopment())
            {
                /* Using physical files in development, so we don't need to recompile on changes */
                options.FileSets.ReplaceEmbeddedByPhysical<MyProjectNameModule>(hostingEnvironment.ContentRootPath);
            }
        });
    }

    private void ConfigureLocalization()
    {
        Configure<JellogLocalizationOptions>(options =>
        {
            options.Resources
                .Add<MyProjectNameResource>("en")
                .AddBaseTypes(typeof(JellogValidationResource))
                .AddVirtualJson("/Localization/MyProjectName");

            options.DefaultResourceType = typeof(MyProjectNameResource);

            options.Languages.Add(new LanguageInfo("en", "en", "English"));
            options.Languages.Add(new LanguageInfo("tr", "tr", "Türkçe"));
            options.Languages.Add(new LanguageInfo("ar", "ar", "العربية"));
            options.Languages.Add(new LanguageInfo("cs", "cs", "Čeština"));
            options.Languages.Add(new LanguageInfo("en-GB", "en-GB", "English (UK)"));
            options.Languages.Add(new LanguageInfo("hu", "hu", "Magyar"));
            options.Languages.Add(new LanguageInfo("fi", "fi", "Finnish"));
            options.Languages.Add(new LanguageInfo("fr", "fr", "Français"));
            options.Languages.Add(new LanguageInfo("hi", "hi", "Hindi", "in"));
            options.Languages.Add(new LanguageInfo("is", "is", "Icelandic", "is"));
            options.Languages.Add(new LanguageInfo("it", "it", "Italiano", "it"));
            options.Languages.Add(new LanguageInfo("pt-BR", "pt-BR", "Português"));
            options.Languages.Add(new LanguageInfo("ro-RO", "ro-RO", "Română"));
            options.Languages.Add(new LanguageInfo("ru", "ru", "Русский", "ru"));
            options.Languages.Add(new LanguageInfo("sk", "sk", "Slovak"));
            options.Languages.Add(new LanguageInfo("zh-Hans", "zh-Hans", "简体中文"));
            options.Languages.Add(new LanguageInfo("zh-Hant", "zh-Hant", "繁體中文"));
            options.Languages.Add(new LanguageInfo("de-DE", "de-DE", "Deutsch", "de"));
            options.Languages.Add(new LanguageInfo("es", "es", "Español"));
        });

        Configure<JellogExceptionLocalizationOptions>(options =>
        {
            options.MapCodeNamespace("MyProjectName", typeof(MyProjectNameResource));
        });
    }

    private void ConfigureAutoApiControllers()
    {
        Configure<JellogAspNetCoreMvcOptions>(options =>
        {
            options.ConventionalControllers.Create(typeof(MyProjectNameModule).Assembly);
        });
    }

    private void ConfigureSwagger(IServiceCollection services)
    {
        services.AddJellogSwaggerGen(
            options =>
            {
                options.SwaggerDoc("v1", new OpenApiInfo { Title = "MyProjectName API", Version = "v1" });
                options.DocInclusionPredicate((docName, description) => true);
                options.CustomSchemaIds(type => type.FullName);
            }
        );
    }

    private void ConfigureAutoMapper(ServiceConfigurationContext context)
    {
        context.Services.AddAutoMapperObjectMapper<MyProjectNameModule>();
        Configure<JellogAutoMapperOptions>(options =>
        {
            /* Uncomment `validate: true` if you want to enable the Configuration Validation feature.
             * See AutoMapper's documentation to learn what it is:
             * https://docs.automapper.org/en/stable/Configuration-validation.html
             */
            options.AddMaps<MyProjectNameModule>(/* validate: true */);
        });
    }

    private void ConfigureMongoDB(ServiceConfigurationContext context)
    {
        context.Services.AddMongoDbContext<MyProjectNameDbContext>(options =>
        {
            options.AddDefaultRepositories();
        });

        Configure<JellogUnitOfWorkDefaultOptions>(options =>
        {
            options.TransactionBehavior = UnitOfWorkTransactionBehavior.Disabled;
        });
    }

    public override void OnApplicationInitialization(ApplicationInitializationContext context)
    {
        var app = context.GetApplicationBuilder();
        var env = context.GetEnvironment();

        if (env.IsDevelopment())
        {
            app.UseDeveloperExceptionPage();
        }

        app.UseJellogRequestLocalization();

        if (!env.IsDevelopment())
        {
            app.UseErrorPage();
        }

        app.UseCorrelationId();
        app.UseJellogSecurityHeaders();
        app.UseStaticFiles();
        app.UseRouting();
        app.UseAuthentication();
        app.UseJwtTokenMiddleware();

        if (IsMultiTenant)
        {
            app.UseMultiTenancy();
        }

        app.UseUnitOfWork();
        app.UseIdentityServer();
        app.UseAuthorization();

        app.UseSwagger();
        app.UseJellogSwaggerUI(options =>
        {
            options.SwaggerEndpoint("/swagger/v1/swagger.json", "MyProjectName API");
        });

        app.UseAuditing();
        app.UseJellogSerilogEnrichers();
        app.UseConfiguredEndpoints();
    }
}
