namespace MyCompanyName.MyProjectName.Blazor.Server.Permissions;

public static class MyProjectNamePermissions
{
    public const string GroupName = "MyProjectName";

    //Add your own permission names. Example:
    //public const string MyPermission1 = GroupName + ".MyPermission1";
}
