﻿namespace MyCompanyName.MyProjectName.Menus;

public class MyProjectNameMenus
{
    private const string Prefix = "MyProjectName";

    public const string Home = Prefix + ".Home";
}
