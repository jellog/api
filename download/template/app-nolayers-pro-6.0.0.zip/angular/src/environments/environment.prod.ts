import { Environment } from '@jellog/ng.core';

const baseUrl = 'http://localhost:4200';

const oAuthConfig = {
  issuer: 'https://localhost:44300/',
  redirectUri: baseUrl,
  clientId: 'MyProjectName_App',
  responseType: 'code',
  scope: 'offline_access MyProjectName',
  requireHttps: true,
};

export const environment = {
  production: true,
  application: {
    baseUrl,
    name: 'MyProjectName',
  },
  oAuthConfig,
  apis: {
    default: {
      url: 'https://localhost:44300',
      rootNamespace: 'MyCompanyName.MyProjectName',
    },
    JellogAccountPublic: {
      url: oAuthConfig.issuer,
      rootNamespace: 'JellogAccountPublic',
    },
  },
} as Environment;
