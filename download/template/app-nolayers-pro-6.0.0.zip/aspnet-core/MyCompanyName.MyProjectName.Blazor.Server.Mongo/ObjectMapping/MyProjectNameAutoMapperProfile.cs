﻿using AutoMapper;

namespace MyCompanyName.MyProjectName.ObjectMapping;

public class MyProjectNameAutoMapperProfile : Profile
{
    public MyProjectNameAutoMapperProfile()
    {
        /* Create your AutoMapper object mappings here */
    }
}
