﻿using Microsoft.EntityFrameworkCore;
using DataGap.Jellog.AuditLogging.EntityFrameworkCore;
using DataGap.Jellog.BackgroundJobs.EntityFrameworkCore;
using DataGap.Jellog.BlobStoring.Database.EntityFrameworkCore;
using DataGap.Jellog.EntityFrameworkCore;
using DataGap.Jellog.FeatureManagement.EntityFrameworkCore;
using DataGap.Jellog.Gdpr;
using DataGap.Jellog.Identity.EntityFrameworkCore;
using DataGap.Jellog.LanguageManagement.EntityFrameworkCore;
using DataGap.Jellog.OpenIddict.EntityFrameworkCore;
using DataGap.Jellog.PermissionManagement.EntityFrameworkCore;
using DataGap.Jellog.SettingManagement.EntityFrameworkCore;
using DataGap.Jellog.TextTemplateManagement.EntityFrameworkCore;
using DataGap.Saas.EntityFrameworkCore;

namespace MyCompanyName.MyProjectName.Data;

public class MyProjectNameDbContext : JellogDbContext<MyProjectNameDbContext>
{
    public const string DbTablePrefix = "App";
    public const string DbSchema = null;

    public MyProjectNameDbContext(DbContextOptions<MyProjectNameDbContext> options)
        : base(options)
    {
    }

    protected override void OnModelCreating(ModelBuilder builder)
    {
        base.OnModelCreating(builder);

        /* Include modules to your migration db context */

        builder.ConfigureSettingManagement();
        builder.ConfigureBackgroundJobs();
        builder.ConfigureAuditLogging();
        builder.ConfigureIdentityPro();
        builder.ConfigureOpenIddict();
        builder.ConfigureFeatureManagement();
        builder.ConfigurePermissionManagement();
        builder.ConfigureLanguageManagement();
        builder.ConfigureSaas();
        builder.ConfigureTextTemplateManagement();
        builder.ConfigureBlobStoring();
        builder.ConfigureGdpr();

        /* Configure your own entities here */
    }
}
