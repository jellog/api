import { Environment } from '@jellog/ng.core';

const baseUrl = 'http://localhost:4200';

const oAuthConfig = {
  issuer: 'https://localhost:44305',
  redirectUri: baseUrl,
  clientId: 'MyProjectName_App',
  responseType: 'code',
  scope: 'offline_access MyProjectName',
  requireHttps: true,
};

export const environment = {
  production: false,
  application: {
    baseUrl,
    name: 'MyProjectName',
  },
  oAuthConfig,
  apis: {
    default: {
      url: 'https://localhost:44305',
      rootNamespace: 'MyCompanyName.MyProjectName',
    },
    JellogAccountPublic: {
      url: oAuthConfig.issuer,
      rootNamespace: 'JellogAccountPublic',
    },
  },
} as Environment;
