﻿using DataGap.Jellog.Account.Public.Web.Impersonation;

namespace MyCompanyName.MyProjectName.Web.Controllers;

public class AccountController : JellogAccountImpersonationChallengeAccountController
{

}
