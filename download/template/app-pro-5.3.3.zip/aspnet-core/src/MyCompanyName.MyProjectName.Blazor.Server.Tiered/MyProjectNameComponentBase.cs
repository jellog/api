﻿using MyCompanyName.MyProjectName.Localization;
using DataGap.Jellog.AspNetCore.Components;

namespace MyCompanyName.MyProjectName.Blazor.Server.Tiered;

public abstract class MyProjectNameComponentBase : JellogComponentBase
{
    protected MyProjectNameComponentBase()
    {
        LocalizationResource = typeof(MyProjectNameResource);
    }
}
