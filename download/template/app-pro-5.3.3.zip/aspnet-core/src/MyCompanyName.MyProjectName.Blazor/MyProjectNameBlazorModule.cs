﻿using System;
using System.Net.Http;
using Blazorise.Bootstrap5;
using Blazorise.Icons.FontAwesome;
using IdentityModel;
using Microsoft.AspNetCore.Components.WebAssembly.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using MyCompanyName.MyProjectName.Blazor.Components.Layout;
using MyCompanyName.MyProjectName.Blazor.Navigation;
using DataGap.Jellog.Account.Pro.Admin.Blazor.WebAssembly;
using DataGap.Jellog.AspNetCore.Components.Web.LeptonTheme;
using DataGap.Jellog.AspNetCore.Components.Web.LeptonTheme.Components;
using DataGap.Jellog.AspNetCore.Components.Web.Theming.Routing;
using DataGap.Jellog.AspNetCore.Components.WebAssembly.LeptonTheme;
using DataGap.Jellog.AuditLogging.Blazor.WebAssembly;
using DataGap.Jellog.Autofac.WebAssembly;
using DataGap.Jellog.AutoMapper;
using DataGap.Jellog.Gdpr.Blazor.WebAssembly;
using DataGap.Jellog.Identity.Pro.Blazor.Server.WebAssembly;
using DataGap.Jellog.IdentityServer.Blazor.WebAssembly;
using DataGap.Jellog.Modularity;
using DataGap.Jellog.UI.Navigation;
using DataGap.Jellog.LanguageManagement.Blazor.WebAssembly;
using DataGap.Jellog.LeptonTheme.Management.Blazor.WebAssembly;
using DataGap.Jellog.SettingManagement.Blazor.WebAssembly;
using DataGap.Jellog.TextTemplateManagement.Blazor.WebAssembly;
using DataGap.Saas.Host.Blazor.WebAssembly;

namespace MyCompanyName.MyProjectName.Blazor;

[DependsOn(
    typeof(JellogAutofacWebAssemblyModule),
    typeof(MyProjectNameHttpApiClientModule),
    typeof(JellogAspNetCoreComponentsWebAssemblyLeptonThemeModule),
    typeof(JellogIdentityProBlazorWebAssemblyModule),
    typeof(SaasHostBlazorWebAssemblyModule),
    typeof(JellogSettingManagementBlazorWebAssemblyModule),
    typeof(LeptonThemeManagementBlazorWebAssemblyModule),
    typeof(JellogAccountAdminBlazorWebAssemblyModule),
    typeof(JellogAuditLoggingBlazorWebAssemblyModule),
    typeof(TextTemplateManagementBlazorWebAssemblyModule),
    typeof(LanguageManagementBlazorWebAssemblyModule),
    typeof(JellogIdentityServerBlazorWebAssemblyModule),
    typeof(JellogGdprBlazorWebAssemblyModule)
)]
public class MyProjectNameBlazorModule : JellogModule
{
    public override void ConfigureServices(ServiceConfigurationContext context)
    {
        var environment = context.Services.GetSingletonInstance<IWebAssemblyHostEnvironment>();
        var builder = context.Services.GetSingletonInstance<WebAssemblyHostBuilder>();

        ConfigureAuthentication(builder);
        ConfigureHttpClient(context, environment);
        ConfigureBlazorise(context);
        ConfigureRouter(context);
        ConfigureUI(builder);
        ConfigureMenu(context);
        ConfigureAutoMapper(context);
        ConfigureLeptonTheme(context);
    }

    private void ConfigureRouter(ServiceConfigurationContext context)
    {
        Configure<JellogRouterOptions>(options =>
        {
            options.AppAssembly = typeof(MyProjectNameBlazorModule).Assembly;
        });
    }

    private void ConfigureMenu(ServiceConfigurationContext context)
    {
        Configure<JellogNavigationOptions>(options =>
        {
            options.MenuContributors.Add(new MyProjectNameMenuContributor(context.Services.GetConfiguration()));
        });
    }

    private void ConfigureBlazorise(ServiceConfigurationContext context)
    {
        context.Services
            .AddBootstrap5Providers()
            .AddFontAwesomeIcons();
    }

    private static void ConfigureAuthentication(WebAssemblyHostBuilder builder)
    {
        builder.Services.AddOidcAuthentication(options =>
        {
            builder.Configuration.Bind("AuthServer", options.ProviderOptions);
            options.UserOptions.RoleClaim = JwtClaimTypes.Role;
            options.ProviderOptions.DefaultScopes.Add("MyProjectName");
            options.ProviderOptions.DefaultScopes.Add("role");
            options.ProviderOptions.DefaultScopes.Add("email");
            options.ProviderOptions.DefaultScopes.Add("phone");
        });
    }

    private static void ConfigureUI(WebAssemblyHostBuilder builder)
    {
        builder.RootComponents.Add<App>("#ApplicationContainer");
    }

    private static void ConfigureHttpClient(ServiceConfigurationContext context, IWebAssemblyHostEnvironment environment)
    {
        context.Services.AddTransient(sp => new HttpClient
        {
            BaseAddress = new Uri(environment.BaseAddress)
        });
    }

    private void ConfigureAutoMapper(ServiceConfigurationContext context)
    {
        Configure<JellogAutoMapperOptions>(options =>
        {
            options.AddMaps<MyProjectNameBlazorModule>();
        });
    }

    private void ConfigureLeptonTheme(ServiceConfigurationContext context)
    {
        Configure<LeptonThemeOptions>(options =>
        {
            options.FooterComponent = typeof(MainFooterComponent);
        });
    }
}
