﻿using DataGap.Jellog.GlobalFeatures;
using DataGap.Jellog.Threading;

namespace MyCompanyName.MyProjectName;

public static class MyProjectNameGlobalFeatureConfigurator
{
    private static readonly OneTimeRunner OneTimeRunner = new OneTimeRunner();

    public static void Configure()
    {
        OneTimeRunner.Run(() =>
        {
           /* You can configure (enable/disable) global features of the used modules here.
            * Please refer to the documentation to learn more about the Global Features System:
            * https://docs.jellog.io/en/jellog/latest/Global-Features
            */
            //<TEMPLATE-REMOVE IF-NOT='CMS-KIT'>
            GlobalFeatureManager.Instance.Modules.CmsKit(cmsKit =>
            {
                cmsKit.EnableAll();
            });

            GlobalFeatureManager.Instance.Modules.CmsKitPro(cmsKitPro =>
            {
                cmsKitPro.EnableAll();
            });
            //</TEMPLATE-REMOVE>
        });
    }
}
