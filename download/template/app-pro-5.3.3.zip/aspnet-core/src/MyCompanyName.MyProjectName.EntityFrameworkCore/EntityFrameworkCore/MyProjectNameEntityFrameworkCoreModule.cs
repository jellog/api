using System;
using Microsoft.Extensions.DependencyInjection;
using DataGap.Jellog.AuditLogging.EntityFrameworkCore;
using DataGap.Jellog.BackgroundJobs.EntityFrameworkCore;
using DataGap.Jellog.EntityFrameworkCore;
using DataGap.Jellog.EntityFrameworkCore.SqlServer;
using DataGap.Jellog.FeatureManagement.EntityFrameworkCore;
using DataGap.Jellog.Identity.EntityFrameworkCore;
using DataGap.Jellog.IdentityServer.EntityFrameworkCore;
using DataGap.Jellog.LanguageManagement.EntityFrameworkCore;
using DataGap.Jellog.Modularity;
using DataGap.Jellog.PermissionManagement.EntityFrameworkCore;
using DataGap.Jellog.SettingManagement.EntityFrameworkCore;
using DataGap.Jellog.TextTemplateManagement.EntityFrameworkCore;
using DataGap.Saas.EntityFrameworkCore;
using DataGap.Jellog.BlobStoring.Database.EntityFrameworkCore;
using DataGap.Jellog.Gdpr;
//<TEMPLATE-REMOVE IF-NOT='CMS-KIT'>
using DataGap.CmsKit.EntityFrameworkCore;
//</TEMPLATE-REMOVE>

namespace MyCompanyName.MyProjectName.EntityFrameworkCore;

[DependsOn(
    typeof(MyProjectNameDomainModule),
    typeof(JellogIdentityProEntityFrameworkCoreModule),
    typeof(JellogIdentityServerEntityFrameworkCoreModule),
    typeof(JellogPermissionManagementEntityFrameworkCoreModule),
    typeof(JellogSettingManagementEntityFrameworkCoreModule),
    typeof(JellogEntityFrameworkCoreSqlServerModule),
    typeof(JellogBackgroundJobsEntityFrameworkCoreModule),
    typeof(JellogAuditLoggingEntityFrameworkCoreModule),
    typeof(JellogFeatureManagementEntityFrameworkCoreModule),
    typeof(LanguageManagementEntityFrameworkCoreModule),
    typeof(SaasEntityFrameworkCoreModule),
    typeof(TextTemplateManagementEntityFrameworkCoreModule),
    typeof(JellogGdprEntityFrameworkCoreModule),
    //<TEMPLATE-REMOVE IF-NOT='CMS-KIT'>
    typeof(CmsKitProEntityFrameworkCoreModule),
    //</TEMPLATE-REMOVE>
    typeof(BlobStoringDatabaseEntityFrameworkCoreModule)
    )]
public class MyProjectNameEntityFrameworkCoreModule : JellogModule
{
    public override void PreConfigureServices(ServiceConfigurationContext context)
    {
//<TEMPLATE-REMOVE IF-NOT='dbms:PostgreSQL'>
        // https://www.npgsql.org/efcore/release-notes/6.0.html#opting-out-of-the-new-timestamp-mapping-logic
        AppContext.SetSwitch("Npgsql.EnableLegacyTimestampBehavior", true);

//</TEMPLATE-REMOVE>
        MyProjectNameEfCoreEntityExtensionMappings.Configure();
    }

    public override void ConfigureServices(ServiceConfigurationContext context)
    {
        context.Services.AddJellogDbContext<MyProjectNameDbContext>(options =>
        {
                /* Remove "includeAllEntities: true" to create
                 * default repositories only for aggregate roots */
            options.AddDefaultRepositories(includeAllEntities: true);
        });

        Configure<JellogDbContextOptions>(options =>
        {
                /* The main point to change your DBMS.
                 * See also MyProjectNameDbContextFactory for EF Core tooling. */
            options.UseSqlServer();
        });
    }
}
