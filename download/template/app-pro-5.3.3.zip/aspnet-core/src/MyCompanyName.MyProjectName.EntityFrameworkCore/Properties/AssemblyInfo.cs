﻿using System.Runtime.CompilerServices;
[assembly:InternalsVisibleToAttribute("MyCompanyName.MyProjectName.EntityFrameworkCore.Tests")]
