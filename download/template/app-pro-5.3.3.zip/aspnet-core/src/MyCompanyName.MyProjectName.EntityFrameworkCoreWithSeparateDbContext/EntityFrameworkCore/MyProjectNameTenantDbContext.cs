﻿using Microsoft.EntityFrameworkCore;
using DataGap.Jellog.Data;
using DataGap.Jellog.MultiTenancy;

namespace MyCompanyName.MyProjectName.EntityFrameworkCore;

[ConnectionStringName("Default")]
public class MyProjectNameTenantDbContext : MyProjectNameDbContextBase<MyProjectNameTenantDbContext>
{
    public MyProjectNameTenantDbContext(DbContextOptions<MyProjectNameTenantDbContext> options)
        : base(options)
    {
    }

    protected override void OnModelCreating(ModelBuilder builder)
    {
        builder.SetMultiTenancySide(MultiTenancySides.Tenant);

        base.OnModelCreating(builder);
    }
}
