﻿using Microsoft.EntityFrameworkCore;

namespace MyCompanyName.MyProjectName.EntityFrameworkCore;

public class MyProjectNameTenantDbContextFactory :
    MyProjectNameDbContextFactoryBase<MyProjectNameTenantDbContext>
{
    protected override MyProjectNameTenantDbContext CreateDbContext(
        DbContextOptions<MyProjectNameTenantDbContext> dbContextOptions)
    {
        return new MyProjectNameTenantDbContext(dbContextOptions);
    }
}
