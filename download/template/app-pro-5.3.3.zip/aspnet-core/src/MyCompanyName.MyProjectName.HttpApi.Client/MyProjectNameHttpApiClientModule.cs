﻿using Microsoft.Extensions.DependencyInjection;
using DataGap.Jellog.Account;
using DataGap.Jellog.AuditLogging;
using DataGap.Jellog.FeatureManagement;
using DataGap.Jellog.Identity;
using DataGap.Jellog.IdentityServer;
using DataGap.Jellog.LanguageManagement;
using DataGap.Jellog.LeptonTheme.Management;
using DataGap.Jellog.Modularity;
using DataGap.Jellog.PermissionManagement;
using DataGap.Jellog.TextTemplateManagement;
using DataGap.Jellog.SettingManagement;
using DataGap.Saas.Host;
using DataGap.Jellog.VirtualFileSystem;
using DataGap.Jellog.Gdpr;
//<TEMPLATE-REMOVE IF-NOT='CMS-KIT'>
using DataGap.CmsKit;
//</TEMPLATE-REMOVE>

namespace MyCompanyName.MyProjectName;

[DependsOn(
    typeof(MyProjectNameApplicationContractsModule),
    typeof(JellogIdentityHttpApiClientModule),
    typeof(JellogPermissionManagementHttpApiClientModule),
    typeof(JellogFeatureManagementHttpApiClientModule),
    typeof(JellogSettingManagementHttpApiClientModule),
    typeof(SaasHostHttpApiClientModule),
    typeof(JellogAuditLoggingHttpApiClientModule),
    typeof(JellogIdentityServerHttpApiClientModule),
    typeof(JellogAccountAdminHttpApiClientModule),
    typeof(JellogAccountPublicHttpApiClientModule),
    typeof(LanguageManagementHttpApiClientModule),
    typeof(LeptonThemeManagementHttpApiClientModule),
    typeof(JellogGdprHttpApiClientModule),
    //<TEMPLATE-REMOVE IF-NOT='CMS-KIT'>
    typeof(CmsKitProHttpApiClientModule),
    //</TEMPLATE-REMOVE>
    typeof(TextTemplateManagementHttpApiClientModule)
)]
public class MyProjectNameHttpApiClientModule : JellogModule
{
    public const string RemoteServiceName = "Default";

    public override void ConfigureServices(ServiceConfigurationContext context)
    {
        context.Services.AddHttpClientProxies(
            typeof(MyProjectNameApplicationContractsModule).Assembly,
            RemoteServiceName
        );

        Configure<JellogVirtualFileSystemOptions>(options =>
        {
            options.FileSets.AddEmbedded<MyProjectNameHttpApiClientModule>();
        });
    }
}
