module.exports = {
    aliases: {

    },
    clean: [

    ],
    mappings: {

    }
};
