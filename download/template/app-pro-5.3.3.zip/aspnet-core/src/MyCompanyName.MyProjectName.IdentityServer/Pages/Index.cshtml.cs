using System.Collections.Generic;
using System.Threading.Tasks;
using IdentityServer4.Stores;
using Microsoft.AspNetCore.Mvc;
using DataGap.Jellog.AspNetCore.Mvc.UI.RazorPages;
using DataGap.Jellog.IdentityServer.Clients;

namespace MyCompanyName.MyProjectName.Pages;

public class IndexModel : JellogPageModel
{
    public List<Client> Clients { get; protected set; }

    // TODO: Consider using IClientStore here.
    protected IClientRepository ClientRepository { get; }

    public IndexModel(IClientRepository clientRepository)
    {
        ClientRepository = clientRepository;
    }

    public async Task OnGetAsync()
    {
        Clients = await ClientRepository.GetListAsync(includeDetails: true);
    }
}
