﻿using System.Runtime.CompilerServices;
[assembly:InternalsVisibleToAttribute("MyCompanyName.MyProjectName.MongoDB.Tests")]
