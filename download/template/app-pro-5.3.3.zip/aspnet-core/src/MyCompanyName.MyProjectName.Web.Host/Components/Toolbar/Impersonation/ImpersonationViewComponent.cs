﻿using Microsoft.AspNetCore.Mvc;
using DataGap.Jellog.AspNetCore.Mvc;

namespace MyCompanyName.MyProjectName.Web.Components.Toolbar.Impersonation;

public class ImpersonationViewComponent : JellogViewComponent
{
    public virtual IViewComponentResult Invoke()
    {
        return View("~/Components/Toolbar/Impersonation/Default.cshtml");
    }
}
