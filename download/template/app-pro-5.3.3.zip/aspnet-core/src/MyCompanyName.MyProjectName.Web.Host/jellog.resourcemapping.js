module.exports = {
    aliases: {
    },
    mappings: {
    }
};