﻿namespace MyCompanyName.MyProjectName.Web.Public.Menus;

public class MyProjectNamePublicMenus
{
    private const string Prefix = "MyProjectName.Public";

    public const string HomePage = Prefix + ".HomePage";

    public const string ArticleSample = Prefix + ".SampleArticle";

    public const string ContactUs = Prefix + ".ContactUs";
}
