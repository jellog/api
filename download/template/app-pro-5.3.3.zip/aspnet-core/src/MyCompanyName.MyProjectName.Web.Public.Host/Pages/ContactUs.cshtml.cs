﻿namespace MyCompanyName.MyProjectName.Web.Public.Pages;

public class ContactUsModel : MyProjectNamePublicPageModel
{
    public void OnGet()
    {

    }
}
