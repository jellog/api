﻿namespace MyCompanyName.MyProjectName;

public abstract class MyProjectNameApplicationTestBase : MyProjectNameTestBase<MyProjectNameApplicationTestModule>
{

}
