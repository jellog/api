﻿using MyCompanyName.MyProjectName.MongoDB;
using Xunit;

namespace MyCompanyName.MyProjectName.MongoDB;

public class MyProjectNameMongoDbCollectionFixtureBase : ICollectionFixture<MyProjectNameMongoDbFixture>
{

}
