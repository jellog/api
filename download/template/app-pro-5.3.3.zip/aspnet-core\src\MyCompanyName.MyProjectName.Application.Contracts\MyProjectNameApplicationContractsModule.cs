﻿using DataGap.Jellog.Account;
using DataGap.Jellog.AuditLogging;
using DataGap.Jellog.FeatureManagement;
using DataGap.Jellog.Identity;
using DataGap.Jellog.IdentityServer;
using DataGap.Jellog.LanguageManagement;
using DataGap.Jellog.LeptonTheme.Management;
using DataGap.Jellog.Modularity;
using DataGap.Jellog.PermissionManagement;
using DataGap.Jellog.SettingManagement;
using DataGap.Jellog.TextTemplateManagement;
using DataGap.Saas.Host;
using DataGap.Jellog.Gdpr;
//<TEMPLATE-REMOVE IF-NOT='CMS-KIT'>
using DataGap.CmsKit;
//</TEMPLATE-REMOVE>

namespace MyCompanyName.MyProjectName;

[DependsOn(
    typeof(MyProjectNameDomainSharedModule),
    typeof(JellogFeatureManagementApplicationContractsModule),
    typeof(JellogIdentityApplicationContractsModule),
    typeof(JellogPermissionManagementApplicationContractsModule),
    typeof(JellogSettingManagementApplicationContractsModule),
    typeof(SaasHostApplicationContractsModule),
    typeof(JellogAuditLoggingApplicationContractsModule),
    typeof(JellogIdentityServerApplicationContractsModule),
    typeof(JellogAccountPublicApplicationContractsModule),
    typeof(JellogAccountAdminApplicationContractsModule),
    typeof(LanguageManagementApplicationContractsModule),
    typeof(LeptonThemeManagementApplicationContractsModule),
    typeof(JellogGdprApplicationContractsModule),
    //<TEMPLATE-REMOVE IF-NOT='CMS-KIT'>
    typeof(CmsKitProApplicationContractsModule),
    //</TEMPLATE-REMOVE>
    typeof(TextTemplateManagementApplicationContractsModule)
)]
public class MyProjectNameApplicationContractsModule : JellogModule
{
    public override void PreConfigureServices(ServiceConfigurationContext context)
    {
        MyProjectNameDtoExtensions.Configure();
    }
}
