﻿using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.DependencyInjection.Extensions;
using DataGap.Jellog.Account;
using DataGap.Jellog.AuditLogging;
using DataGap.Jellog.AutoMapper;
using DataGap.Jellog.Emailing;
using DataGap.Jellog.FeatureManagement;
using DataGap.Jellog.Gdpr;
using DataGap.Jellog.Identity;
using DataGap.Jellog.IdentityServer;
using DataGap.Jellog.LanguageManagement;
using DataGap.Jellog.LeptonTheme.Management;
using DataGap.Jellog.Modularity;
using DataGap.Jellog.PermissionManagement;
using DataGap.Jellog.SettingManagement;
using DataGap.Jellog.TextTemplateManagement;
using DataGap.Saas.Host;
//<TEMPLATE-REMOVE IF-NOT='CMS-KIT'>
using DataGap.CmsKit;
//</TEMPLATE-REMOVE>

namespace MyCompanyName.MyProjectName;

[DependsOn(
    typeof(MyProjectNameDomainModule),
    typeof(MyProjectNameApplicationContractsModule),
    typeof(JellogIdentityApplicationModule),
    typeof(JellogPermissionManagementApplicationModule),
    typeof(JellogFeatureManagementApplicationModule),
    typeof(JellogSettingManagementApplicationModule),
    typeof(SaasHostApplicationModule),
    typeof(JellogAuditLoggingApplicationModule),
    typeof(JellogIdentityServerApplicationModule),
    typeof(JellogAccountPublicApplicationModule),
    typeof(JellogAccountAdminApplicationModule),
    typeof(LanguageManagementApplicationModule),
    typeof(LeptonThemeManagementApplicationModule),
    typeof(JellogGdprApplicationModule),
    //<TEMPLATE-REMOVE IF-NOT='CMS-KIT'>
    typeof(CmsKitProApplicationModule),
    //</TEMPLATE-REMOVE>
    typeof(TextTemplateManagementApplicationModule)
    )]
public class MyProjectNameApplicationModule : JellogModule
{
    public override void ConfigureServices(ServiceConfigurationContext context)
    {
        Configure<JellogAutoMapperOptions>(options =>
        {
            options.AddMaps<MyProjectNameApplicationModule>();
        });
    }
}
