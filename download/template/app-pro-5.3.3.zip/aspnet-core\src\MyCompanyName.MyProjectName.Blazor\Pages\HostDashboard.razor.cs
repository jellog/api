﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Components;
using DataGap.Jellog.AuditLogging;
using DataGap.Jellog.AuditLogging.Blazor.Pages.Shared.AverageExecutionDurationPerDayWidget;
using DataGap.Jellog.AuditLogging.Blazor.Pages.Shared.ErrorRateWidget;
using DataGap.Jellog.Authorization.Permissions;
using DataGap.Jellog.BlazoriseUI;
using DataGap.Jellog.Timing;
using DataGap.Saas.Host;
using DataGap.Saas.Host.Blazor.Pages.Shared.Components.SaasEditionPercentageWidget;
using DataGap.Saas.Host.Blazor.Pages.Shared.Components.SaasLatestTenantsWidget;

namespace MyCompanyName.MyProjectName.Blazor.Pages;

public partial class HostDashboard
{
    [Inject]
    public IPermissionChecker PermissionChecker { get; set; }
    
    [Inject]
    public IClock Clock { get; set; }
    
    protected List<BreadcrumbItem> BreadcrumbItems = new();

    protected AuditLoggingErrorRateWidgetComponent ErrorRateWidgetComponent;
    
    protected AuditLoggingAverageExecutionDurationPerDayWidgetComponent AverageExecutionDurationPerDayWidgetComponent;
    
    protected SaasEditionPercentageWidgetComponent SaasEditionPercentageWidgetComponent;
    
    protected SaasLatestTenantsWidgetComponent SaasLatestTenantsWidgetComponent;
    
    protected DateTime StartDate { get; set; }
    
    protected DateTime EndDate { get; set; }
    
    protected bool HasAuditLoggingPermission { get; set; }
    
    protected bool HasSaasPermission { get; set; }
    
    protected async override Task OnInitializedAsync()
    {
        StartDate = Clock.Now.AddMonths(-1).Date;
        EndDate = Clock.Now.Date;
        HasAuditLoggingPermission = await PermissionChecker.IsGrantedAsync(JellogAuditLoggingPermissions.AuditLogs.Default);
        HasSaasPermission = await PermissionChecker.IsGrantedAsync(SaasHostPermissions.Tenants.Default);
        await SetBreadcrumbItemsAsync();
    }

    protected virtual async Task RefreshAsync()
    {
        if (HasAuditLoggingPermission)
        {
            await ErrorRateWidgetComponent.RefreshAsync();
            await AverageExecutionDurationPerDayWidgetComponent.RefreshAsync();
        }

        if (HasSaasPermission)
        {
            await SaasEditionPercentageWidgetComponent.RefreshAsync();
        }
    }

    protected virtual ValueTask SetBreadcrumbItemsAsync()
    {
        BreadcrumbItems.Add(new BreadcrumbItem(L["Dashboard"]));
        return ValueTask.CompletedTask;
    }
}