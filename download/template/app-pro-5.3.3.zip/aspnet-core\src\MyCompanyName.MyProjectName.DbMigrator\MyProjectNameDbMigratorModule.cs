﻿using MyCompanyName.MyProjectName.EntityFrameworkCore;
using DataGap.Jellog.Autofac;
using DataGap.Jellog.BackgroundJobs;
using DataGap.Jellog.Modularity;

namespace MyCompanyName.MyProjectName.DbMigrator;

[DependsOn(
    typeof(JellogAutofacModule),
    typeof(MyProjectNameEntityFrameworkCoreModule),
    typeof(MyProjectNameApplicationContractsModule)
)]
public class MyProjectNameDbMigratorModule : JellogModule
{
    public override void ConfigureServices(ServiceConfigurationContext context)
    {
        Configure<JellogBackgroundJobOptions>(options =>
        {
            options.IsJobExecutionEnabled = false;
        });
    }
}
