﻿using Microsoft.EntityFrameworkCore;

namespace MyCompanyName.MyProjectName.EntityFrameworkCore;

public class MyProjectNameDbContextFactory :
    MyProjectNameDbContextFactoryBase<MyProjectNameDbContext>
{
    protected override MyProjectNameDbContext CreateDbContext(
        DbContextOptions<MyProjectNameDbContext> dbContextOptions)
    {
        return new MyProjectNameDbContext(dbContextOptions);
    }
}
