﻿using DataGap.Jellog.AspNetCore.Mvc.Authentication;

namespace MyCompanyName.MyProjectName.Web.Public.Controllers;

public class AccountController : ChallengeAccountController
{

}
