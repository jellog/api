using System.Threading.Tasks;
using MyCompanyName.MyProjectName.Localization;
using MyCompanyName.MyProjectName.Permissions;
using DataGap.Jellog.AuditLogging.Web.Navigation;
using DataGap.Jellog.Identity.Web.Navigation;
using DataGap.Jellog.IdentityServer.Web.Navigation;
using DataGap.Jellog.LanguageManagement.Navigation;
using DataGap.Jellog.SettingManagement.Web.Navigation;
using DataGap.Jellog.TextTemplateManagement.Web.Navigation;
using DataGap.Jellog.Authorization.Permissions;
using DataGap.Jellog.UI.Navigation;
//<TEMPLATE-REMOVE IF-NOT='CMS-KIT'>
using DataGap.CmsKit.Pro.Admin.Web.Menus;
//</TEMPLATE-REMOVE>
using DataGap.Saas.Host.Navigation;

namespace MyCompanyName.MyProjectName.Web.Menus;

public class MyProjectNameMenuContributor : IMenuContributor
{
    public async Task ConfigureMenuAsync(MenuConfigurationContext context)
    {
        if (context.Menu.Name == StandardMenus.Main)
        {
            await ConfigureMainMenuAsync(context);
        }
    }

    private static Task ConfigureMainMenuAsync(MenuConfigurationContext context)
    {
        var l = context.GetLocalizer<MyProjectNameResource>();

        //Home
        context.Menu.AddItem(
            new ApplicationMenuItem(
                MyProjectNameMenus.Home,
                l["Menu:Home"],
                "~/",
                icon: "fa fa-home",
                order: 1
            )
        );

        //HostDashboard
        context.Menu.AddItem(
            new ApplicationMenuItem(
                MyProjectNameMenus.HostDashboard,
                l["Menu:Dashboard"],
                "~/HostDashboard",
                icon: "fa fa-line-chart",
                order: 2
            ).RequirePermissions(MyProjectNamePermissions.Dashboard.Host)
        );

        //TenantDashboard
        context.Menu.AddItem(
            new ApplicationMenuItem(
                MyProjectNameMenus.TenantDashboard,
                l["Menu:Dashboard"],
                "~/Dashboard",
                icon: "fa fa-line-chart",
                order: 2
            ).RequirePermissions(MyProjectNamePermissions.Dashboard.Tenant)
        );

        context.Menu.SetSubItemOrder(SaasHostMenuNames.GroupName, 3);
        //<TEMPLATE-REMOVE IF-NOT='CMS-KIT'>
        //CMS
        context.Menu.SetSubItemOrder(CmsKitProAdminMenus.GroupName, 4);
        //</TEMPLATE-REMOVE>

        //Administration
        var administration = context.Menu.GetAdministration();
        administration.Order = 5;

        //Administration->Identity
        administration.SetSubItemOrder(IdentityMenuNames.GroupName, 1);

        //Administration->Identity Server
        administration.SetSubItemOrder(JellogIdentityServerMenuNames.GroupName, 2);

        //Administration->Language Management
        administration.SetSubItemOrder(LanguageManagementMenuNames.GroupName, 3);

        //Administration->Text Template Management
        administration.SetSubItemOrder(TextTemplateManagementMainMenuNames.GroupName, 4);

        //Administration->Audit Logs
        administration.SetSubItemOrder(JellogAuditLoggingMainMenuNames.GroupName, 5);

        //Administration->Settings
        administration.SetSubItemOrder(SettingManagementMenuNames.GroupName, 6);

        return Task.CompletedTask;
    }
}
