using System;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace MyCompanyName.MyProjectName.Web.Pages;

public class HostDashboardModel : PageModel
{
    public void OnGet()
    {

    }
}
