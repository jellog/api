using Microsoft.AspNetCore.Mvc;

namespace MyCompanyName.MyProjectName.Web.Pages;

public class IndexModel : MyProjectNamePageModel
{

}
