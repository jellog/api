﻿using DataGap.Jellog;

namespace MyCompanyName.MyProjectName.EntityFrameworkCore;

public abstract class MyProjectNameEntityFrameworkCoreTestBase : MyProjectNameTestBase<MyProjectNameEntityFrameworkCoreTestModule>
{

}
