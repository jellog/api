import React from 'react';
import { Text } from 'react-native';

function TenantDashboard() {
  return (
    <Text style={{ paddingVertical: 20, textAlign: 'center' }}>
      Add your Tenant related charts/widgets to this page!
    </Text>
  );
}

export default TenantDashboard;
