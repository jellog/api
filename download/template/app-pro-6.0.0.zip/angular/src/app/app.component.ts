import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template: `
    <jellog-loader-bar></jellog-loader-bar>
    <jellog-dynamic-layout></jellog-dynamic-layout>
    <jellog-gdpr-cookie-consent></jellog-gdpr-cookie-consent>
  `,
})
export class AppComponent {}
