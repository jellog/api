import { Component } from '@angular/core';

@Component({
  selector: 'jellog-cookie-policy',
  templateUrl: './cookie-policy.component.html',
})
export class CookiePolicyComponent {
  constructor() {}
}
