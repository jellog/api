using AutoMapper;

namespace MyCompanyName.MyProjectName.Blazor.Server;

public class MyProjectNameBlazorAutoMapperProfile : Profile
{
    public MyProjectNameBlazorAutoMapperProfile()
    {
        //Define your AutoMapper configuration here for the Blazor project.
    }
}
