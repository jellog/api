﻿using System;
using System.Net.Http;
using Blazorise.Bootstrap5;
using Blazorise.Icons.FontAwesome;
using Microsoft.AspNetCore.Components.WebAssembly.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using MyCompanyName.MyProjectName.Blazor.Components.Layout;
using MyCompanyName.MyProjectName.Blazor.Navigation;
using OpenIddict.Abstractions;
using DataGap.Jellog.Account.Pro.Admin.Blazor.WebAssembly;
using DataGap.Jellog.AspNetCore.Components.Web.LeptonXTheme.Components;
using DataGap.Jellog.AspNetCore.Components.Web.Theming.Routing;
using DataGap.Jellog.AspNetCore.Components.WebAssembly.LeptonXTheme;
using DataGap.Jellog.AuditLogging.Blazor.WebAssembly;
using DataGap.Jellog.Autofac.WebAssembly;
using DataGap.Jellog.AutoMapper;
using DataGap.Jellog.Gdpr.Blazor.Extensions;
using DataGap.Jellog.Gdpr.Blazor.WebAssembly;
using DataGap.Jellog.Identity.Pro.Blazor.Server.WebAssembly;
using DataGap.Jellog.Modularity;
using DataGap.Jellog.UI.Navigation;
using DataGap.Jellog.LanguageManagement.Blazor.WebAssembly;
//<TEMPLATE-REMOVE IF-NOT='LEPTONX'>
using DataGap.Jellog.LeptonX.Shared;
//</TEMPLATE-REMOVE>
using DataGap.Jellog.OpenIddict.Pro.Blazor.WebAssembly;
using DataGap.Jellog.SettingManagement.Blazor.WebAssembly;
using DataGap.Jellog.TextTemplateManagement.Blazor.WebAssembly;
using DataGap.Saas.Host.Blazor.WebAssembly;
//<TEMPLATE-REMOVE IF-NOT='CMS-KIT'>
using DataGap.CmsKit.Pro.Admin.Blazor.WebAssembly;
//</TEMPLATE-REMOVE>


namespace MyCompanyName.MyProjectName.Blazor;

[DependsOn(
    typeof(JellogAccountAdminBlazorWebAssemblyModule),
    typeof(JellogAspNetCoreComponentsWebAssemblyLeptonXThemeModule),
    typeof(JellogAuditLoggingBlazorWebAssemblyModule),
    typeof(JellogAutofacWebAssemblyModule),
    typeof(JellogGdprBlazorWebAssemblyModule),
    typeof(JellogIdentityProBlazorWebAssemblyModule),
    typeof(JellogOpenIddictProBlazorWebAssemblyModule),
    typeof(JellogSettingManagementBlazorWebAssemblyModule),
    //<TEMPLATE-REMOVE IF-NOT='CMS-KIT'>
    typeof(CmsKitProAdminBlazorWebAssemblyModule),
    //</TEMPLATE-REMOVE>
    typeof(LanguageManagementBlazorWebAssemblyModule),
    typeof(MyProjectNameHttpApiClientModule),
    typeof(SaasHostBlazorWebAssemblyModule),
    typeof(TextTemplateManagementBlazorWebAssemblyModule)
)]
public class MyProjectNameBlazorModule : JellogModule
{
    public override void ConfigureServices(ServiceConfigurationContext context)
    {
        var environment = context.Services.GetSingletonInstance<IWebAssemblyHostEnvironment>();
        var builder = context.Services.GetSingletonInstance<WebAssemblyHostBuilder>();

        ConfigureAuthentication(builder);
        ConfigureHttpClient(context, environment);
        ConfigureBlazorise(context);
        ConfigureRouter(context);
        ConfigureUI(builder);
        ConfigureMenu(context);
        ConfigureAutoMapper(context);
        ConfigureCookieConsent(context);
        //<TEMPLATE-REMOVE IF-NOT='LEPTONX'>
        ConfigureTheme();
        //</TEMPLATE-REMOVE>
    }
    
    private void ConfigureCookieConsent(ServiceConfigurationContext context)
    {
        context.Services.AddJellogCookieConsent(options =>
        {
            options.IsEnabled = true;
            options.CookiePolicyUrl = "/CookiePolicy";
            options.PrivacyPolicyUrl = "/PrivacyPolicy";
        });
    }

    //<TEMPLATE-REMOVE IF-NOT='LEPTONX'>
    private void ConfigureTheme()
    {
        Configure<LeptonXThemeOptions>(options =>
        {
            options.DefaultStyle = LeptonXStyleNames.System;
        });
    }
    //</TEMPLATE-REMOVE>

    private void ConfigureRouter(ServiceConfigurationContext context)
    {
        Configure<JellogRouterOptions>(options =>
        {
            options.AppAssembly = typeof(MyProjectNameBlazorModule).Assembly;
        });
    }

    private void ConfigureMenu(ServiceConfigurationContext context)
    {
        Configure<JellogNavigationOptions>(options =>
        {
            options.MenuContributors.Add(new MyProjectNameMenuContributor(context.Services.GetConfiguration()));
        });
    }

    private void ConfigureBlazorise(ServiceConfigurationContext context)
    {
        context.Services
            .AddBootstrap5Providers()
            .AddFontAwesomeIcons();
    }

    private static void ConfigureAuthentication(WebAssemblyHostBuilder builder)
    {
        builder.Services.AddOidcAuthentication(options =>
        {
            builder.Configuration.Bind("AuthServer", options.ProviderOptions);
            options.UserOptions.NameClaim = OpenIddictConstants.Claims.Name;
            options.UserOptions.RoleClaim = OpenIddictConstants.Claims.Role;

            options.ProviderOptions.DefaultScopes.Add("MyProjectName");
            options.ProviderOptions.DefaultScopes.Add("roles");
            options.ProviderOptions.DefaultScopes.Add("email");
            options.ProviderOptions.DefaultScopes.Add("phone");
        });
    }

    private static void ConfigureUI(WebAssemblyHostBuilder builder)
    {
        builder.RootComponents.Add<App>("#ApplicationContainer");
    }

    private static void ConfigureHttpClient(ServiceConfigurationContext context, IWebAssemblyHostEnvironment environment)
    {
        context.Services.AddTransient(sp => new HttpClient
        {
            BaseAddress = new Uri(environment.BaseAddress)
        });
    }

    private void ConfigureAutoMapper(ServiceConfigurationContext context)
    {
        Configure<JellogAutoMapperOptions>(options =>
        {
            options.AddMaps<MyProjectNameBlazorModule>();
        });
    }
}
