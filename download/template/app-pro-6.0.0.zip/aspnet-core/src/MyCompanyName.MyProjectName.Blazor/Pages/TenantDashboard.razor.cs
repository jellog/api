﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Components;
using DataGap.Jellog.AuditLogging;
using DataGap.Jellog.AuditLogging.Blazor.Pages.Shared.AverageExecutionDurationPerDayWidget;
using DataGap.Jellog.AuditLogging.Blazor.Pages.Shared.ErrorRateWidget;
using DataGap.Jellog.Authorization.Permissions;
using DataGap.Jellog.BlazoriseUI;
using DataGap.Jellog.Timing;

namespace MyCompanyName.MyProjectName.Blazor.Pages;

public partial class TenantDashboard
{
    [Inject]
    public IPermissionChecker PermissionChecker { get; set; }
    
    protected List<BreadcrumbItem> BreadcrumbItems = new();

    protected AuditLoggingErrorRateWidgetComponent ErrorRateWidgetComponent;
    
    protected AuditLoggingAverageExecutionDurationPerDayWidgetComponent AverageExecutionDurationPerDayWidgetComponent;
    
    protected DateTime StartDate { get; set; }
    
    protected DateTime EndDate { get; set; }

    protected bool HasAuditLoggingPermission { get; set; }
    
    protected async override Task OnInitializedAsync()
    {
        StartDate = Clock.Now.AddMonths(-1).Date;
        EndDate = Clock.Now.Date;
        HasAuditLoggingPermission = await PermissionChecker.IsGrantedAsync(JellogAuditLoggingPermissions.AuditLogs.Default);
        await SetBreadcrumbItemsAsync();
    }
    
    protected virtual async Task RefreshAsync()
    {
        if (HasAuditLoggingPermission)
        {
            await AverageExecutionDurationPerDayWidgetComponent.RefreshAsync();
            await ErrorRateWidgetComponent.RefreshAsync();   
        }
    }

    protected virtual ValueTask SetBreadcrumbItemsAsync()
    {
        BreadcrumbItems.Add(new BreadcrumbItem(L["Dashboard"]));
        return ValueTask.CompletedTask;
    }
}