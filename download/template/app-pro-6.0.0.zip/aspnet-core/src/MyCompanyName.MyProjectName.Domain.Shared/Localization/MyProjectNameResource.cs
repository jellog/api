﻿using DataGap.Jellog.Localization;

namespace MyCompanyName.MyProjectName.Localization;

[LocalizationResourceName("MyProjectName")]
public class MyProjectNameResource
{

}
