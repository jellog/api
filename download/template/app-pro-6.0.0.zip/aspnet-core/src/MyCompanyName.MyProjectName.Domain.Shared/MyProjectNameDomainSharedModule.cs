using MyCompanyName.MyProjectName.Localization;
using DataGap.Jellog.AuditLogging;
using DataGap.Jellog.BackgroundJobs;
using DataGap.Jellog.FeatureManagement;
using DataGap.Jellog.Identity;
using DataGap.Jellog.LanguageManagement;
using DataGap.Jellog.Localization;
using DataGap.Jellog.Localization.ExceptionHandling;
using DataGap.Jellog.Validation.Localization;
using DataGap.Jellog.Modularity;
using DataGap.Jellog.PermissionManagement;
using DataGap.Jellog.SettingManagement;
using DataGap.Jellog.TextTemplateManagement;
using DataGap.Jellog.VirtualFileSystem;
using DataGap.Saas;
using DataGap.Jellog.OpenIddict;
using DataGap.Jellog.BlobStoring.Database;
using DataGap.Jellog.Gdpr;
//<TEMPLATE-REMOVE IF-NOT='CMS-KIT'>
using DataGap.CmsKit;
//</TEMPLATE-REMOVE>
//<TEMPLATE-REMOVE IF='CMS-KIT'>
using DataGap.Jellog.GlobalFeatures;
//</TEMPLATE-REMOVE>

namespace MyCompanyName.MyProjectName;

[DependsOn(
    typeof(JellogAuditLoggingDomainSharedModule),
    typeof(JellogBackgroundJobsDomainSharedModule),
    typeof(JellogFeatureManagementDomainSharedModule),
    typeof(JellogIdentityProDomainSharedModule),
    typeof(JellogOpenIddictDomainSharedModule),
    typeof(JellogPermissionManagementDomainSharedModule),
    typeof(JellogSettingManagementDomainSharedModule),
    typeof(LanguageManagementDomainSharedModule),
    typeof(SaasDomainSharedModule),
    typeof(TextTemplateManagementDomainSharedModule),
    typeof(JellogGdprDomainSharedModule),
    //<TEMPLATE-REMOVE IF-NOT='CMS-KIT'>
    typeof(CmsKitProDomainSharedModule),
    //</TEMPLATE-REMOVE>
    //<TEMPLATE-REMOVE IF='CMS-KIT'>
    typeof(JellogGlobalFeaturesModule),
    //</TEMPLATE-REMOVE>
    typeof(BlobStoringDatabaseDomainSharedModule)
    )]
public class MyProjectNameDomainSharedModule : JellogModule
{
    public override void PreConfigureServices(ServiceConfigurationContext context)
    {
        MyProjectNameGlobalFeatureConfigurator.Configure();
        MyProjectNameModuleExtensionConfigurator.Configure();
    }

    public override void ConfigureServices(ServiceConfigurationContext context)
    {
        Configure<JellogVirtualFileSystemOptions>(options =>
        {
            options.FileSets.AddEmbedded<MyProjectNameDomainSharedModule>();
        });

        Configure<JellogLocalizationOptions>(options =>
        {
            options.Resources
                .Add<MyProjectNameResource>("en")
                .AddBaseTypes(typeof(JellogValidationResource))
                .AddVirtualJson("/Localization/MyProjectName");

            options.DefaultResourceType = typeof(MyProjectNameResource);
        });

        Configure<JellogExceptionLocalizationOptions>(options =>
        {
            options.MapCodeNamespace("MyProjectName", typeof(MyProjectNameResource));
        });
    }
}
