using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.DependencyInjection.Extensions;
using MyCompanyName.MyProjectName.Localization;
using MyCompanyName.MyProjectName.MultiTenancy;
using DataGap.Jellog.AuditLogging;
using DataGap.Jellog.BackgroundJobs;
using DataGap.Jellog.Emailing;
using DataGap.Jellog.FeatureManagement;
using DataGap.Jellog.Identity;
using DataGap.Jellog.LanguageManagement;
using DataGap.Jellog.Localization;
using DataGap.Jellog.Modularity;
using DataGap.Jellog.MultiTenancy;
using DataGap.Jellog.PermissionManagement.Identity;
using DataGap.Jellog.SettingManagement;
using DataGap.Jellog.TextTemplateManagement;
using DataGap.Saas;
using DataGap.Jellog.BlobStoring.Database;
using DataGap.Jellog.Gdpr;
using DataGap.Jellog.OpenIddict;
using DataGap.Jellog.PermissionManagement.OpenIddict;
//<TEMPLATE-REMOVE IF-NOT='CMS-KIT'>
using DataGap.CmsKit;
using DataGap.CmsKit.Contact;
using DataGap.CmsKit.Newsletters;
//</TEMPLATE-REMOVE>

namespace MyCompanyName.MyProjectName;

[DependsOn(
    typeof(MyProjectNameDomainSharedModule),
    typeof(JellogAuditLoggingDomainModule),
    typeof(JellogBackgroundJobsDomainModule),
    typeof(JellogFeatureManagementDomainModule),
    typeof(JellogIdentityProDomainModule),
    typeof(JellogPermissionManagementDomainIdentityModule),
    typeof(JellogOpenIddictDomainModule),
    typeof(JellogPermissionManagementDomainOpenIddictModule),
    typeof(JellogSettingManagementDomainModule),
    typeof(SaasDomainModule),
    typeof(TextTemplateManagementDomainModule),
    typeof(LanguageManagementDomainModule),
    typeof(JellogEmailingModule),
    typeof(JellogGdprDomainModule),
    //<TEMPLATE-REMOVE IF-NOT='CMS-KIT'>
    typeof(CmsKitProDomainModule),
    //</TEMPLATE-REMOVE>
    typeof(BlobStoringDatabaseDomainModule)
    )]
public class MyProjectNameDomainModule : JellogModule
{
    public override void ConfigureServices(ServiceConfigurationContext context)
    {
        Configure<JellogMultiTenancyOptions>(options =>
        {
            options.IsEnabled = MultiTenancyConsts.IsEnabled;
        });

        Configure<JellogLocalizationOptions>(options =>
        {
            options.Languages.Add(new LanguageInfo("ar", "ar", "العربية", "ae"));
            options.Languages.Add(new LanguageInfo("en", "en", "English", "gb"));
            options.Languages.Add(new LanguageInfo("fi", "fi", "Finnish", "fi"));
            options.Languages.Add(new LanguageInfo("fr", "fr", "Français", "fr"));
            options.Languages.Add(new LanguageInfo("hi", "hi", "Hindi", "in"));
            options.Languages.Add(new LanguageInfo("it", "it", "Italiano", "it"));
            options.Languages.Add(new LanguageInfo("sk", "sk", "Slovak", "sk"));
            options.Languages.Add(new LanguageInfo("ru", "ru", "Русский", "ru"));
            options.Languages.Add(new LanguageInfo("tr", "tr", "Türkçe", "tr"));
            options.Languages.Add(new LanguageInfo("sl", "sl", "Slovenščina", "si"));
            options.Languages.Add(new LanguageInfo("zh-Hans", "zh-Hans", "简体中文", "cn"));
            options.Languages.Add(new LanguageInfo("zh-Hant", "zh-Hant", "繁體中文", "tw"));
            options.Languages.Add(new LanguageInfo("de-DE", "de-DE", "Deutsch", "de"));
            options.Languages.Add(new LanguageInfo("es", "es", "Español", "es"));
            options.Languages.Add(new LanguageInfo("nl", "nl", "Dutch", "nl"));
        });
        //<TEMPLATE-REMOVE IF-NOT='CMS-KIT'>
        Configure<NewsletterOptions>(options =>
        {
            options.AddPreference(
                "Newsletter_Default",
                new NewsletterPreferenceDefinition(
                    LocalizableString.Create<MyProjectNameResource>("NewsletterPreference_Default"),
                    privacyPolicyConfirmation: LocalizableString.Create<MyProjectNameResource>("NewsletterPrivacyAcceptMessage")
                )
            );
        });

        //</TEMPLATE-REMOVE>

#if DEBUG
        context.Services.Replace(ServiceDescriptor.Singleton<IEmailSender, NullEmailSender>());
#endif
    }
}
