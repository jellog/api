using Microsoft.EntityFrameworkCore;
using DataGap.Jellog.AuditLogging.EntityFrameworkCore;
using DataGap.Jellog.BackgroundJobs.EntityFrameworkCore;
using DataGap.Jellog.BlobStoring.Database.EntityFrameworkCore;
using DataGap.Jellog.Data;
using DataGap.Jellog.DependencyInjection;
using DataGap.Jellog.EntityFrameworkCore;
using DataGap.Jellog.FeatureManagement.EntityFrameworkCore;
using DataGap.Jellog.Identity;
using DataGap.Jellog.Identity.EntityFrameworkCore;
using DataGap.Jellog.LanguageManagement.EntityFrameworkCore;
using DataGap.Jellog.PermissionManagement.EntityFrameworkCore;
using DataGap.Jellog.SettingManagement.EntityFrameworkCore;
using DataGap.Jellog.TextTemplateManagement.EntityFrameworkCore;
using DataGap.Saas.EntityFrameworkCore;
using DataGap.Saas.Editions;
using DataGap.Saas.Tenants;
using DataGap.Jellog.Gdpr;
using DataGap.Jellog.OpenIddict.EntityFrameworkCore;
//<TEMPLATE-REMOVE IF-NOT='CMS-KIT'>
using DataGap.CmsKit.EntityFrameworkCore;
//</TEMPLATE-REMOVE>

namespace MyCompanyName.MyProjectName.EntityFrameworkCore;

[ReplaceDbContext(typeof(IIdentityProDbContext))]
[ReplaceDbContext(typeof(ISaasDbContext))]
[ConnectionStringName("Default")]
public class MyProjectNameDbContext :
    JellogDbContext<MyProjectNameDbContext>,
    IIdentityProDbContext,
    ISaasDbContext
{
    /* Add DbSet properties for your Aggregate Roots / Entities here. */

    #region Entities from the modules

    /* Notice: We only implemented IIdentityProDbContext and ISaasDbContext
     * and replaced them for this DbContext. This allows you to perform JOIN
     * queries for the entities of these modules over the repositories easily. You
     * typically don't need that for other modules. But, if you need, you can
     * implement the DbContext interface of the needed module and use ReplaceDbContext
     * attribute just like IIdentityProDbContext and ISaasDbContext.
     *
     * More info: Replacing a DbContext of a module ensures that the related module
     * uses this DbContext on runtime. Otherwise, it will use its own DbContext class.
     */

    // Identity
    public DbSet<IdentityUser> Users { get; set; }
    public DbSet<IdentityRole> Roles { get; set; }
    public DbSet<IdentityClaimType> ClaimTypes { get; set; }
    public DbSet<OrganizationUnit> OrganizationUnits { get; set; }
    public DbSet<IdentitySecurityLog> SecurityLogs { get; set; }
    public DbSet<IdentityLinkUser> LinkUsers { get; set; }

    // SaaS
    public DbSet<Tenant> Tenants { get; set; }
    public DbSet<Edition> Editions { get; set; }
    public DbSet<TenantConnectionString> TenantConnectionStrings { get; set; }

    #endregion

    public MyProjectNameDbContext(DbContextOptions<MyProjectNameDbContext> options)
        : base(options)
    {

    }

    protected override void OnModelCreating(ModelBuilder builder)
    {
        base.OnModelCreating(builder);

        /* Include modules to your migration db context */

        builder.ConfigurePermissionManagement();
        builder.ConfigureSettingManagement();
        builder.ConfigureBackgroundJobs();
        builder.ConfigureAuditLogging();
        builder.ConfigureIdentityPro();
        builder.ConfigureOpenIddict();
        builder.ConfigureFeatureManagement();
        builder.ConfigureLanguageManagement();
        builder.ConfigureSaas();
        builder.ConfigureTextTemplateManagement();
        builder.ConfigureBlobStoring();
        builder.ConfigureGdpr();
        //<TEMPLATE-REMOVE IF-NOT='CMS-KIT'>
        builder.ConfigureCmsKit();
        builder.ConfigureCmsKitPro();
        //</TEMPLATE-REMOVE>

        /* Configure your own tables/entities inside here */

        //builder.Entity<YourEntity>(b =>
        //{
        //    b.ToTable(MyProjectNameConsts.DbTablePrefix + "YourEntities", MyProjectNameConsts.DbSchema);
        //    b.ConfigureByConvention(); //auto configure for the base class props
        //    //...
        //});
    }
}
