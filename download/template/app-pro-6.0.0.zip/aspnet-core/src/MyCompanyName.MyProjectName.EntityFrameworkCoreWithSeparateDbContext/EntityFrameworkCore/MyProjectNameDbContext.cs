﻿using Microsoft.EntityFrameworkCore;
using DataGap.Jellog.Data;
using DataGap.Jellog.MultiTenancy;

namespace MyCompanyName.MyProjectName.EntityFrameworkCore;

[ConnectionStringName("Default")]
public class MyProjectNameDbContext : MyProjectNameDbContextBase<MyProjectNameDbContext>
{
    public MyProjectNameDbContext(DbContextOptions<MyProjectNameDbContext> options)
        : base(options)
    {
    }

    protected override void OnModelCreating(ModelBuilder builder)
    {
        builder.SetMultiTenancySide(MultiTenancySides.Both);

        base.OnModelCreating(builder);
    }
}
