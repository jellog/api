﻿using Localization.Resources.JellogUi;
using MyCompanyName.MyProjectName.Localization;
using DataGap.Jellog.Account;
using DataGap.Jellog.AuditLogging;
using DataGap.Jellog.FeatureManagement;
using DataGap.Jellog.Identity;
using DataGap.Jellog.LanguageManagement;
using DataGap.Jellog.Modularity;
using DataGap.Jellog.PermissionManagement.HttpApi;
using DataGap.Saas.Host;
using DataGap.Jellog.Localization;
using DataGap.Jellog.SettingManagement;
using DataGap.Jellog.TextTemplateManagement;
using DataGap.Jellog.Gdpr;
using DataGap.Jellog.OpenIddict;
//<TEMPLATE-REMOVE IF-NOT='CMS-KIT'>
using DataGap.CmsKit;
//</TEMPLATE-REMOVE>

namespace MyCompanyName.MyProjectName;

 [DependsOn(
    typeof(MyProjectNameApplicationContractsModule),
    typeof(JellogIdentityHttpApiModule),
    typeof(JellogPermissionManagementHttpApiModule),
    typeof(JellogFeatureManagementHttpApiModule),
    typeof(JellogSettingManagementHttpApiModule),
    typeof(JellogAuditLoggingHttpApiModule),
    typeof(JellogOpenIddictProHttpApiModule),
    typeof(JellogAccountAdminHttpApiModule),
    typeof(LanguageManagementHttpApiModule),
    typeof(SaasHostHttpApiModule),
    typeof(JellogGdprHttpApiModule),
    //<TEMPLATE-REMOVE IF-NOT='CMS-KIT'>
    typeof(CmsKitProHttpApiModule),
    //</TEMPLATE-REMOVE>
    //<TEMPLATE-REMOVE IF='tiered'>
    typeof(JellogAccountPublicHttpApiModule),
    //</TEMPLATE-REMOVE>
    typeof(TextTemplateManagementHttpApiModule)
    )]
public class MyProjectNameHttpApiModule : JellogModule
{
    public override void ConfigureServices(ServiceConfigurationContext context)
    {
        ConfigureLocalization();
    }

    private void ConfigureLocalization()
    {
        Configure<JellogLocalizationOptions>(options =>
        {
            options.Resources
                .Get<MyProjectNameResource>()
                .AddBaseTypes(
                    typeof(JellogUiResource)
                );
        });
    }
}
