﻿using MyCompanyName.MyProjectName.Maui.ViewModels;
using DataGap.Jellog.DependencyInjection;

namespace MyCompanyName.MyProjectName.Maui;

public partial class AppShell : Shell, ITransientDependency
{
    public AppShell(ShellViewModel vm)
    {
        BindingContext = vm;
        InitializeComponent();
    }
}
