using MyCompanyName.MyProjectName.Maui.ViewModels;
using DataGap.Jellog.DependencyInjection;

namespace MyCompanyName.MyProjectName.Maui;

public partial class MainPage : ContentPage, ITransientDependency
{
    public MainPage(
		MainPageViewModel vm)
	{
        BindingContext = vm;
        InitializeComponent();
    }
}