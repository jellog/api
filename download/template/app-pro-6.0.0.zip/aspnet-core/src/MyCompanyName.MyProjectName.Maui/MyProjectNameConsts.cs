﻿namespace MyCompanyName.MyProjectName.Maui;
public static class MyProjectNameConsts
{
    public static class OidcConsts
    {
        public const string AccessTokenKeyName = "__access_token";
        public const string RefreshTokenKeyName = "__refresh_token";
    }

    public static class MessagingCenterConsts
    {
        public const string LoginEvent = "LoginEvent";
        public const string LogoutEvent = "SignOutEvent";
    }
}
