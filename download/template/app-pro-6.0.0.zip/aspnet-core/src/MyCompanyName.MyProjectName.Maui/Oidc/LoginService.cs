﻿using System.IdentityModel.Tokens.Jwt;
using IdentityModel.OidcClient;
using MyCompanyName.MyProjectName.Maui.Storage;
using DataGap.Jellog.DependencyInjection;

namespace MyCompanyName.MyProjectName.Maui.Oidc;

public class LoginService : ILoginService, ITransientDependency
{
    private readonly OidcClient _oidcClient;
    private readonly IStorage _storage;

    public LoginService(OidcClient oidcClient, IStorage storage)
    {
        _oidcClient = oidcClient;
        _storage = storage;
    }

    public async Task<LoginResult> LoginAsync()
    {
        var loginResult = await _oidcClient.LoginAsync(new LoginRequest());

        if (!loginResult.IsError)
        {
            await SetTokenCacheAsync(loginResult.AccessToken, loginResult.RefreshToken);
            MessagingCenter.Send(this, MyProjectNameConsts.MessagingCenterConsts.LoginEvent);
        }

        return loginResult;
    }

    public async Task<LogoutResult> LogoutAsync()
    {
        var logoutResult = await _oidcClient.LogoutAsync();
        if (!logoutResult.IsError)
        {
            await ClearTokenCacheAsync();
            MessagingCenter.Send(this, MyProjectNameConsts.MessagingCenterConsts.LogoutEvent);
        }

        return logoutResult;
    }

    public async Task<string> GetAccessTokenAsync()
    {
        var token = await _storage.GetAsync(MyProjectNameConsts.OidcConsts.AccessTokenKeyName);

        if (!token.IsNullOrEmpty())
        {
            var jwtToken = new JwtSecurityTokenHandler().ReadJwtToken(token);
            if (jwtToken.ValidTo <= DateTime.UtcNow)
            {
                var refreshToken = await _storage.GetAsync(MyProjectNameConsts.OidcConsts.RefreshTokenKeyName);
                if (!refreshToken.IsNullOrEmpty())
                {
                    var refreshResult = await _oidcClient.RefreshTokenAsync(refreshToken);
                    await SetTokenCacheAsync(refreshResult.AccessToken, refreshResult.RefreshToken);

                    return refreshResult.AccessToken;
                }

                await ClearTokenCacheAsync();
                MessagingCenter.Send(this, MyProjectNameConsts.MessagingCenterConsts.LogoutEvent);
            }
        }

        return token;
    }

    private async Task SetTokenCacheAsync(string accessToken, string refreshToken)
    {
        await _storage.SetAsync(MyProjectNameConsts.OidcConsts.AccessTokenKeyName, accessToken);
        await _storage.SetAsync(MyProjectNameConsts.OidcConsts.RefreshTokenKeyName, refreshToken);
    }

    private async Task ClearTokenCacheAsync()
    {
        await _storage.RemoveAsync(MyProjectNameConsts.OidcConsts.AccessTokenKeyName);
        await _storage.RemoveAsync(MyProjectNameConsts.OidcConsts.RefreshTokenKeyName);
    }
}