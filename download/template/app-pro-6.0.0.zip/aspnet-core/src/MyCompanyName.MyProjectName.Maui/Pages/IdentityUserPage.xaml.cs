using MyCompanyName.MyProjectName.Maui.ViewModels;
using DataGap.Jellog.DependencyInjection;

namespace MyCompanyName.MyProjectName.Maui.Pages;

public partial class IdentityUserPage : ContentPage , ITransientDependency
{
	
	public IdentityUserPage(IdentityUserPageViewModel vm)
	{
        BindingContext = vm;
        InitializeComponent();
	}
}