﻿using System.Collections.ObjectModel;
using System.Windows.Input;
using DataGap.Jellog.DependencyInjection;
using DataGap.Jellog.Identity;

namespace MyCompanyName.MyProjectName.Maui.ViewModels;
public class IdentityUserPageViewModel : MyProjectNameViewModelBase, ITransientDependency
{
    protected IIdentityUserAppService IdentityUserAppService { get; }

    public GetIdentityUsersInput Input { get; } = new();

    public ObservableCollection<IdentityUserDto> Items { get; } = new();

    public ICommand RefreshCommand { get; }

    private bool _isBusy;
    public bool IsBusy { get => _isBusy; set => SetProperty(ref _isBusy, value, nameof(IsBusy)); }

    public IdentityUserPageViewModel(IIdentityUserAppService identityUserAppService)
    {
        IdentityUserAppService = identityUserAppService;
        GetUsersAsync();
        RefreshCommand = new Command(GetUsersAsync);
    }

    private async void GetUsersAsync()
    {
        if (IsBusy)
        {
            return;
        }

        IsBusy = true;

        Items.Clear();

        var result = await IdentityUserAppService.GetListAsync(Input);
        foreach (var user in result.Items)
        {
            Items.Add(user);
        }

        IsBusy = false;
    }
}
