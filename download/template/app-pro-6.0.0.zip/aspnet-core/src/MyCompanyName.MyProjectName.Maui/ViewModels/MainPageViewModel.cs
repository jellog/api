﻿using System.Globalization;
using System.Windows.Input;
using Microsoft.Extensions.Options;
using MyCompanyName.MyProjectName.Maui.Oidc;
using DataGap.Jellog.DependencyInjection;
using DataGap.Jellog.Localization;

namespace MyCompanyName.MyProjectName.Maui.ViewModels;

public class MainPageViewModel : MyProjectNameViewModelBase, ITransientDependency
{
    private readonly ILoginService _loginService;
    private readonly JellogLocalizationOptions _localizationOptions;
    
    public string LoginOrLogoutBtnText => CurrentUser.IsAuthenticated ? L["LoggedOutTitle"] : L["LoginToTheApplication"];

    public ICommand LoginOrLogoutCommand { get; }
    
    public ICommand ChangeLanguageCommand { get; }
    
    public MainPageViewModel(
        ILoginService loginService,
        IOptions<JellogLocalizationOptions> localizationOptions)
    {
        _loginService = loginService;
        _localizationOptions = localizationOptions.Value;
        
        MessagingCenter.Subscribe<LoginService>(this, MyProjectNameConsts.MessagingCenterConsts.LoginEvent, _ =>
        {
            OnPropertyChanged(nameof(LoginOrLogoutBtnText));
        });

        MessagingCenter.Subscribe<LoginService>(this, MyProjectNameConsts.MessagingCenterConsts.LogoutEvent, _ =>
        {
            OnPropertyChanged(nameof(LoginOrLogoutBtnText));
        });

        LoginOrLogoutCommand = new Command(LoginOrLogoutAsync);
        ChangeLanguageCommand = new Command(ChangeLanguageAsync);
    }

    private async void LoginOrLogoutAsync()
    {
        if (DeviceInfo.Platform == DevicePlatform.WinUI)
        { 
            //https://github.com/dotnet/maui/issues/2702
            await Shell.Current.DisplayAlert(L["Error"], "At the moment, WebAuthenticator isn't working on Windows.", L["Close"]);
            return;
        }
        
        if(!CurrentUser.IsAuthenticated)
        {
            var loginResult = await _loginService.LoginAsync();

            if (loginResult.IsError)
            {
                await Shell.Current.DisplayAlert(L["Error"], loginResult.Error, L["Close"]);
            }
        }
        else
        {
            var logoutResult = await _loginService.LogoutAsync();

            if (logoutResult.IsError)
            {
                await Shell.Current.DisplayAlert(L["Error"], logoutResult.Error, L["Close"]);
            }
        } 
    }

    private async void ChangeLanguageAsync()
    {
        var selectedLanguage = await Shell.Current.CurrentPage.DisplayActionSheet(
            null, null, null,
            _localizationOptions.Languages.Select(x => x.DisplayName).ToArray());

        if(selectedLanguage.IsNullOrWhiteSpace())
        {
            return;
        }
		
        var culture = _localizationOptions.Languages.FirstOrDefault(x => x.DisplayName == selectedLanguage);
        if(culture == null)
        {
            return;
        }

        L.CurrentCulture = new CultureInfo(culture.CultureName);

        OnPropertyChanged(nameof(LoginOrLogoutBtnText));
    }
}
