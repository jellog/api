﻿using System.Runtime.CompilerServices;
using MyCompanyName.MyProjectName.Maui.Localization;
using DataGap.Jellog.DependencyInjection;
using DataGap.Jellog.MultiTenancy;
using DataGap.Jellog.Users;

namespace MyCompanyName.MyProjectName.Maui.ViewModels;

public abstract class MyProjectNameViewModelBase: BindableObject
{
    public IJellogLazyServiceProvider LazyServiceProvider { get; set; }

    public ICurrentTenant CurrentTenant => LazyServiceProvider.LazyGetRequiredService<ICurrentTenant>();

    public ICurrentUser CurrentUser => LazyServiceProvider.LazyGetRequiredService<ICurrentUser>();
    
    public LocalizationResourceManager L => LazyServiceProvider.LazyGetRequiredService<LocalizationResourceManager>();

    protected void SetProperty<T>(ref T backField, T value, [CallerMemberName] string propertyName = null)
    {
        backField = value;
        OnPropertyChanged(propertyName);
    }
}