﻿using MyCompanyName.MyProjectName.Maui.Localization;
using MyCompanyName.MyProjectName.Maui.Oidc;
using DataGap.Jellog.DependencyInjection;

namespace MyCompanyName.MyProjectName.Maui.ViewModels;

public class ShellViewModel : MyProjectNameViewModelBase, ITransientDependency
{
    public bool IsIdentityUserPageVisible => CurrentUser.IsAuthenticated;

    public string CurrentUserName => L["Welcome"] + $" {CurrentUser.UserName}";

    public ShellViewModel(LocalizationResourceManager localizationManager)
    {
        MessagingCenter.Subscribe<LoginService>(this, MyProjectNameConsts.MessagingCenterConsts.LoginEvent, _ =>
        {
            UpdateProperties();
        });

        MessagingCenter.Subscribe<LoginService>(this, MyProjectNameConsts.MessagingCenterConsts.LogoutEvent, _ =>
        {
            UpdateProperties();
        });

        localizationManager.PropertyChanged += (_, _) =>
        {
            UpdateProperties();
        };
    }

    private void UpdateProperties()
    {
        OnPropertyChanged(nameof(IsIdentityUserPageVisible));
        OnPropertyChanged(nameof(CurrentUserName));
    }
}