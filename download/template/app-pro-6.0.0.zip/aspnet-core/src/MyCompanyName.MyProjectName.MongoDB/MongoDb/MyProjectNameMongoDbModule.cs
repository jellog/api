using Microsoft.Extensions.DependencyInjection;
using DataGap.Jellog.AuditLogging.MongoDB;
using DataGap.Jellog.BackgroundJobs.MongoDB;
using DataGap.Jellog.FeatureManagement.MongoDB;
using DataGap.Jellog.Identity.MongoDB;
using DataGap.Jellog.LanguageManagement.MongoDB;
using DataGap.Jellog.Modularity;
using DataGap.Jellog.PermissionManagement.MongoDB;
using DataGap.Jellog.SettingManagement.MongoDB;
using DataGap.Jellog.TextTemplateManagement.MongoDB;
using DataGap.Saas.MongoDB;
using DataGap.Jellog.BlobStoring.Database.MongoDB;
using DataGap.Jellog.Uow;
using DataGap.Jellog.Gdpr;
using DataGap.Jellog.OpenIddict.MongoDB;
//<TEMPLATE-REMOVE IF-NOT='CMS-KIT'>
using DataGap.CmsKit.MongoDB;
//</TEMPLATE-REMOVE>

namespace MyCompanyName.MyProjectName.MongoDB;

[DependsOn(
    typeof(MyProjectNameDomainModule),
    typeof(JellogPermissionManagementMongoDbModule),
    typeof(JellogSettingManagementMongoDbModule),
    typeof(JellogIdentityProMongoDbModule),
    typeof(JellogOpenIddictMongoDbModule),
    typeof(JellogBackgroundJobsMongoDbModule),
    typeof(JellogAuditLoggingMongoDbModule),
    typeof(JellogFeatureManagementMongoDbModule),
    typeof(LanguageManagementMongoDbModule),
    typeof(SaasMongoDbModule),
    typeof(TextTemplateManagementMongoDbModule),
    typeof(JellogGdprMongoDbModule),
    //<TEMPLATE-REMOVE IF-NOT='CMS-KIT'>
    typeof(CmsKitProMongoDbModule),
    //</TEMPLATE-REMOVE>
    typeof(BlobStoringDatabaseMongoDbModule)
)]
public class MyProjectNameMongoDbModule : JellogModule
{
    public override void ConfigureServices(ServiceConfigurationContext context)
    {
        context.Services.AddMongoDbContext<MyProjectNameMongoDbContext>(options =>
        {
            options.AddDefaultRepositories();
        });

        Configure<JellogUnitOfWorkDefaultOptions>(options =>
        {
            options.TransactionBehavior = UnitOfWorkTransactionBehavior.Disabled;
        });
    }
}
