using System;
using System.IO;
using System.Threading.Tasks;
using Medallion.Threading;
using Medallion.Threading.Redis;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.OpenIdConnect;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.DataProtection;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.IdentityModel.Protocols.OpenIdConnect;
using MyCompanyName.MyProjectName.Localization;
using MyCompanyName.MyProjectName.MultiTenancy;
using MyCompanyName.MyProjectName.Permissions;
using MyCompanyName.MyProjectName.Web.Menus;
using StackExchange.Redis;
using DataGap.Jellog.Caching.StackExchangeRedis;
using DataGap.Jellog.DistributedLocking;
using Microsoft.OpenApi.Models;
using DataGap.Jellog;
using DataGap.Jellog.Account.Admin.Web;
using DataGap.Jellog.Account.Public.Web.Impersonation;
using DataGap.Jellog.AspNetCore.Authentication.OpenIdConnect;
using DataGap.Jellog.AspNetCore.Mvc.Client;
using DataGap.Jellog.AspNetCore.Mvc.Localization;
using DataGap.Jellog.AspNetCore.Mvc.UI;
using DataGap.Jellog.AspNetCore.Mvc.UI.Bootstrap;
using DataGap.Jellog.AspNetCore.Mvc.UI.Bundling;
using DataGap.Jellog.AspNetCore.Mvc.UI.Theme.LeptonX;
using DataGap.Jellog.AspNetCore.Mvc.UI.Theme.LeptonX.Bundling;
using DataGap.Jellog.AspNetCore.Mvc.UI.Theme.Shared;
using DataGap.Jellog.AspNetCore.Mvc.UI.Theme.Shared.Toolbars;
using DataGap.Jellog.AspNetCore.Serilog;
using DataGap.Jellog.AuditLogging.Web;
using DataGap.Jellog.Autofac;
using DataGap.Jellog.AutoMapper;
using DataGap.Jellog.BackgroundJobs;
using DataGap.Jellog.Caching;
using DataGap.Jellog.FeatureManagement;
using DataGap.Jellog.Gdpr.Web;
using DataGap.Jellog.Gdpr.Web.Extensions;
using DataGap.Jellog.Http.Client.IdentityModel.Web;
using DataGap.Jellog.Identity.Web;
using DataGap.Jellog.Http.Client.Web;
using DataGap.Jellog.LanguageManagement;
//<TEMPLATE-REMOVE IF-NOT='LEPTONX'>
using DataGap.Jellog.LeptonX.Shared;
//</TEMPLATE-REMOVE IF-NOT='LEPTONX'>
using DataGap.Jellog.Modularity;
using DataGap.Jellog.MultiTenancy;
using DataGap.Jellog.OpenIddict.Pro.Web;
using DataGap.Jellog.PermissionManagement.Web;
using DataGap.Jellog.Swashbuckle;
using DataGap.Jellog.TextTemplateManagement.Web;
using DataGap.Jellog.UI;
using DataGap.Jellog.UI.Navigation.Urls;
using DataGap.Jellog.UI.Navigation;
using DataGap.Jellog.VirtualFileSystem;
using DataGap.Saas.Host;
//<TEMPLATE-REMOVE IF-NOT='CMS-KIT'>
using DataGap.CmsKit.Pro.Admin.Web;
//</TEMPLATE-REMOVE>

namespace MyCompanyName.MyProjectName.Web;

[DependsOn(
    typeof(MyProjectNameHttpApiClientModule),
    typeof(MyProjectNameHttpApiModule),
    typeof(JellogAccountPublicWebImpersonationModule),
    typeof(JellogAspNetCoreMvcClientModule),
    typeof(JellogHttpClientWebModule),
    typeof(JellogAutofacModule),
    typeof(JellogCachingStackExchangeRedisModule),
    typeof(JellogDistributedLockingModule),
    typeof(JellogFeatureManagementWebModule),
    typeof(JellogAccountAdminWebModule),
    typeof(JellogHttpClientIdentityModelWebModule),
    typeof(JellogIdentityWebModule),
    typeof(JellogAuditLoggingWebModule),
    typeof(SaasHostWebModule),
    typeof(JellogOpenIddictProWebModule),
    //typeof(JellogAspNetCoreMvcUiLeptonXThemeModule),
    typeof(LanguageManagementWebModule),
    typeof(TextTemplateManagementWebModule),
    typeof(JellogGdprWebModule),
    //<TEMPLATE-REMOVE IF-NOT='CMS-KIT'>
    typeof(CmsKitProAdminWebModule),
    //</TEMPLATE-REMOVE>
    typeof(JellogSwashbuckleModule),
    typeof(JellogAspNetCoreSerilogModule)
    )]
public class MyProjectNameWebModule : JellogModule
{
    public override void PreConfigureServices(ServiceConfigurationContext context)
    {
        context.Services.PreConfigure<JellogMvcDataAnnotationsLocalizationOptions>(options =>
        {
            options.AddAssemblyResource(
                typeof(MyProjectNameResource),
                typeof(MyProjectNameDomainSharedModule).Assembly,
                typeof(MyProjectNameApplicationContractsModule).Assembly,
                typeof(MyProjectNameWebModule).Assembly
            );
        });
    }

    public override void ConfigureServices(ServiceConfigurationContext context)
    {
        //You can disable this setting in production to avoid any potential security risks.
        Microsoft.IdentityModel.Logging.IdentityModelEventSource.ShowPII = true;

        var hostingEnvironment = context.Services.GetHostingEnvironment();
        var configuration = context.Services.GetConfiguration();

        ConfigureBundles();
        ConfigurePages(configuration);
        ConfigureCache(configuration);
        ConfigureDataProtection(context, configuration, hostingEnvironment);
        ConfigureDistributedLocking(context, configuration);
        ConfigureUrls(configuration);
        ConfigureAuthentication(context, configuration);
        ConfigureImpersonation(context, configuration);
        ConfigureAutoMapper();
        ConfigureVirtualFileSystem(hostingEnvironment);
        ConfigureNavigationServices(configuration);
        ConfigureSwaggerServices(context.Services);
        ConfigureMultiTenancy();
        ConfigureBackgroundJobs();
        ConfigureCookieConsent(context);
        //<TEMPLATE-REMOVE IF-NOT='LEPTONX'>
        ConfigureTheme();
        //</TEMPLATE-REMOVE>
    }
    
    private void ConfigureCookieConsent(ServiceConfigurationContext context)
    {
        context.Services.AddJellogCookieConsent(options =>
        {
            options.IsEnabled = true;
            options.CookiePolicyUrl = "/CookiePolicy";
            options.PrivacyPolicyUrl = "/PrivacyPolicy";
        });
    }

    //<TEMPLATE-REMOVE IF-NOT='LEPTONX'>
    private void ConfigureTheme()
    {
        Configure<LeptonXThemeOptions>(options =>
        {
            options.DefaultStyle = LeptonXStyleNames.System;
        });
    }
    //</TEMPLATE-REMOVE>

    private void ConfigureBackgroundJobs()
    {
        Configure<JellogBackgroundJobOptions>(options =>
        {
            options.IsJobExecutionEnabled = false;
        });
    }

    private void ConfigureBundles()
    {
        Configure<JellogBundlingOptions>(options =>
        {
            options.StyleBundles.Configure(
                LeptonXThemeBundles.Styles.Global,
                bundle =>
                {
                    bundle.AddFiles("/global-styles.css");
                }
            );
        });
    }

    private void ConfigurePages(IConfiguration configuration)
    {
        Configure<RazorPagesOptions>(options =>
        {
            options.Conventions.AuthorizePage("/HostDashboard", MyProjectNamePermissions.Dashboard.Host);
            options.Conventions.AuthorizePage("/TenantDashboard", MyProjectNamePermissions.Dashboard.Tenant);
        });
    }

    private void ConfigureCache(IConfiguration configuration)
    {
        Configure<JellogDistributedCacheOptions>(options =>
        {
            options.KeyPrefix = "MyProjectName:";
        });
    }

    private void ConfigureUrls(IConfiguration configuration)
    {
        Configure<AppUrlOptions>(options =>
        {
            options.Applications["MVC"].RootUrl = configuration["App:SelfUrl"];
        });
    }

    private void ConfigureMultiTenancy()
    {
        Configure<JellogMultiTenancyOptions>(options => { options.IsEnabled = MultiTenancyConsts.IsEnabled; });
    }

    private void ConfigureAuthentication(ServiceConfigurationContext context, IConfiguration configuration)
    {
        context.Services.AddAuthentication(options =>
            {
                options.DefaultScheme = "Cookies";
                options.DefaultChallengeScheme = "oidc";
            })
            .AddCookie("Cookies", options =>
            {
                options.ExpireTimeSpan = TimeSpan.FromDays(365);
            })
            .AddJellogOpenIdConnect("oidc", options =>
            {
                options.Authority = configuration["AuthServer:Authority"];
                options.RequireHttpsMetadata = Convert.ToBoolean(configuration["AuthServer:RequireHttpsMetadata"]);
                options.ResponseType = OpenIdConnectResponseType.CodeIdToken;

                options.ClientId = configuration["AuthServer:ClientId"];
                options.ClientSecret = configuration["AuthServer:ClientSecret"];

                options.UsePkce = true;
                options.SaveTokens = true;
                options.GetClaimsFromUserInfoEndpoint = true;

                options.Scope.Add("roles");
                options.Scope.Add("email");
                options.Scope.Add("phone");
                options.Scope.Add("MyProjectName");
            });
            /*
            * This configuration is used when the AuthServer is running on docker containers at localhost.
            * Configuring the redirectin URLs for internal network and the web
            */
            if (Convert.ToBoolean(configuration["AuthServer:IsContainerizedOnLocalhost"]))
            {
                context.Services.Configure<OpenIdConnectOptions>("oidc", options =>
                {
                    options.MetadataAddress = configuration["AuthServer:MetaAddress"].EnsureEndsWith('/') +
                                            ".well-known/openid-configuration";

                    var previousOnRedirectToIdentityProvider = options.Events.OnRedirectToIdentityProvider;
                    options.Events.OnRedirectToIdentityProvider = async ctx =>
                    {
                        // Intercept the redirection so the browser navigates to the right URL in your host
                        ctx.ProtocolMessage.IssuerAddress = configuration["AuthServer:Authority"].EnsureEndsWith('/') + "connect/authorize";

                        if (previousOnRedirectToIdentityProvider != null)
                        {
                            await previousOnRedirectToIdentityProvider(ctx);
                        }
                    };
                    var previousOnRedirectToIdentityProviderForSignOut = options.Events.OnRedirectToIdentityProviderForSignOut;
                    options.Events.OnRedirectToIdentityProviderForSignOut = async ctx =>
                    {
                        // Intercept the redirection for signout so the browser navigates to the right URL in your host
                        ctx.ProtocolMessage.IssuerAddress = configuration["AuthServer:Authority"].EnsureEndsWith('/') + "connect/endsession";

                        if (previousOnRedirectToIdentityProviderForSignOut != null)
                        {
                            await previousOnRedirectToIdentityProviderForSignOut(ctx);
                        }
                    };
                });

            }
    }

    private void ConfigureImpersonation(ServiceConfigurationContext context, IConfiguration configuration)
    {
        context.Services.Configure<JellogSaasHostWebOptions>(options =>
        {
            options.EnableTenantImpersonation = true;
        });
        context.Services.Configure<JellogIdentityWebOptions>(options =>
        {
            options.EnableUserImpersonation = true;
        });
    }

    private void ConfigureAutoMapper()
    {
        Configure<JellogAutoMapperOptions>(options =>
        {
            options.AddMaps<MyProjectNameWebModule>();
        });
    }

    private void ConfigureVirtualFileSystem(IWebHostEnvironment hostingEnvironment)
    {
        Configure<JellogVirtualFileSystemOptions>(options =>
        {
            options.FileSets.AddEmbedded<MyProjectNameWebModule>();

            if (hostingEnvironment.IsDevelopment())
            {
                //<TEMPLATE-REMOVE>
                options.FileSets.ReplaceEmbeddedByPhysical<JellogUiModule>(Path.Combine(hostingEnvironment.ContentRootPath, string.Format("..{0}..{0}..{0}..{0}..{0}..{0}..{0}jellog{0}framework{0}src{0}DataGap.Jellog.UI", Path.DirectorySeparatorChar)));
                options.FileSets.ReplaceEmbeddedByPhysical<JellogAspNetCoreMvcUiModule>(Path.Combine(hostingEnvironment.ContentRootPath, string.Format("..{0}..{0}..{0}..{0}..{0}..{0}..{0}jellog{0}framework{0}src{0}DataGap.Jellog.AspNetCore.Mvc.UI", Path.DirectorySeparatorChar)));
                options.FileSets.ReplaceEmbeddedByPhysical<JellogAspNetCoreMvcUiBootstrapModule>(Path.Combine(hostingEnvironment.ContentRootPath, string.Format("..{0}..{0}..{0}..{0}..{0}..{0}..{0}jellog{0}framework{0}src{0}DataGap.Jellog.AspNetCore.Mvc.UI.Bootstrap", Path.DirectorySeparatorChar)));
                options.FileSets.ReplaceEmbeddedByPhysical<JellogAspNetCoreMvcUiThemeSharedModule>(Path.Combine(hostingEnvironment.ContentRootPath, string.Format("..{0}..{0}..{0}..{0}..{0}..{0}..{0}jellog{0}framework{0}src{0}DataGap.Jellog.AspNetCore.Mvc.UI.Theme.Shared", Path.DirectorySeparatorChar)));
                options.FileSets.ReplaceEmbeddedByPhysical<JellogPermissionManagementWebModule>(Path.Combine(hostingEnvironment.ContentRootPath, string.Format("..{0}..{0}..{0}..{0}..{0}..{0}..{0}jellog{0}modules{0}permission-management{0}src{0}DataGap.Jellog.PermissionManagement.Web", Path.DirectorySeparatorChar)));
                options.FileSets.ReplaceEmbeddedByPhysical<JellogIdentityWebModule>(Path.Combine(hostingEnvironment.ContentRootPath, string.Format("..{0}..{0}..{0}..{0}..{0}identity-pro{0}src{0}DataGap.Jellog.Identity.Pro.Web", Path.DirectorySeparatorChar)));
                options.FileSets.ReplaceEmbeddedByPhysical<JellogGdprWebModule>(Path.Combine(hostingEnvironment.ContentRootPath, string.Format("..{0}..{0}..{0}..{0}..{0}gdpr{0}src{0}DataGap.Jellog.Gdpr.Web", Path.DirectorySeparatorChar)));
                options.FileSets.ReplaceEmbeddedByPhysical<LanguageManagementWebModule>(Path.Combine(hostingEnvironment.ContentRootPath, string.Format("..{0}..{0}..{0}..{0}..{0}language-management{0}src{0}DataGap.Jellog.LanguageManagement.Web", Path.DirectorySeparatorChar)));
                options.FileSets.ReplaceEmbeddedByPhysical<JellogOpenIddictProWebModule>(Path.Combine(hostingEnvironment.ContentRootPath, string.Format("..{0}..{0}..{0}..{0}..{0}openiddict{0}src{0}DataGap.Jellog.OpenIddict.Pro.Web", Path.DirectorySeparatorChar)));
                options.FileSets.ReplaceEmbeddedByPhysical<SaasHostWebModule>(Path.Combine(hostingEnvironment.ContentRootPath, string.Format("..{0}..{0}..{0}..{0}..{0}saas{0}src{0}DataGap.Saas.Host.Web", Path.DirectorySeparatorChar)));
                //options.FileSets.ReplaceEmbeddedByPhysical<JellogAspNetCoreMvcUiThemeCommercialModule>(Path.Combine(hostingEnvironment.ContentRootPath, string.Format("..{0}..{0}..{0}..{0}..{0}licensing{0}DataGap.Jellog.AspNetCore.Mvc.UI.Theme.Commercial", Path.DirectorySeparatorChar)));
                options.FileSets.ReplaceEmbeddedByPhysical<JellogAccountAdminWebModule>(Path.Combine(hostingEnvironment.ContentRootPath, string.Format("..{0}..{0}..{0}..{0}..{0}account{0}src{0}DataGap.Jellog.Account.Pro.Admin.Web", Path.DirectorySeparatorChar)));
                //</TEMPLATE-REMOVE>
                options.FileSets.ReplaceEmbeddedByPhysical<MyProjectNameDomainSharedModule>(Path.Combine(hostingEnvironment.ContentRootPath, string.Format("..{0}MyCompanyName.MyProjectName.Domain.Shared", Path.DirectorySeparatorChar)));
                options.FileSets.ReplaceEmbeddedByPhysical<MyProjectNameApplicationContractsModule>(Path.Combine(hostingEnvironment.ContentRootPath, string.Format("..{0}MyCompanyName.MyProjectName.Application.Contracts", Path.DirectorySeparatorChar)));
                options.FileSets.ReplaceEmbeddedByPhysical<MyProjectNameWebModule>(hostingEnvironment.ContentRootPath);
            }
        });
    }

    private void ConfigureNavigationServices(IConfiguration configuration)
    {
        Configure<JellogNavigationOptions>(options =>
        {
            options.MenuContributors.Add(new MyProjectNameMenuContributor(configuration));
        });

        Configure<JellogToolbarOptions>(options =>
        {
            options.Contributors.Add(new MyProjectNameToolbarContributor());
        });
    }

    private void ConfigureSwaggerServices(IServiceCollection services)
    {
        services.AddJellogSwaggerGen(
            options =>
            {
                options.SwaggerDoc("v1", new OpenApiInfo { Title = "MyProjectName API", Version = "v1" });
                options.DocInclusionPredicate((docName, description) => true);
                options.CustomSchemaIds(type => type.FullName);
            }
        );
    }

    private void ConfigureDataProtection(
        ServiceConfigurationContext context,
        IConfiguration configuration,
        IWebHostEnvironment hostingEnvironment)
    {
        var dataProtectionBuilder = context.Services.AddDataProtection().SetApplicationName("MyProjectName");
        if (!hostingEnvironment.IsDevelopment())
        {
            var redis = ConnectionMultiplexer.Connect(configuration["Redis:Configuration"]);
            dataProtectionBuilder.PersistKeysToStackExchangeRedis(redis, "MyProjectName-Protection-Keys");
        }
    }
    
    private void ConfigureDistributedLocking(
                ServiceConfigurationContext context,
                IConfiguration configuration)
    {
        context.Services.AddSingleton<IDistributedLockProvider>(sp =>
        {
            var connection = ConnectionMultiplexer
                .Connect(configuration["Redis:Configuration"]);
            return new RedisDistributedSynchronizationProvider(connection.GetDatabase());
        });
    }

    public override void OnApplicationInitialization(ApplicationInitializationContext context)
    {
        var app = context.GetApplicationBuilder();
        var env = context.GetEnvironment();

        if (env.IsDevelopment())
        {
            app.UseDeveloperExceptionPage();
        }

        app.UseJellogRequestLocalization();

        if (!env.IsDevelopment())
        {
            app.UseErrorPage();
        }

        app.UseJellogCookieConsent();
        app.UseJellogSecurityHeaders();
        app.UseStaticFiles();
        app.UseRouting();
        app.UseAuthentication();

        if (MultiTenancyConsts.IsEnabled)
        {
            app.UseMultiTenancy();
        }

        app.UseAuthorization();
        app.UseSwagger();
        app.UseJellogSwaggerUI(options =>
        {
            options.SwaggerEndpoint("/swagger/v1/swagger.json", "MyProjectName API");
        });
        app.UseJellogSerilogEnrichers();
        app.UseConfiguredEndpoints();
    }
}
