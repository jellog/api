﻿using Microsoft.AspNetCore.Mvc.RazorPages;

namespace MyCompanyName.MyProjectName.Web.Pages;

public class CookiePolicy : PageModel
{
    public void OnGet()
    {
        
    }
}