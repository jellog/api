﻿using Microsoft.AspNetCore.Mvc.RazorPages;

namespace MyCompanyName.MyProjectName.Web.Pages;

public class PrivacyPolicy : PageModel
{
    public void OnGet()
    {
        
    }
}