module.exports = {
    aliases: {
    },
    mappings: {
    }
};