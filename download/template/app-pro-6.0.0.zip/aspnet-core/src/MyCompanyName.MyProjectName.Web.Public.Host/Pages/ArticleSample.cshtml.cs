﻿namespace MyCompanyName.MyProjectName.Web.Public.Pages;

public class ArticleSampleModel : MyProjectNamePublicPageModel
{
    public void OnGet()
    {

    }
}
