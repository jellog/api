﻿using MyCompanyName.MyProjectName.Localization;
using DataGap.Jellog.AspNetCore.Mvc.UI.RazorPages;

namespace MyCompanyName.MyProjectName.Web.Public.Pages;

/* Inherit your Page Model classes from this class.
 */
public abstract class MyProjectNamePublicPageModel : JellogPageModel
{
    protected MyProjectNamePublicPageModel()
    {
        LocalizationResourceType = typeof(MyProjectNameResource);
    }
}
