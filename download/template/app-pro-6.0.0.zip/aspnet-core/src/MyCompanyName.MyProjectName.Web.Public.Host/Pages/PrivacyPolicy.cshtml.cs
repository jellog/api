﻿namespace MyCompanyName.MyProjectName.Web.Public.Pages;

public class PrivacyPolicyModel : MyProjectNamePublicPageModel
{
    public void OnGet()
    {

    }
}
