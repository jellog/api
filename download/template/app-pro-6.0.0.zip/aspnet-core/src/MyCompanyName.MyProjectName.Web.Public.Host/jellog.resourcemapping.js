module.exports = {
    aliases: {
        
    },
    mappings: {
    }
};
