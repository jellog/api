using AutoMapper;

namespace MyCompanyName.MyProjectName.Web;

public class MyProjectNameWebAutoMapperProfile : Profile
{
    public MyProjectNameWebAutoMapperProfile()
    {
        //Define your object mappings here, for the Web project
    }
}
