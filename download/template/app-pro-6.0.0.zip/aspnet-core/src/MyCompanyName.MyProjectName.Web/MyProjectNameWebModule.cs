using System.IO;
using Microsoft.AspNetCore.Authentication.Google;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using MyCompanyName.MyProjectName.EntityFrameworkCore;
using MyCompanyName.MyProjectName.Localization;
using MyCompanyName.MyProjectName.MultiTenancy;
using MyCompanyName.MyProjectName.Permissions;
using MyCompanyName.MyProjectName.Web.Menus;
using Microsoft.OpenApi.Models;
using DataGap.Jellog;
using DataGap.Jellog.Account.Admin.Web;
using DataGap.Jellog.Account.Public.Web;
using DataGap.Jellog.Account.Public.Web.ExternalProviders;
using DataGap.Jellog.AspNetCore.Mvc;
using DataGap.Jellog.AspNetCore.Mvc.Localization;
using DataGap.Jellog.AspNetCore.Mvc.UI;
using DataGap.Jellog.AspNetCore.Mvc.UI.Bootstrap;
using DataGap.Jellog.AspNetCore.Mvc.UI.Theme.Commercial;
using DataGap.Jellog.AspNetCore.Mvc.UI.Theme.Shared;
using DataGap.Jellog.AuditLogging.Web;
using DataGap.Jellog.Autofac;
using DataGap.Jellog.AutoMapper;
using DataGap.Jellog.Identity.Web;
using DataGap.Jellog.LanguageManagement;
using DataGap.Jellog.Modularity;
using DataGap.Jellog.PermissionManagement.Web;
using DataGap.Jellog.TextTemplateManagement.Web;
using DataGap.Jellog.UI.Navigation.Urls;
using DataGap.Jellog.UI;
using DataGap.Jellog.UI.Navigation;
using DataGap.Jellog.VirtualFileSystem;
using DataGap.Saas.Host;
using System;
//<TEMPLATE-REMOVE IF-NOT='PUBLIC-REDIS'>
using Microsoft.AspNetCore.DataProtection;
using StackExchange.Redis;
using DataGap.Jellog.Caching;
using DataGap.Jellog.Caching.StackExchangeRedis;
using DataGap.Jellog.DistributedLocking;
using Medallion.Threading;
using Medallion.Threading.Redis;
//</TEMPLATE-REMOVE>
using Microsoft.AspNetCore.Authentication.MicrosoftAccount;
using Microsoft.AspNetCore.Authentication.Twitter;
using Microsoft.AspNetCore.Extensions.DependencyInjection;
using MyCompanyName.MyProjectName.Web.HealthChecks;
using OpenIddict.Validation.AspNetCore;
using DataGap.Jellog.Account.Web;
using DataGap.Jellog.AspNetCore.Mvc.UI.Bundling;
using DataGap.Jellog.AspNetCore.Mvc.UI.Theme.LeptonX;
using DataGap.Jellog.AspNetCore.Mvc.UI.Theme.LeptonX.Bundling;
using DataGap.Jellog.AspNetCore.Mvc.UI.Theme.Shared.Toolbars;
using DataGap.Jellog.AspNetCore.Serilog;
using DataGap.Jellog.Identity;
using DataGap.Jellog.Swashbuckle;
using DataGap.Jellog.Gdpr.Web;
using DataGap.Jellog.Gdpr.Web.Extensions;
//<TEMPLATE-REMOVE IF-NOT='LEPTONX'>
//using DataGap.Jellog.LeptonX.Shared;
//</TEMPLATE-REMOVE>
using DataGap.Jellog.OpenIddict.Pro.Web;
using DataGap.Jellog.SettingManagement.Web;
//<TEMPLATE-REMOVE IF-NOT='CMS-KIT'>
using DataGap.CmsKit.Pro.Admin.Web;
//</TEMPLATE-REMOVE>

namespace MyCompanyName.MyProjectName.Web;

[DependsOn(
    typeof(MyProjectNameHttpApiModule),
    typeof(MyProjectNameApplicationModule),
    typeof(MyProjectNameEntityFrameworkCoreModule),
    typeof(JellogAutofacModule),
    //<TEMPLATE-REMOVE IF-NOT='PUBLIC-REDIS'>
    typeof(JellogCachingStackExchangeRedisModule),
    typeof(JellogDistributedLockingModule),
    //</TEMPLATE-REMOVE>
    typeof(JellogIdentityWebModule),
    typeof(JellogAccountPublicWebOpenIddictModule),
    typeof(JellogAuditLoggingWebModule),
    typeof(SaasHostWebModule),
    typeof(JellogAccountAdminWebModule),
    typeof(JellogOpenIddictProWebModule),
    typeof(LanguageManagementWebModule),
    //typeof(JellogAspNetCoreMvcUiLeptonXThemeModule),
    typeof(TextTemplateManagementWebModule),
    typeof(JellogGdprWebModule),
    //<TEMPLATE-REMOVE IF-NOT='CMS-KIT'>
    typeof(CmsKitProAdminWebModule),
    //</TEMPLATE-REMOVE>
    typeof(JellogSwashbuckleModule),
    typeof(JellogAspNetCoreSerilogModule)
)]
public class MyProjectNameWebModule : JellogModule
{
    public override void PreConfigureServices(ServiceConfigurationContext context)
    {
        context.Services.PreConfigure<JellogMvcDataAnnotationsLocalizationOptions>(options =>
        {
            options.AddAssemblyResource(
                typeof(MyProjectNameResource),
                typeof(MyProjectNameDomainModule).Assembly,
                typeof(MyProjectNameDomainSharedModule).Assembly,
                typeof(MyProjectNameApplicationModule).Assembly,
                typeof(MyProjectNameApplicationContractsModule).Assembly,
                typeof(MyProjectNameWebModule).Assembly
            );
        });

        PreConfigure<OpenIddictBuilder>(builder =>
        {
            builder.AddValidation(options =>
            {
                options.AddAudiences("MyProjectName");
                options.UseLocalServer();
                options.UseAspNetCore();
            });
        });
    }

    public override void ConfigureServices(ServiceConfigurationContext context)
    {
        var hostingEnvironment = context.Services.GetHostingEnvironment();
        var configuration = context.Services.GetConfiguration();

        ConfigureBundles();
        ConfigureUrls(configuration);
        ConfigurePages(configuration);
        //<TEMPLATE-REMOVE IF-NOT='PUBLIC-REDIS'>
        ConfigureCache(configuration);
        ConfigureDataProtection(context, configuration, hostingEnvironment);
        ConfigureDistributedLocking(context, configuration);
        //</TEMPLATE-REMOVE>
        ConfigureAuthentication(context);
        ConfigureImpersonation(context, configuration);
        ConfigureAutoMapper();
        ConfigureVirtualFileSystem(hostingEnvironment);
        ConfigureNavigationServices();
        ConfigureAutoApiControllers();
        ConfigureSwaggerServices(context.Services);
        ConfigureExternalProviders(context);
        ConfigureHealthChecks(context);
        ConfigureCookieConsent(context);
        //<TEMPLATE-REMOVE IF-NOT='LEPTONX'>
        ConfigureTheme();
        //</TEMPLATE-REMOVE>
    }

    private void ConfigureCookieConsent(ServiceConfigurationContext context)
    {
        context.Services.AddJellogCookieConsent(options =>
        {
            options.IsEnabled = true;
            options.CookiePolicyUrl = "/CookiePolicy";
            options.PrivacyPolicyUrl = "/PrivacyPolicy";
        });
    }

    //<TEMPLATE-REMOVE IF-NOT='LEPTONX'>
    private void ConfigureTheme() 
    {
        Configure<LeptonXThemeOptions>(options =>
        {
            options.DefaultStyle = LeptonXStyleNames.System;
        });
    }
    //</TEMPLATE-REMOVE>

    private void ConfigureHealthChecks(ServiceConfigurationContext context)
    {
        context.Services.AddMyProjectNameHealthChecks();
    }

    private void ConfigureBundles()
    {
        Configure<JellogBundlingOptions>(options =>
        {
            options.StyleBundles.Configure(
                LeptonXThemeBundles.Styles.Global,
                bundle =>
                {
                    bundle.AddFiles("/global-styles.css");
                }
            );
        });
    }

    private void ConfigurePages(IConfiguration configuration)
    {
        Configure<RazorPagesOptions>(options =>
        {
            options.Conventions.AuthorizePage("/HostDashboard", MyProjectNamePermissions.Dashboard.Host);
            options.Conventions.AuthorizePage("/TenantDashboard", MyProjectNamePermissions.Dashboard.Tenant);
        });
    }

    private void ConfigureUrls(IConfiguration configuration)
    {
        Configure<AppUrlOptions>(options =>
        {
            options.Applications["MVC"].RootUrl = configuration["App:SelfUrl"];
        });
    }

    private void ConfigureAuthentication(ServiceConfigurationContext context)
    {
        context.Services.ForwardIdentityAuthenticationForBearer(OpenIddictValidationAspNetCoreDefaults.AuthenticationScheme);
    }

    private void ConfigureImpersonation(ServiceConfigurationContext context, IConfiguration configuration)
    {
        context.Services.Configure<JellogSaasHostWebOptions>(options =>
        {
            options.EnableTenantImpersonation = true;
        });
        context.Services.Configure<JellogIdentityWebOptions>(options =>
        {
            options.EnableUserImpersonation = true;
        });
        context.Services.Configure<JellogAccountOptions>(options =>
        {
            options.TenantAdminUserName = "admin";
            options.ImpersonationTenantPermission = SaasHostPermissions.Tenants.Impersonation;
            options.ImpersonationUserPermission = IdentityPermissions.Users.Impersonation;
        });
    }

    private void ConfigureAutoMapper()
    {
        Configure<JellogAutoMapperOptions>(options =>
        {
            options.AddMaps<MyProjectNameWebModule>();
        });
    }

    private void ConfigureVirtualFileSystem(IWebHostEnvironment hostingEnvironment)
    {
        Configure<JellogVirtualFileSystemOptions>(options =>
        {
            options.FileSets.AddEmbedded<MyProjectNameWebModule>();

            if (hostingEnvironment.IsDevelopment())
            {
                //<TEMPLATE-REMOVE>
                options.FileSets.ReplaceEmbeddedByPhysical<JellogSettingManagementWebModule>(Path.Combine(hostingEnvironment.ContentRootPath, string.Format("..{0}..{0}..{0}..{0}..{0}..{0}..{0}jellog{0}modules{0}setting-management{0}src{0}DataGap.Jellog.SettingManagement.Web", Path.DirectorySeparatorChar)));
                options.FileSets.ReplaceEmbeddedByPhysical<JellogUiModule>(Path.Combine(hostingEnvironment.ContentRootPath, string.Format("..{0}..{0}..{0}..{0}..{0}..{0}..{0}jellog{0}framework{0}src{0}DataGap.Jellog.UI", Path.DirectorySeparatorChar)));
                options.FileSets.ReplaceEmbeddedByPhysical<JellogAspNetCoreMvcUiModule>(Path.Combine(hostingEnvironment.ContentRootPath, string.Format("..{0}..{0}..{0}..{0}..{0}..{0}..{0}jellog{0}framework{0}src{0}DataGap.Jellog.AspNetCore.Mvc.UI", Path.DirectorySeparatorChar)));
                options.FileSets.ReplaceEmbeddedByPhysical<JellogAspNetCoreMvcUiBootstrapModule>(Path.Combine(hostingEnvironment.ContentRootPath, string.Format("..{0}..{0}..{0}..{0}..{0}..{0}..{0}jellog{0}framework{0}src{0}DataGap.Jellog.AspNetCore.Mvc.UI.Bootstrap", Path.DirectorySeparatorChar)));
                options.FileSets.ReplaceEmbeddedByPhysical<JellogAspNetCoreMvcUiThemeSharedModule>(Path.Combine(hostingEnvironment.ContentRootPath, string.Format("..{0}..{0}..{0}..{0}..{0}..{0}..{0}jellog{0}framework{0}src{0}DataGap.Jellog.AspNetCore.Mvc.UI.Theme.Shared", Path.DirectorySeparatorChar)));
                options.FileSets.ReplaceEmbeddedByPhysical<JellogPermissionManagementWebModule>(Path.Combine(hostingEnvironment.ContentRootPath, string.Format("..{0}..{0}..{0}..{0}..{0}..{0}..{0}jellog{0}modules{0}permission-management{0}src{0}DataGap.Jellog.PermissionManagement.Web", Path.DirectorySeparatorChar)));
                options.FileSets.ReplaceEmbeddedByPhysical<JellogIdentityWebModule>(Path.Combine(hostingEnvironment.ContentRootPath, string.Format("..{0}..{0}..{0}..{0}..{0}identity-pro{0}src{0}DataGap.Jellog.Identity.Pro.Web", Path.DirectorySeparatorChar)));
                options.FileSets.ReplaceEmbeddedByPhysical<JellogGdprWebModule>(Path.Combine(hostingEnvironment.ContentRootPath, string.Format("..{0}..{0}..{0}..{0}..{0}gdpr{0}src{0}DataGap.Jellog.Gdpr.Web", Path.DirectorySeparatorChar)));
                options.FileSets.ReplaceEmbeddedByPhysical<JellogAccountPublicWebModule>(Path.Combine(hostingEnvironment.ContentRootPath, string.Format("..{0}..{0}..{0}..{0}..{0}account{0}src{0}DataGap.Jellog.Account.Pro.Public.Web", Path.DirectorySeparatorChar)));
                options.FileSets.ReplaceEmbeddedByPhysical<JellogAccountPublicWebOpenIddictModule>(Path.Combine(hostingEnvironment.ContentRootPath, string.Format("..{0}..{0}..{0}..{0}..{0}account{0}src{0}DataGap.Jellog.Account.Pro.Public.Web.OpenIddict", Path.DirectorySeparatorChar)));
                options.FileSets.ReplaceEmbeddedByPhysical<JellogAccountAdminWebModule>(Path.Combine(hostingEnvironment.ContentRootPath, string.Format("..{0}..{0}..{0}..{0}..{0}account{0}src{0}DataGap.Jellog.Account.Pro.Admin.Web", Path.DirectorySeparatorChar)));
                options.FileSets.ReplaceEmbeddedByPhysical<JellogAuditLoggingWebModule>(Path.Combine(hostingEnvironment.ContentRootPath, string.Format("..{0}..{0}..{0}..{0}..{0}audit-logging{0}src{0}DataGap.Jellog.AuditLogging.Web", Path.DirectorySeparatorChar)));
                options.FileSets.ReplaceEmbeddedByPhysical<LanguageManagementWebModule>(Path.Combine(hostingEnvironment.ContentRootPath, string.Format("..{0}..{0}..{0}..{0}..{0}language-management{0}src{0}DataGap.Jellog.LanguageManagement.Web", Path.DirectorySeparatorChar)));
                options.FileSets.ReplaceEmbeddedByPhysical<JellogOpenIddictProWebModule>(Path.Combine(hostingEnvironment.ContentRootPath, string.Format("..{0}..{0}..{0}..{0}..{0}openiddict{0}src{0}DataGap.Jellog.OpenIddict.Pro.Web", Path.DirectorySeparatorChar)));
                options.FileSets.ReplaceEmbeddedByPhysical<SaasHostWebModule>(Path.Combine(hostingEnvironment.ContentRootPath, string.Format("..{0}..{0}..{0}..{0}..{0}saas{0}src{0}DataGap.Saas.Host.Web", Path.DirectorySeparatorChar)));
                options.FileSets.ReplaceEmbeddedByPhysical<JellogAspNetCoreMvcUiThemeCommercialModule>(Path.Combine(hostingEnvironment.ContentRootPath, string.Format("..{0}..{0}..{0}..{0}..{0}licensing{0}DataGap.Jellog.AspNetCore.Mvc.UI.Theme.Commercial", Path.DirectorySeparatorChar)));
                //</TEMPLATE-REMOVE>
                options.FileSets.ReplaceEmbeddedByPhysical<MyProjectNameDomainSharedModule>(Path.Combine(hostingEnvironment.ContentRootPath, string.Format("..{0}MyCompanyName.MyProjectName.Domain.Shared", Path.DirectorySeparatorChar)));
                options.FileSets.ReplaceEmbeddedByPhysical<MyProjectNameDomainModule>(Path.Combine(hostingEnvironment.ContentRootPath, string.Format("..{0}MyCompanyName.MyProjectName.Domain", Path.DirectorySeparatorChar)));
                options.FileSets.ReplaceEmbeddedByPhysical<MyProjectNameApplicationContractsModule>(Path.Combine(hostingEnvironment.ContentRootPath, string.Format("..{0}MyCompanyName.MyProjectName.Application.Contracts", Path.DirectorySeparatorChar)));
                options.FileSets.ReplaceEmbeddedByPhysical<MyProjectNameApplicationModule>(Path.Combine(hostingEnvironment.ContentRootPath, string.Format("..{0}MyCompanyName.MyProjectName.Application", Path.DirectorySeparatorChar)));
                options.FileSets.ReplaceEmbeddedByPhysical<MyProjectNameHttpApiModule>(Path.Combine(hostingEnvironment.ContentRootPath, string.Format("..{0}..{0}src{0}MyCompanyName.MyProjectName.HttpApi", Path.DirectorySeparatorChar)));
                options.FileSets.ReplaceEmbeddedByPhysical<MyProjectNameWebModule>(hostingEnvironment.ContentRootPath);
            }
        });
    }

    private void ConfigureNavigationServices()
    {
        Configure<JellogNavigationOptions>(options =>
        {
            options.MenuContributors.Add(new MyProjectNameMenuContributor());
        });

        Configure<JellogToolbarOptions>(options =>
        {
            options.Contributors.Add(new MyProjectNameToolbarContributor());
        });
    }

    private void ConfigureAutoApiControllers()
    {
        Configure<JellogAspNetCoreMvcOptions>(options =>
        {
            options.ConventionalControllers.Create(typeof(MyProjectNameApplicationModule).Assembly);
        });
    }

    private void ConfigureSwaggerServices(IServiceCollection services)
    {
        services.AddJellogSwaggerGen(
            options =>
            {
                options.SwaggerDoc("v1", new OpenApiInfo { Title = "MyProjectName API", Version = "v1" });
                options.DocInclusionPredicate((docName, description) => true);
                options.CustomSchemaIds(type => type.FullName);
            }
        );
    }

    private void ConfigureExternalProviders(ServiceConfigurationContext context)
    {
        context.Services.AddAuthentication()
            .AddGoogle(GoogleDefaults.AuthenticationScheme, _ => { })
            .WithDynamicOptions<GoogleOptions, GoogleHandler>(
                GoogleDefaults.AuthenticationScheme,
                options =>
                {
                    options.WithProperty(x => x.ClientId);
                    options.WithProperty(x => x.ClientSecret, isSecret: true);
                }
            )
            .AddMicrosoftAccount(MicrosoftAccountDefaults.AuthenticationScheme, options =>
            {
                    //Personal Microsoft accounts as an example.
                    options.AuthorizationEndpoint = "https://login.microsoftonline.com/consumers/oauth2/v2.0/authorize";
                options.TokenEndpoint = "https://login.microsoftonline.com/consumers/oauth2/v2.0/token";
            })
            .WithDynamicOptions<MicrosoftAccountOptions, MicrosoftAccountHandler>(
                MicrosoftAccountDefaults.AuthenticationScheme,
                options =>
                {
                    options.WithProperty(x => x.ClientId);
                    options.WithProperty(x => x.ClientSecret, isSecret: true);
                }
            )
            .AddTwitter(TwitterDefaults.AuthenticationScheme, options => options.RetrieveUserDetails = true)
            .WithDynamicOptions<TwitterOptions, TwitterHandler>(
                TwitterDefaults.AuthenticationScheme,
                options =>
                {
                    options.WithProperty(x => x.ConsumerKey);
                    options.WithProperty(x => x.ConsumerSecret, isSecret: true);
                }
            );
    }

    //<TEMPLATE-REMOVE IF-NOT='PUBLIC-REDIS'>
    private void ConfigureCache(IConfiguration configuration)
    {
        Configure<JellogDistributedCacheOptions>(options =>
        {
            options.KeyPrefix = "MyProjectName:";
        });
    }

    private void ConfigureDataProtection(
        ServiceConfigurationContext context,
        IConfiguration configuration,
        IWebHostEnvironment hostingEnvironment)
    {
        var dataProtectionBuilder = context.Services.AddDataProtection().SetApplicationName("MyProjectName");
        if (!hostingEnvironment.IsDevelopment())
        {
            var redis = ConnectionMultiplexer.Connect(configuration["Redis:Configuration"]);
            dataProtectionBuilder.PersistKeysToStackExchangeRedis(redis, "MyProjectName-Protection-Keys");
        }
    }
    
    private void ConfigureDistributedLocking(
        ServiceConfigurationContext context,
        IConfiguration configuration)
    {
        context.Services.AddSingleton<IDistributedLockProvider>(sp =>
        {
            var connection = ConnectionMultiplexer
                .Connect(configuration["Redis:Configuration"]);
            return new RedisDistributedSynchronizationProvider(connection.GetDatabase());
        });
    }
    //</TEMPLATE-REMOVE>

    public override void OnApplicationInitialization(ApplicationInitializationContext context)
    {
        var app = context.GetApplicationBuilder();
        var env = context.GetEnvironment();

        if (env.IsDevelopment())
        {
            app.UseDeveloperExceptionPage();
        }

        app.UseJellogRequestLocalization();

        if (!env.IsDevelopment())
        {
            app.UseErrorPage();
            app.UseHsts();
        }

        app.UseJellogCookieConsent();
        app.UseHttpsRedirection();
        app.UseCorrelationId();
        app.UseJellogSecurityHeaders();
        app.UseStaticFiles();
        app.UseRouting();
        app.UseAuthentication();
        app.UseJellogOpenIddictValidation();

        if (MultiTenancyConsts.IsEnabled)
        {
            app.UseMultiTenancy();
        }

        app.UseUnitOfWork();
        app.UseAuthorization();
        app.UseSwagger();
        app.UseJellogSwaggerUI(options =>
        {
            options.SwaggerEndpoint("/swagger/v1/swagger.json", "MyProjectName API");
        });
        app.UseAuditing();
        app.UseJellogSerilogEnrichers();
        app.UseConfiguredEndpoints();
    }
}
