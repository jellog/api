﻿using System.Threading;
using System.Threading.Tasks;
using Microsoft.Extensions.Hosting;
using DataGap.Jellog;

namespace MyCompanyName.MyProjectName;

public class MyProjectNameHostedService : IHostedService
{
    private readonly IJellogApplicationWithExternalServiceProvider _jellogApplication;
    private readonly HelloWorldService _helloWorldService;

    public MyProjectNameHostedService(HelloWorldService helloWorldService, IJellogApplicationWithExternalServiceProvider jellogApplication)
    {
        _helloWorldService = helloWorldService;
        _jellogApplication = jellogApplication;
    }

    public async Task StartAsync(CancellationToken cancellationToken)
    {
        await _helloWorldService.SayHelloAsync();
    }

    public async Task StopAsync(CancellationToken cancellationToken)
    {
        await _jellogApplication.ShutdownAsync();
    }
}
