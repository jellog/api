﻿namespace MyCompanyName.MyProjectName.Blazor.Server.Navigation;

public class MyProjectNameMenus
{
    private const string Prefix = "MyProjectName";

    public const string Home = Prefix + ".Home";
}
