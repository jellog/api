﻿using DataGap.Jellog.Ui.Branding;

namespace MyCompanyName.MyProjectName.Blazor;

public class MyProjectNameBrandingProvider : DefaultBrandingProvider
{
    public override string AppName => "MyProjectName";
}
