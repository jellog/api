﻿namespace MyCompanyName.MyProjectName.PublicWeb.Menus;

public class MyProjectNamePublicWebMenus
{
    private const string Prefix = "MyProjectName.Public";

    public const string HomePage = Prefix + ".HomePage";
    public const string ProductPage = Prefix + ".ProductPage";
}
