﻿using DataGap.Jellog.AspNetCore.Components;

namespace MyCompanyName.MyProjectName.Blazor;

public abstract class MyProjectNameComponentBase : JellogComponentBase
{
    protected MyProjectNameComponentBase()
    {

    }
}
