﻿using Microsoft.AspNetCore.Mvc;
using DataGap.Jellog.AspNetCore.Mvc;

namespace MyCompanyName.MyProjectName.PublicWeb.Components.Toolbar.LoginLink;

public class LoginLinkViewComponent : JellogViewComponent
{
    public virtual IViewComponentResult Invoke()
    {
        return View("~/Components/Toolbar/LoginLink/Default.cshtml");
    }
}
