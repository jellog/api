﻿using System.Collections.Generic;
using System.Threading.Tasks;
using MyCompanyName.MyProjectName.ProductService.Products;
using DataGap.Jellog.AspNetCore.Mvc.UI.RazorPages;

namespace MyCompanyName.MyProjectName.PublicWeb.Pages.Products;

public class Index : JellogPageModel
{
    private readonly IProductPublicAppService _productPublicAppService;

    public Index(IProductPublicAppService productPublicAppService)
    {
        _productPublicAppService = productPublicAppService;
    }

    public List<ProductDto> Products { get; set; }

    public async Task OnGet()
    {
        Products = await _productPublicAppService.GetListAsync();
    }
}
