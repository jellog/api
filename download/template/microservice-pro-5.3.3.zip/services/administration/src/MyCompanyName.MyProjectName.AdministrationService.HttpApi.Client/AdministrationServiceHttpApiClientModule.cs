﻿using Microsoft.Extensions.DependencyInjection;
using DataGap.Jellog.AuditLogging;
using DataGap.Jellog.FeatureManagement;
using DataGap.Jellog.LanguageManagement;
using DataGap.Jellog.LeptonTheme.Management;
using DataGap.Jellog.Modularity;
using DataGap.Jellog.PermissionManagement;
using DataGap.Jellog.SettingManagement;
using DataGap.Jellog.TextTemplateManagement;

namespace MyCompanyName.MyProjectName.AdministrationService;

[DependsOn(
    typeof(AdministrationServiceApplicationContractsModule),
    typeof(JellogPermissionManagementHttpApiClientModule),
    typeof(JellogFeatureManagementHttpApiClientModule),
    typeof(JellogSettingManagementHttpApiClientModule),
    typeof(JellogAuditLoggingHttpApiClientModule),
    typeof(LeptonThemeManagementHttpApiClientModule),
    typeof(LanguageManagementHttpApiClientModule),
    typeof(TextTemplateManagementHttpApiClientModule)
)]
public class AdministrationServiceHttpApiClientModule : JellogModule
{
    public override void ConfigureServices(ServiceConfigurationContext context)
    {
        context.Services.AddHttpClientProxies(
            typeof(AdministrationServiceApplicationContractsModule).Assembly,
            AdministrationServiceRemoteServiceConsts.RemoteServiceName
        );
    }
}
