﻿using DataGap.Jellog.AuditLogging;
using DataGap.Jellog.FeatureManagement;
using DataGap.Jellog.LanguageManagement;
using DataGap.Jellog.LeptonTheme;
using DataGap.Jellog.Modularity;
using DataGap.Jellog.PermissionManagement.HttpApi;
using DataGap.Jellog.SettingManagement;
using DataGap.Jellog.TextTemplateManagement;

namespace MyCompanyName.MyProjectName.AdministrationService;

[DependsOn(
    typeof(AdministrationServiceApplicationContractsModule),
    typeof(JellogPermissionManagementHttpApiModule),
    typeof(JellogFeatureManagementHttpApiModule),
    typeof(JellogSettingManagementHttpApiModule),
    typeof(JellogAuditLoggingHttpApiModule),
    typeof(LeptonThemeManagementHttpApiModule),
    typeof(LanguageManagementHttpApiModule),
    typeof(TextTemplateManagementHttpApiModule)
)]
public class AdministrationServiceHttpApiModule : JellogModule
{
}
