﻿using DataGap.Jellog.Account.Admin.Web;
using DataGap.Jellog.AuditLogging.Web;
using DataGap.Jellog.LanguageManagement;
using DataGap.Jellog.LeptonTheme.Management;
using DataGap.Jellog.Modularity;
using DataGap.Jellog.TextTemplateManagement.Web;
using DataGap.Jellog.VirtualFileSystem;

namespace MyCompanyName.MyProjectName.AdministrationService.Web;

[DependsOn(
    typeof(LeptonThemeManagementWebModule),
    typeof(JellogAuditLoggingWebModule),
    typeof(LanguageManagementWebModule),
    typeof(TextTemplateManagementWebModule),
    typeof(JellogAccountAdminWebModule),
    typeof(AdministrationServiceApplicationContractsModule)
    )]
public class AdministrationServiceWebModule : JellogModule
{
    public override void ConfigureServices(ServiceConfigurationContext context)
    {
        Configure<JellogVirtualFileSystemOptions>(options =>
        {
            options.FileSets.AddEmbedded<AdministrationServiceWebModule>();
        });
    }
}
