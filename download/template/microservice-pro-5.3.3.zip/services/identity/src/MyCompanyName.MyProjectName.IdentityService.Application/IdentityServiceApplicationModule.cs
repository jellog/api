﻿using Microsoft.Extensions.DependencyInjection;
using DataGap.Jellog.Account;
using DataGap.Jellog.AutoMapper;
using DataGap.Jellog.Identity;
using DataGap.Jellog.IdentityServer;
using DataGap.Jellog.Modularity;

namespace MyCompanyName.MyProjectName.IdentityService;

[DependsOn(
    typeof(JellogIdentityApplicationModule),
    typeof(JellogIdentityServerApplicationModule),
    typeof(IdentityServiceDomainModule),
    typeof(JellogAccountAdminApplicationModule),
    typeof(IdentityServiceApplicationContractsModule)
)]
public class IdentityServiceApplicationModule : JellogModule
{
    public override void ConfigureServices(ServiceConfigurationContext context)
    {
        context.Services.AddAutoMapperObjectMapper<IdentityServiceApplicationModule>();
        Configure<JellogAutoMapperOptions>(options =>
        {
            options.AddMaps<IdentityServiceApplicationModule>(validate: true);
        });
    }
}
