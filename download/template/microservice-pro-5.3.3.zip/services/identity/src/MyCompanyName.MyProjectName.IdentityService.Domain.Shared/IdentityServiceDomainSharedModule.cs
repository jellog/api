﻿using MyCompanyName.MyProjectName.IdentityService.Localization;
using DataGap.Jellog.Identity;
using DataGap.Jellog.IdentityServer;
using DataGap.Jellog.Localization;
using DataGap.Jellog.Modularity;
using DataGap.Jellog.Validation.Localization;
using DataGap.Jellog.VirtualFileSystem;

namespace MyCompanyName.MyProjectName.IdentityService;

[DependsOn(
    typeof(JellogIdentityProDomainSharedModule),
    typeof(JellogIdentityServerDomainSharedModule)
)]
public class IdentityServiceDomainSharedModule : JellogModule
{
    public override void PreConfigureServices(ServiceConfigurationContext context)
    {
        IdentityServiceModuleExtensionConfigurator.Configure();
    }

    public override void ConfigureServices(ServiceConfigurationContext context)
    {
        Configure<JellogVirtualFileSystemOptions>(options =>
        {
            options.FileSets.AddEmbedded<IdentityServiceDomainSharedModule>();
        });

        Configure<JellogLocalizationOptions>(options =>
        {
            options.Resources
                .Add<IdentityServiceResource>("en")
                .AddBaseTypes(typeof(JellogValidationResource))
                .AddVirtualJson("/Localization/IdentityService");
        });

    }
}
