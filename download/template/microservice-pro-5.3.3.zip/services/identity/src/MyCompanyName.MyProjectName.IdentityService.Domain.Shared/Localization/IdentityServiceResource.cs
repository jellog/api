﻿using DataGap.Jellog.Localization;

namespace MyCompanyName.MyProjectName.IdentityService.Localization;

[LocalizationResourceName("IdentityService")]
public class IdentityServiceResource
{

}
