using Microsoft.Extensions.DependencyInjection;
using DataGap.Jellog.EntityFrameworkCore;
using DataGap.Jellog.EntityFrameworkCore.SqlServer;
using DataGap.Jellog.Identity.EntityFrameworkCore;
using DataGap.Jellog.IdentityServer.EntityFrameworkCore;
using DataGap.Jellog.Modularity;

namespace MyCompanyName.MyProjectName.IdentityService.EntityFramework;

[DependsOn(
    typeof(IdentityServiceDomainModule),
    typeof(JellogIdentityProEntityFrameworkCoreModule),
    typeof(JellogIdentityServerEntityFrameworkCoreModule),
    typeof(JellogEntityFrameworkCoreSqlServerModule)
)]
public class IdentityServiceEntityFrameworkCoreModule : JellogModule
{
    public override void PreConfigureServices(ServiceConfigurationContext context)
    {
        IdentityServiceEfCoreEntityExtensionMappings.Configure();
    }

    public override void ConfigureServices(ServiceConfigurationContext context)
    {
        context.Services.AddJellogDbContext<IdentityServiceDbContext>(options =>
        {
            options.ReplaceDbContext<IIdentityDbContext>();
            options.ReplaceDbContext<IIdentityServerDbContext>();

                /* includeAllEntities: true allows to use IRepository<TEntity, TKey> also for non aggregate root entities */
            options.AddDefaultRepositories(includeAllEntities: true);
        });

        Configure<JellogDbContextOptions>(options =>
        {
            options.Configure<IdentityServiceDbContext>(c =>
            {
                c.UseSqlServer(b =>
                {
                    b.MigrationsHistoryTable("__IdentityService_Migrations");
                });
            });
        });
    }
}
