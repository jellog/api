﻿using DataGap.Jellog.Account;
using DataGap.Jellog.Identity;
using DataGap.Jellog.IdentityServer;
using DataGap.Jellog.Modularity;

namespace MyCompanyName.MyProjectName.IdentityService;

[DependsOn(
    typeof(IdentityServiceApplicationContractsModule),
    typeof(JellogIdentityHttpApiModule),
    typeof(JellogIdentityServerHttpApiModule),
    typeof(JellogAccountAdminHttpApiModule)
    )]
public class IdentityServiceHttpApiModule : JellogModule
{

}
