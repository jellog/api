﻿namespace MyCompanyName.MyProjectName.IdentityService.Samples;

public class SampleAppService_Tests : IdentityServiceDomainTestBase
{
    //private readonly ISampleAppService _sampleAppService;

    public SampleAppService_Tests()
    {
        //_sampleAppService = GetRequiredService<ISampleAppService>();
    }

    // [Fact]
    // public async Task Method1Async()
    // {
    //
    // }
}
