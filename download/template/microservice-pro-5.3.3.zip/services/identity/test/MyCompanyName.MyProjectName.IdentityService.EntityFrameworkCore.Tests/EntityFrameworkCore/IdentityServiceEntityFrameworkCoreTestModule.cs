﻿using Microsoft.Data.Sqlite;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Infrastructure;
using Microsoft.EntityFrameworkCore.Storage;
using MyCompanyName.MyProjectName.IdentityService.EntityFramework;
using DataGap.Jellog.EntityFrameworkCore;
using DataGap.Jellog.EntityFrameworkCore.Sqlite;
using DataGap.Jellog.Modularity;

namespace MyCompanyName.MyProjectName.IdentityService.EntityFrameworkCore;

[DependsOn(
    typeof(IdentityServiceTestBaseModule),
    typeof(IdentityServiceEntityFrameworkCoreModule),
    typeof(JellogEntityFrameworkCoreSqliteModule)
)]
public class IdentityServiceEntityFrameworkCoreTestModule : JellogModule
{
    public override void ConfigureServices(ServiceConfigurationContext context)
    {
        var sqliteConnection = CreateDatabaseAndGetConnection();

        Configure<JellogDbContextOptions>(options =>
        {
            options.Configure<IdentityServiceDbContext>(c =>
            {
                c.DbContextOptions.UseSqlite(sqliteConnection);
            });
        });
    }

    private static SqliteConnection CreateDatabaseAndGetConnection()
    {
        var connection = new SqliteConnection("Data Source=:memory:");
        connection.Open();

        new IdentityServiceDbContext(
            new DbContextOptionsBuilder<IdentityServiceDbContext>().UseSqlite(connection).Options
        ).GetService<IRelationalDatabaseCreator>().CreateTables();

        return connection;
    }
}
