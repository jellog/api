using AutoMapper;
using MyCompanyName.MyProjectName.ProductService.Products;

namespace MyCompanyName.MyProjectName.ProductService.Blazor;

public class ProductServiceBlazorAutoMapperProfile : Profile
{
    public ProductServiceBlazorAutoMapperProfile()
    {
        CreateMap<ProductDto, ProductUpdateDto>();
    }
}
