﻿using Microsoft.Extensions.DependencyInjection;
using MyCompanyName.MyProjectName.ProductService.Blazor.Menus;
using DataGap.Jellog.AspNetCore.Components.Web.Theming.Routing;
using DataGap.Jellog.AspNetCore.Components.Web.Theming;
using DataGap.Jellog.AutoMapper;
using DataGap.Jellog.Modularity;
using DataGap.Jellog.UI.Navigation;

namespace MyCompanyName.MyProjectName.ProductService.Blazor;

[DependsOn(
    typeof(ProductServiceApplicationContractsModule),
    typeof(JellogAspNetCoreComponentsWebThemingModule),
    typeof(JellogAutoMapperModule)
    )]
public class ProductServiceBlazorModule : JellogModule
{
    public override void ConfigureServices(ServiceConfigurationContext context)
    {
        context.Services.AddAutoMapperObjectMapper<ProductServiceBlazorModule>();

        Configure<JellogAutoMapperOptions>(options =>
        {
            options.AddProfile<ProductServiceBlazorAutoMapperProfile>(validate: true);
        });

        Configure<JellogNavigationOptions>(options =>
        {
            options.MenuContributors.Add(new ProductServiceMenuContributor());
        });

        Configure<JellogRouterOptions>(options =>
        {
            options.AdditionalAssemblies.Add(typeof(ProductServiceBlazorModule).Assembly);
        });
    }
}
