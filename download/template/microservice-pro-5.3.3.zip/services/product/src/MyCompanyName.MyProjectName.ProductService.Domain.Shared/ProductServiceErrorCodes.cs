﻿namespace MyCompanyName.MyProjectName.ProductService;

public static class ProductServiceErrorCodes
{
    //Add your business exception error codes here...
}
