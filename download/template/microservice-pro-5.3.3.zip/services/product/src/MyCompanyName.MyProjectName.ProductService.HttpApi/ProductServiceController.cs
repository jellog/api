﻿using MyCompanyName.MyProjectName.ProductService.Localization;
using DataGap.Jellog.AspNetCore.Mvc;

namespace MyCompanyName.MyProjectName.ProductService;

public abstract class ProductServiceController : JellogController
{
    protected ProductServiceController()
    {
        LocalizationResource = typeof(ProductServiceResource);
    }
}
