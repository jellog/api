﻿using Localization.Resources.JellogUi;
using Microsoft.Extensions.DependencyInjection;
using MyCompanyName.MyProjectName.ProductService.Localization;
using DataGap.Jellog.AspNetCore.Mvc;
using DataGap.Jellog.Localization;
using DataGap.Jellog.Modularity;

namespace MyCompanyName.MyProjectName.ProductService;

[DependsOn(
    typeof(ProductServiceApplicationContractsModule),
    typeof(JellogAspNetCoreMvcModule))]
public class ProductServiceHttpApiModule : JellogModule
{
    public override void PreConfigureServices(ServiceConfigurationContext context)
    {
        PreConfigure<IMvcBuilder>(mvcBuilder =>
        {
            mvcBuilder.AddApplicationPartIfNotExists(typeof(ProductServiceHttpApiModule).Assembly);
        });
    }

    public override void ConfigureServices(ServiceConfigurationContext context)
    {
        Configure<JellogLocalizationOptions>(options =>
        {
            options.Resources
                .Get<ProductServiceResource>()
                .AddBaseTypes(typeof(JellogUiResource));
        });
    }
}
