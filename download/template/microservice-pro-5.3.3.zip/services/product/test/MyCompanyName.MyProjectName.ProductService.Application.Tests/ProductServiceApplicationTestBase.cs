﻿namespace MyCompanyName.MyProjectName.ProductService;

/* Inherit from this class for your application layer tests.
 * See ProductAppService_Tests for example.
 */
public abstract class ProductServiceApplicationTestBase : ProductServiceTestBase<ProductServiceApplicationTestModule>
{

}
