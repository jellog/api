﻿namespace MyCompanyName.MyProjectName.AdministrationService;

public static class AdministrationServiceRemoteServiceConsts
{
    public const string RemoteServiceName = "AdministrationService";
}
