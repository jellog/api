﻿using MyCompanyName.MyProjectName.AdministrationService.Localization;
using DataGap.Jellog.Authorization.Permissions;
using DataGap.Jellog.Localization;
using DataGap.Jellog.MultiTenancy;

namespace MyCompanyName.MyProjectName.AdministrationService.Permissions;

public class AdministrationServicePermissionDefinitionProvider : PermissionDefinitionProvider
{
    public override void Define(IPermissionDefinitionContext context)
    {
        var administrationServiceGroup = context.AddGroup(AdministrationServicePermissions.GroupName);

        administrationServiceGroup.AddPermission(AdministrationServicePermissions.Dashboard.Host, L("Permission:Dashboard"), MultiTenancySides.Host);
        administrationServiceGroup.AddPermission(AdministrationServicePermissions.Dashboard.Tenant, L("Permission:Dashboard"), MultiTenancySides.Tenant);
    }

    private static LocalizableString L(string name)
    {
        return LocalizableString.Create<AdministrationServiceResource>(name);
    }
}
