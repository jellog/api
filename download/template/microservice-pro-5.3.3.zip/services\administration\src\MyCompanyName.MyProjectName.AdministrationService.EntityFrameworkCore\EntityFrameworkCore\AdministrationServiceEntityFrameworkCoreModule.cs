﻿using Microsoft.Extensions.DependencyInjection;
using DataGap.Jellog.AuditLogging.EntityFrameworkCore;
using DataGap.Jellog.BlobStoring.Database.EntityFrameworkCore;
using DataGap.Jellog.EntityFrameworkCore;
using DataGap.Jellog.EntityFrameworkCore.SqlServer;
using DataGap.Jellog.FeatureManagement.EntityFrameworkCore;
using DataGap.Jellog.LanguageManagement.EntityFrameworkCore;
using DataGap.Jellog.Modularity;
using DataGap.Jellog.PermissionManagement.EntityFrameworkCore;
using DataGap.Jellog.SettingManagement.EntityFrameworkCore;
using DataGap.Jellog.TextTemplateManagement.EntityFrameworkCore;

namespace MyCompanyName.MyProjectName.AdministrationService.EntityFrameworkCore;

[DependsOn(
    typeof(AdministrationServiceDomainModule),
    typeof(JellogEntityFrameworkCoreSqlServerModule),
    typeof(JellogPermissionManagementEntityFrameworkCoreModule),
    typeof(JellogFeatureManagementEntityFrameworkCoreModule),
    typeof(JellogSettingManagementEntityFrameworkCoreModule),
    typeof(JellogAuditLoggingEntityFrameworkCoreModule),
    typeof(BlobStoringDatabaseEntityFrameworkCoreModule),
    typeof(LanguageManagementEntityFrameworkCoreModule),
    typeof(TextTemplateManagementEntityFrameworkCoreModule)
)]
public class AdministrationServiceEntityFrameworkCoreModule : JellogModule
{
    public override void PreConfigureServices(ServiceConfigurationContext context)
    {
        AdministrationServiceEfCoreEntityExtensionMappings.Configure();
    }

    public override void ConfigureServices(ServiceConfigurationContext context)
    {
        context.Services.AddJellogDbContext<AdministrationServiceDbContext>(options =>
        {
            options.ReplaceDbContext<IPermissionManagementDbContext>();
            options.ReplaceDbContext<ISettingManagementDbContext>();
            options.ReplaceDbContext<IFeatureManagementDbContext>();
            options.ReplaceDbContext<IAuditLoggingDbContext>();
            options.ReplaceDbContext<ILanguageManagementDbContext>();
            options.ReplaceDbContext<ITextTemplateManagementDbContext>();
            options.ReplaceDbContext<IBlobStoringDbContext>();

                /* includeAllEntities: true allows to use IRepository<TEntity, TKey> also for non aggregate root entities */
            options.AddDefaultRepositories(includeAllEntities: true);
        });

        Configure<JellogDbContextOptions>(options =>
        {
            options.Configure<AdministrationServiceDbContext>(c =>
            {
                c.UseSqlServer(b =>
                {
                    b.MigrationsHistoryTable("__AdministrationService_Migrations");
                });
            });
        });
    }
}
