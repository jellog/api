using AutoMapper;

namespace MyCompanyName.MyProjectName.IdentityService;

public class IdentityServiceApplicationAutoMapperProfile : Profile
{
    public IdentityServiceApplicationAutoMapperProfile()
    {

    }
}
