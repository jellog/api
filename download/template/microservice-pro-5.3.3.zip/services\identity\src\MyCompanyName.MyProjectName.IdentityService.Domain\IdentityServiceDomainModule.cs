﻿using DataGap.Jellog.Identity;
using DataGap.Jellog.IdentityServer;
using DataGap.Jellog.Modularity;

namespace MyCompanyName.MyProjectName.IdentityService;

[DependsOn(
    typeof(JellogIdentityProDomainModule),
    typeof(JellogIdentityServerDomainModule),
    typeof(IdentityServiceDomainSharedModule)
)]
public class IdentityServiceDomainModule : JellogModule
{
}
