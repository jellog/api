﻿using Microsoft.AspNetCore.Mvc;
using DataGap.Jellog.AspNetCore.Mvc;

namespace MyCompanyName.MyProjectName.IdentityService.Controllers;

public class HomeController : JellogController
{
    public ActionResult Index()
    {
        return Redirect("/swagger");
    }
}
