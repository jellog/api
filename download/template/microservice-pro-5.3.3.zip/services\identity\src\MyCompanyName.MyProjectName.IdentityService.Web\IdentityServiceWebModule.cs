﻿using DataGap.Jellog.Identity.Web;
using DataGap.Jellog.IdentityServer.Web;
using DataGap.Jellog.Modularity;
using DataGap.Jellog.VirtualFileSystem;

namespace MyCompanyName.MyProjectName.IdentityService.Web;

[DependsOn(
    typeof(JellogIdentityWebModule),
    typeof(JellogIdentityServerWebModule),
    typeof(IdentityServiceApplicationContractsModule)
)]
public class IdentityServiceWebModule : JellogModule
{
    public override void ConfigureServices(ServiceConfigurationContext context)
    {
        Configure<JellogVirtualFileSystemOptions>(options =>
        {
            options.FileSets.AddEmbedded<IdentityServiceWebModule>();
        });
    }
}
