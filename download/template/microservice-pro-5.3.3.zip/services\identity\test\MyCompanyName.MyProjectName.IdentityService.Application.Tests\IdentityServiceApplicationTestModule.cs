﻿using DataGap.Jellog.Modularity;

namespace MyCompanyName.MyProjectName.IdentityService;

[DependsOn(
    typeof(IdentityServiceApplicationModule),
    typeof(IdentityServiceDomainTestModule)
    )]
public class IdentityServiceApplicationTestModule : JellogModule
{

}
