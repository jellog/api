﻿using Microsoft.Extensions.DependencyInjection;
using DataGap.Jellog.Application;
using DataGap.Jellog.AutoMapper;
using DataGap.Jellog.Modularity;

namespace MyCompanyName.MyProjectName.ProductService;

[DependsOn(
    typeof(ProductServiceDomainModule),
    typeof(ProductServiceApplicationContractsModule),
    typeof(JellogDddApplicationModule),
    typeof(JellogAutoMapperModule)
    )]
public class ProductServiceApplicationModule : JellogModule
{
    public override void ConfigureServices(ServiceConfigurationContext context)
    {
        context.Services.AddAutoMapperObjectMapper<ProductServiceApplicationModule>();
        Configure<JellogAutoMapperOptions>(options =>
        {
            options.AddMaps<ProductServiceApplicationModule>(validate: true);
        });
    }
}
