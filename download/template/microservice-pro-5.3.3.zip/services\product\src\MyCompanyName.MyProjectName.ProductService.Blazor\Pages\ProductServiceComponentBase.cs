﻿using MyCompanyName.MyProjectName.ProductService.Localization;
using DataGap.Jellog.AspNetCore.Components;

namespace MyCompanyName.MyProjectName.ProductService.Blazor.Pages;

public class ProductServiceComponentBase : JellogComponentBase
{
    public ProductServiceComponentBase()
    {
        LocalizationResource = typeof(ProductServiceResource);
        ObjectMapperContext = typeof(ProductServiceBlazorModule);
    }
}
