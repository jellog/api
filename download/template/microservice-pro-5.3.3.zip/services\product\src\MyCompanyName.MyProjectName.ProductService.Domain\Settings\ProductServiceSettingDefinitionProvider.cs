﻿using DataGap.Jellog.Settings;

namespace MyCompanyName.MyProjectName.ProductService.Settings;

public class ProductServiceSettingDefinitionProvider : SettingDefinitionProvider
{
    public override void Define(ISettingDefinitionContext context)
    {
        /* Define module settings here.
         * Use names from ProductServiceSettings class.
         */
    }
}
