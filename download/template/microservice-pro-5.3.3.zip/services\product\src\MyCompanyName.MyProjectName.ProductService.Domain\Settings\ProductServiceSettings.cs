﻿namespace MyCompanyName.MyProjectName.ProductService.Settings;

public static class ProductServiceSettings
{
    public const string GroupName = "ProductService";

    /* Add constants for setting names. Example:
     * public const string MySettingName = GroupName + ".MySettingName";
     */
}
