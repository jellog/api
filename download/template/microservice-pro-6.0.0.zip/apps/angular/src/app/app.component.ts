import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template: `
    <jellog-loader-bar></jellog-loader-bar>
    <jellog-dynamic-layout></jellog-dynamic-layout>
  `,
})
export class AppComponent {}
