﻿using DataGap.Jellog.AspNetCore.Mvc.Authentication;

namespace MyCompanyName.MyProjectName.Blazor.Server.Controllers;

public class AccountController : ChallengeAccountController
{

}
