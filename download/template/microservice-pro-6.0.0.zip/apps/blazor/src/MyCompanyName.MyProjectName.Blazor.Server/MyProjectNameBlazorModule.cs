using System;
using System.IO;
using Blazorise.Bootstrap5;
using Blazorise.Icons.FontAwesome;
using Microsoft.AspNetCore.Authentication.OpenIdConnect;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.DataProtection;
using Microsoft.AspNetCore.HttpOverrides;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.IdentityModel.Protocols.OpenIdConnect;
using MyCompanyName.MyProjectName.AdministrationService;
using MyCompanyName.MyProjectName.Blazor.Server.Components.Layout;
using MyCompanyName.MyProjectName.Blazor.Server.Navigation;
using MyCompanyName.MyProjectName.IdentityService;
using MyCompanyName.MyProjectName.Localization;
using MyCompanyName.MyProjectName.ProductService;
using MyCompanyName.MyProjectName.ProductService.Blazor;
using MyCompanyName.MyProjectName.SaasService;
using MyCompanyName.MyProjectName.Shared.Hosting.AspNetCore;
using Polly;
using Prometheus;
using StackExchange.Redis;
using DataGap.Jellog;
using DataGap.Jellog.Account;
using DataGap.Jellog.Account.Pro.Admin.Blazor.Server;
using DataGap.Jellog.AspNetCore.Authentication.OpenIdConnect;
using DataGap.Jellog.AspNetCore.Components.Server.LeptonXTheme;
using DataGap.Jellog.AspNetCore.Components.Server.LeptonXTheme.Bundling;
using DataGap.Jellog.AspNetCore.Components.Web.Theming.Routing;
using DataGap.Jellog.AspNetCore.Mvc.Client;
using DataGap.Jellog.AspNetCore.Mvc.Localization;
using DataGap.Jellog.AspNetCore.Mvc.UI.Bundling;
using DataGap.Jellog.AspNetCore.Mvc.UI.Theme.LeptonX;
using DataGap.Jellog.AspNetCore.Mvc.UI.Theme.LeptonX.Bundling;
using DataGap.Jellog.AspNetCore.Mvc.UI.Theme.Shared;
using DataGap.Jellog.AspNetCore.Mvc.UI.Theme.Shared.Toolbars;
using DataGap.Jellog.AuditLogging.Blazor.Server;
using DataGap.Jellog.Caching;
using DataGap.Jellog.Caching.StackExchangeRedis;
using DataGap.Jellog.EventBus.RabbitMq;
using DataGap.Jellog.Http.Client;
using DataGap.Jellog.Http.Client.Web;
using DataGap.Jellog.Http.Client.IdentityModel.Web;
using DataGap.Jellog.Identity.Pro.Blazor.Server;
using DataGap.Jellog.LanguageManagement.Blazor.Server;
//<TEMPLATE-REMOVE IF-NOT='LEPTONX'>
using DataGap.Jellog.LeptonX.Shared;
//</TEMPLATE-REMOVE>
using DataGap.Jellog.Modularity;
using DataGap.Jellog.MultiTenancy;
using DataGap.Jellog.OpenIddict.Pro.Blazor.Server;
using DataGap.Jellog.TextTemplateManagement.Blazor.Server;
using DataGap.Jellog.UI.Navigation;
using DataGap.Jellog.UI.Navigation.Urls;
using DataGap.Jellog.VirtualFileSystem;
using DataGap.Saas.Host.Blazor.Server;
using DataGap.Saas.Tenant.Blazor.Server;

namespace MyCompanyName.MyProjectName.Blazor.Server;

[DependsOn(
    typeof(JellogCachingStackExchangeRedisModule),
    typeof(JellogEventBusRabbitMqModule),
    typeof(JellogAspNetCoreMvcClientModule),
    typeof(JellogAspNetCoreAuthenticationOpenIdConnectModule),
    typeof(JellogHttpClientWebModule),
    typeof(JellogHttpClientIdentityModelWebModule),
    typeof(JellogIdentityProBlazorServerModule),
    typeof(JellogOpenIddictProBlazorServerModule),
    typeof(JellogAspNetCoreComponentsServerLeptonXThemeModule),
    typeof(JellogAspNetCoreMvcUiLeptonXThemeModule),
    typeof(JellogAuditLoggingBlazorServerModule),
    typeof(LanguageManagementBlazorServerModule),
    typeof(JellogAccountAdminBlazorServerModule),
    typeof(JellogAccountPublicHttpApiClientModule),
    typeof(TextTemplateManagementBlazorServerModule),
    typeof(SaasHostBlazorServerModule),
    typeof(SaasTenantBlazorServerModule),
    typeof(ProductServiceBlazorModule),
    typeof(ProductServiceHttpApiClientModule),
    typeof(IdentityServiceHttpApiClientModule),
    typeof(AdministrationServiceHttpApiClientModule),
    typeof(SaasServiceHttpApiClientModule),
    typeof(MyProjectNameSharedHostingAspNetCoreModule),
    typeof(MyProjectNameSharedLocalizationModule)
    )]
public class MyProjectNameBlazorModule : JellogModule
{
    public override void PreConfigureServices(ServiceConfigurationContext context)
    {
        context.Services.PreConfigure<JellogMvcDataAnnotationsLocalizationOptions>(options =>
        {
            options.AddAssemblyResource(
                typeof(MyProjectNameResource),
                typeof(MyProjectNameBlazorModule).Assembly
            );
        });
        
        PreConfigure<JellogHttpClientBuilderOptions>(options =>
        {
            options.ProxyClientBuildActions.Add((remoteServiceName, clientBuilder) =>
            {
                clientBuilder.AddTransientHttpErrorPolicy(policyBuilder =>
                    policyBuilder.WaitAndRetryAsync(
                        4,
                        i => TimeSpan.FromSeconds(Math.Pow(2, i))
                    )
                );
            });
        });
    }

    public override void ConfigureServices(ServiceConfigurationContext context)
    {
        //You can disable this setting in production to avoid any potential security risks.
        Microsoft.IdentityModel.Logging.IdentityModelEventSource.ShowPII = true;
        
        var hostingEnvironment = context.Services.GetHostingEnvironment();
        var configuration = context.Services.GetConfiguration();

        Configure<JellogMultiTenancyOptions>(options =>
        {
            options.IsEnabled = true;
        });

        Configure<JellogDistributedCacheOptions>(options =>
        {
            options.KeyPrefix = "MyProjectName:";
        });

        Configure<AppUrlOptions>(options =>
        {
            options.Applications["MVC"].RootUrl = configuration["App:SelfUrl"];
        });

        context.Services.AddAuthentication(options =>
            {
                options.DefaultScheme = "Cookies";
                options.DefaultChallengeScheme = "oidc";
            })
            .AddCookie("Cookies", options =>
            {
                options.ExpireTimeSpan = TimeSpan.FromDays(365);
            })
            .AddJellogOpenIdConnect("oidc", options =>
            {
                options.Authority = configuration["AuthServer:Authority"];
                options.RequireHttpsMetadata = Convert.ToBoolean(configuration["AuthServer:RequireHttpsMetadata"]); ;
                options.ResponseType = OpenIdConnectResponseType.CodeIdToken;

                options.ClientId = configuration["AuthServer:ClientId"];
                options.ClientSecret = configuration["AuthServer:ClientSecret"];

                options.SaveTokens = true;
                options.GetClaimsFromUserInfoEndpoint = true;

                options.Scope.Add("roles");
                options.Scope.Add("email");
                options.Scope.Add("phone");
                options.Scope.Add("AccountService");
                options.Scope.Add("IdentityService");
                options.Scope.Add("AdministrationService");
                options.Scope.Add("SaasService");
                options.Scope.Add("ProductService");
            });
        
        if (Convert.ToBoolean(configuration["AuthServer:IsOnK8s"]))
        {
            context.Services.Configure<OpenIdConnectOptions>("oidc", options =>
            {
                options.MetadataAddress = configuration["AuthServer:MetaAddress"].EnsureEndsWith('/') +
                                          ".well-known/openid-configuration";

                var previousOnRedirectToIdentityProvider = options.Events.OnRedirectToIdentityProvider;
                options.Events.OnRedirectToIdentityProvider = async ctx =>
                {
                    // Intercept the redirection so the browser navigates to the right URL in your host
                    ctx.ProtocolMessage.IssuerAddress = configuration["AuthServer:Authority"].EnsureEndsWith('/') + "connect/authorize";

                    if (previousOnRedirectToIdentityProvider != null)
                    {
                        await previousOnRedirectToIdentityProvider(ctx);
                    }
                };
                var previousOnRedirectToIdentityProviderForSignOut = options.Events.OnRedirectToIdentityProviderForSignOut;
                options.Events.OnRedirectToIdentityProviderForSignOut = async ctx =>
                {
                    // Intercept the redirection for signout so the browser navigates to the right URL in your host
                    ctx.ProtocolMessage.IssuerAddress = configuration["AuthServer:Authority"].EnsureEndsWith('/') + "connect/endsession";

                    if (previousOnRedirectToIdentityProviderForSignOut != null)
                    {
                        await previousOnRedirectToIdentityProviderForSignOut(ctx);
                    }
                };
            });
        }

        context.Services
            .AddBootstrap5Providers()
            .AddFontAwesomeIcons();

        var dataProtectionBuilder = context.Services.AddDataProtection().SetApplicationName("MyProjectName");
        var redis = ConnectionMultiplexer.Connect(configuration["Redis:Configuration"]);
        dataProtectionBuilder.PersistKeysToStackExchangeRedis(redis, "MyProjectName-Protection-Keys");

        Configure<JellogNavigationOptions>(options =>
        {
            options.MenuContributors.Add(new MyProjectNameMenuContributor(configuration));
        });

        Configure<JellogRouterOptions>(options =>
        {
            options.AppAssembly = typeof(MyProjectNameBlazorModule).Assembly;
        });

        Configure<JellogToolbarOptions>(options =>
        {
            options.Contributors.Add(new MyProjectNameToolbarContributor());
        });

        //<TEMPLATE-REMOVE IF-NOT='LEPTONX'>
        Configure<LeptonXThemeOptions>(options =>
        {
            options.DefaultStyle = LeptonXStyleNames.System;
        });
        //</TEMPLATE-REMOVE>

        Configure<JellogBundlingOptions>(options =>
        {
            // MVC UI
            options.StyleBundles.Configure(
                LeptonXThemeBundles.Styles.Global,
            bundle =>
            {
                bundle.AddFiles("/global-styles.css");
            }
            );

            // Blazor UI
            options.StyleBundles.Configure(
                BlazorLeptonXThemeBundles.Styles.Global,
            bundle =>
            {
                bundle.AddFiles("/blazor-global-styles.css");
            }
            );
        });

        if (hostingEnvironment.IsDevelopment())
        {
            Configure<JellogVirtualFileSystemOptions>(options =>
            {
                options.FileSets.ReplaceEmbeddedByPhysical<MyProjectNameSharedLocalizationModule>(Path.Combine(hostingEnvironment.ContentRootPath,
                    $"..{Path.DirectorySeparatorChar}..{Path.DirectorySeparatorChar}..{Path.DirectorySeparatorChar}..{Path.DirectorySeparatorChar}shared{Path.DirectorySeparatorChar}MyCompanyName.MyProjectName.Shared.Localization"));
            });
        }
    }

    public override void OnApplicationInitialization(ApplicationInitializationContext context)
    {
        var app = context.GetApplicationBuilder();
        var env = context.GetEnvironment();
        
        app.Use((ctx, next) =>
        {
            ctx.Request.Scheme = "https";
            return next();
        });

        if (env.IsDevelopment())
        {
            app.UseDeveloperExceptionPage();
        }

        app.UseJellogRequestLocalization();

        if (!env.IsDevelopment())
        {
            app.UseErrorPage();
        }
        
        app.UseForwardedHeaders(new ForwardedHeadersOptions
        {
            ForwardedHeaders = ForwardedHeaders.XForwardedFor | ForwardedHeaders.XForwardedProto
        });

        app.UseCorrelationId();
        app.UseJellogSecurityHeaders();
        app.UseStaticFiles();
        app.UseRouting();
        app.UseHttpMetrics();
        app.UseAuthentication();
        app.UseMultiTenancy();
        app.UseAuthorization();
        app.UseJellogSerilogEnrichers();
        app.UseConfiguredEndpoints(endpoints =>
        {
            endpoints.MapMetrics();
        });
    }
}
