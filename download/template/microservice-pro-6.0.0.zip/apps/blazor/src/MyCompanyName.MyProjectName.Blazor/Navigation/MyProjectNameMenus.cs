﻿namespace MyCompanyName.MyProjectName.Blazor.Navigation;

public class MyProjectNameMenus
{
    private const string Prefix = "MyProjectName";

    public const string Home = Prefix + ".Home";
}
