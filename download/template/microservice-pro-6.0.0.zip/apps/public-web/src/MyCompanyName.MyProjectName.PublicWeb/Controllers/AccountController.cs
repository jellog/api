﻿using DataGap.Jellog.AspNetCore.Mvc.Authentication;

namespace MyCompanyName.MyProjectName.PublicWeb.Controllers;

public class AccountController : ChallengeAccountController
{

}
