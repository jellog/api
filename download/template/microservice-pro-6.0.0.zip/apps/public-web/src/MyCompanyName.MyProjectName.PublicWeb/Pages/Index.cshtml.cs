﻿using System.Threading.Tasks;
using Microsoft.AspNetCore.Authentication;
using DataGap.Jellog.AspNetCore.Mvc.UI.RazorPages;

namespace MyCompanyName.MyProjectName.PublicWeb.Pages;

public class IndexModel : JellogPageModel
{
    public void OnGet()
    {

    }

    public async Task OnPostLoginAsync()
    {
        await HttpContext.ChallengeAsync("oidc");
    }
}
