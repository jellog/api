mkcert `
#<TEMPLATE-REMOVE IF-NOT='ui:mvc'>
"myprojectname-st-web" `
#</TEMPLATE-REMOVE>
#<TEMPLATE-REMOVE IF-NOT='ui:angular'>
"myprojectname-st-angular" `
#</TEMPLATE-REMOVE>
#<TEMPLATE-REMOVE IF-NOT='ui:blazor'>
"myprojectname-st-blazor" `
#</TEMPLATE-REMOVE>
#<TEMPLATE-REMOVE IF-NOT='ui:blazor-server'>
"myprojectname-st-blazor-server" `
#</TEMPLATE-REMOVE>
"myprojectname-st-public-web" "myprojectname-st-authserver" `
"myprojectname-st-gateway-web" "myprojectname-st-gateway-web-public" `
"myprojectname-st-identity" "myprojectname-st-administration" "myprojectname-st-saas" "myprojectname-st-product" 
kubectl create namespace myprojectname
kubectl create secret tls -n myprojectname myprojectname-tls --cert=./myprojectname-st-web+10.pem  --key=./myprojectname-st-web+10-key.pem