﻿using DataGap.Jellog.AuditLogging;
using DataGap.Jellog.FeatureManagement;
using DataGap.Jellog.LanguageManagement;
using DataGap.Jellog.Modularity;
using DataGap.Jellog.PermissionManagement;
using DataGap.Jellog.SettingManagement;
using DataGap.Jellog.TextTemplateManagement;

namespace MyCompanyName.MyProjectName.AdministrationService;

[DependsOn(
    typeof(JellogPermissionManagementApplicationContractsModule),
    typeof(JellogFeatureManagementApplicationContractsModule),
    typeof(JellogSettingManagementApplicationContractsModule),
    typeof(JellogAuditLoggingApplicationContractsModule),
    typeof(LanguageManagementApplicationContractsModule),
    typeof(TextTemplateManagementApplicationContractsModule),
    typeof(AdministrationServiceDomainSharedModule)
)]
public class AdministrationServiceApplicationContractsModule : JellogModule
{
}
