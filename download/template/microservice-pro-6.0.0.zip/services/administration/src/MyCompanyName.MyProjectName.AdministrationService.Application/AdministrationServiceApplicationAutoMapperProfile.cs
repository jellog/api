﻿using AutoMapper;

namespace MyCompanyName.MyProjectName.AdministrationService;

public class AdministrationServiceWebAutoMapperProfile : Profile
{
    public AdministrationServiceWebAutoMapperProfile()
    {

    }
}