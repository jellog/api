﻿using Microsoft.Extensions.DependencyInjection;
using DataGap.Jellog.AuditLogging;
using DataGap.Jellog.AutoMapper;
using DataGap.Jellog.FeatureManagement;
using DataGap.Jellog.LanguageManagement;
using DataGap.Jellog.Modularity;
using DataGap.Jellog.PermissionManagement;
using DataGap.Jellog.SettingManagement;
using DataGap.Jellog.TextTemplateManagement;

namespace MyCompanyName.MyProjectName.AdministrationService;

[DependsOn(
    typeof(JellogPermissionManagementApplicationModule),
    typeof(JellogFeatureManagementApplicationModule),
    typeof(JellogSettingManagementApplicationModule),
    typeof(JellogAuditLoggingApplicationModule),
    typeof(LanguageManagementApplicationModule),
    typeof(TextTemplateManagementApplicationModule),
    typeof(AdministrationServiceApplicationContractsModule),
    typeof(AdministrationServiceDomainModule)
)]
public class AdministrationServiceApplicationModule : JellogModule
{
    public override void ConfigureServices(ServiceConfigurationContext context)
    {
        context.Services.AddAutoMapperObjectMapper<AdministrationServiceApplicationModule>();
        Configure<JellogAutoMapperOptions>(options =>
        {
            options.AddMaps<AdministrationServiceApplicationModule>(validate: true);
        });
    }
}
