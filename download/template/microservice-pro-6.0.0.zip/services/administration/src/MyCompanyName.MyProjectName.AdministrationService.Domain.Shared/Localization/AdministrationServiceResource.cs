﻿using DataGap.Jellog.Localization;

namespace MyCompanyName.MyProjectName.AdministrationService.Localization;

[LocalizationResourceName("AdministrationService")]
public class AdministrationServiceResource
{

}
