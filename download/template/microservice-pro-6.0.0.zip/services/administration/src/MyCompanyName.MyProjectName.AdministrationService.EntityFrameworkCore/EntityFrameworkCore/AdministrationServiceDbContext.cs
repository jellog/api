﻿using Microsoft.EntityFrameworkCore;
using DataGap.Jellog.AuditLogging;
using DataGap.Jellog.AuditLogging.EntityFrameworkCore;
using DataGap.Jellog.BlobStoring.Database;
using DataGap.Jellog.BlobStoring.Database.EntityFrameworkCore;
using DataGap.Jellog.Data;
using DataGap.Jellog.EntityFrameworkCore;
using DataGap.Jellog.FeatureManagement;
using DataGap.Jellog.FeatureManagement.EntityFrameworkCore;
using DataGap.Jellog.LanguageManagement;
using DataGap.Jellog.LanguageManagement.EntityFrameworkCore;
using DataGap.Jellog.PermissionManagement;
using DataGap.Jellog.PermissionManagement.EntityFrameworkCore;
using DataGap.Jellog.SettingManagement;
using DataGap.Jellog.SettingManagement.EntityFrameworkCore;
using DataGap.Jellog.TextTemplateManagement.EntityFrameworkCore;
using DataGap.Jellog.TextTemplateManagement.TextTemplates;

namespace MyCompanyName.MyProjectName.AdministrationService.EntityFrameworkCore;

[ConnectionStringName(AdministrationServiceDbProperties.ConnectionStringName)]
public class AdministrationServiceDbContext : JellogDbContext<AdministrationServiceDbContext>,
    IPermissionManagementDbContext,
    ISettingManagementDbContext,
    IFeatureManagementDbContext,
    IAuditLoggingDbContext,
    ILanguageManagementDbContext,
    ITextTemplateManagementDbContext,
    IBlobStoringDbContext
{
    public DbSet<PermissionGrant> PermissionGrants { get; set; }
    public DbSet<Setting> Settings { get; set; }
    public DbSet<FeatureValue> FeatureValues { get; set; }
    public DbSet<AuditLog> AuditLogs { get; set; }
    public DbSet<Language> Languages { get; set; }
    public DbSet<LanguageText> LanguageTexts { get; set; }
    public DbSet<TextTemplateContent> TextTemplateContents { get; set; }
    public DbSet<DatabaseBlobContainer> BlobContainers { get; set; }
    public DbSet<DatabaseBlob> Blobs { get; set; }

    public AdministrationServiceDbContext(DbContextOptions<AdministrationServiceDbContext> options)
        : base(options)
    {
    }

    protected override void OnModelCreating(ModelBuilder builder)
    {
        base.OnModelCreating(builder);

        builder.ConfigurePermissionManagement();
        builder.ConfigureSettingManagement();
        builder.ConfigureFeatureManagement();
        builder.ConfigureAuditLogging();
        builder.ConfigureLanguageManagement();
        builder.ConfigureTextTemplateManagement();
        builder.ConfigureBlobStoring();
    }
}
