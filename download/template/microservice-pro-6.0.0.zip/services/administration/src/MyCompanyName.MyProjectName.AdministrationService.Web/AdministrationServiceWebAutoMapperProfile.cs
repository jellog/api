﻿using AutoMapper;

namespace MyCompanyName.MyProjectName.AdministrationService.Web;

public class AdministrationServiceWebAutoMapperProfile : Profile
{
    public AdministrationServiceWebAutoMapperProfile()
    {
        
    }
}