﻿using Microsoft.Extensions.DependencyInjection;
using DataGap.Jellog.Account.Admin.Web;
using DataGap.Jellog.AuditLogging.Web;
using DataGap.Jellog.AutoMapper;
using DataGap.Jellog.LanguageManagement;
using DataGap.Jellog.Modularity;
using DataGap.Jellog.TextTemplateManagement.Web;
using DataGap.Jellog.VirtualFileSystem;

namespace MyCompanyName.MyProjectName.AdministrationService.Web;

[DependsOn(
    typeof(JellogAuditLoggingWebModule),
    typeof(LanguageManagementWebModule),
    typeof(TextTemplateManagementWebModule),
    typeof(JellogAccountAdminWebModule),
    typeof(AdministrationServiceApplicationContractsModule)
    )]
public class AdministrationServiceWebModule : JellogModule
{
    public override void ConfigureServices(ServiceConfigurationContext context)
    {
        Configure<JellogVirtualFileSystemOptions>(options =>
        {
            options.FileSets.AddEmbedded<AdministrationServiceWebModule>();
        });
        
        context.Services.AddAutoMapperObjectMapper<AdministrationServiceWebModule>();
        Configure<JellogAutoMapperOptions>(options =>
        {
            options.AddMaps<AdministrationServiceWebModule>(validate: true);
        });
    }
}
