﻿namespace MyCompanyName.MyProjectName.AdministrationService.Web.Menus;

public class AdministrationServiceMenus
{
    public const string Prefix = "AdministrationService";
}