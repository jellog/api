﻿using DataGap.Jellog.Account;
using DataGap.Jellog.Identity;
using DataGap.Jellog.Modularity;
using DataGap.Jellog.OpenIddict;

namespace MyCompanyName.MyProjectName.IdentityService;

[DependsOn(
    typeof(JellogIdentityApplicationContractsModule),
    typeof(JellogOpenIddictProApplicationContractsModule),
    typeof(JellogAccountAdminApplicationContractsModule),
    typeof(IdentityServiceDomainSharedModule)
)]
public class IdentityServiceApplicationContractsModule : JellogModule
{
}
