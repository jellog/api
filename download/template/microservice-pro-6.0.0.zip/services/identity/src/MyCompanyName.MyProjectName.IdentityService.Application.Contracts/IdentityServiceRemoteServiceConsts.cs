﻿namespace MyCompanyName.MyProjectName.IdentityService;

public static class IdentityServiceRemoteServiceConsts
{
    public const string RemoteServiceName = "IdentityService";
}
