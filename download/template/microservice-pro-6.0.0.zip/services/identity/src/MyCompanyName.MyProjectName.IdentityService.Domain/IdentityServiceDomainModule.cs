﻿using DataGap.Jellog.Identity;
using DataGap.Jellog.Modularity;
using DataGap.Jellog.OpenIddict;

namespace MyCompanyName.MyProjectName.IdentityService;

[DependsOn(
    typeof(JellogIdentityProDomainModule),
    typeof(JellogOpenIddictDomainModule),
    typeof(IdentityServiceDomainSharedModule)
)]
public class IdentityServiceDomainModule : JellogModule
{
}
