﻿using Microsoft.Extensions.DependencyInjection;
using DataGap.Jellog.Account;
using DataGap.Jellog.Identity;
using DataGap.Jellog.OpenIddict;
using DataGap.Jellog.Modularity;

namespace MyCompanyName.MyProjectName.IdentityService;

[DependsOn(
    typeof(IdentityServiceApplicationContractsModule),
    typeof(JellogOpenIddictProHttpApiClientModule),
    typeof(JellogIdentityHttpApiClientModule),
    typeof(JellogAccountAdminHttpApiClientModule)
    )]
public class IdentityServiceHttpApiClientModule : JellogModule
{
    public override void ConfigureServices(ServiceConfigurationContext context)
    {
        context.Services.AddHttpClientProxies(
            typeof(IdentityServiceApplicationContractsModule).Assembly,
            IdentityServiceRemoteServiceConsts.RemoteServiceName
        );
    }
}
