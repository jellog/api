﻿using DataGap.Jellog.Account;
using DataGap.Jellog.Identity;
using DataGap.Jellog.Modularity;
using DataGap.Jellog.OpenIddict;

namespace MyCompanyName.MyProjectName.IdentityService;

[DependsOn(
    typeof(IdentityServiceApplicationContractsModule),
    typeof(JellogIdentityHttpApiModule),
    typeof(JellogOpenIddictProHttpApiModule),
    typeof(JellogAccountAdminHttpApiModule)
    )]
public class IdentityServiceHttpApiModule : JellogModule
{

}
