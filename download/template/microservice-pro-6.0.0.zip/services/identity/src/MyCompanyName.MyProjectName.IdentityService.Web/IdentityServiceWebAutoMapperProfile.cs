using AutoMapper;

namespace MyCompanyName.MyProjectName.IdentityService.Web;

public class IdentityServiceWebAutoMapperProfile : Profile
{
    public IdentityServiceWebAutoMapperProfile()
    {
        
    }
}
