﻿using Microsoft.Extensions.DependencyInjection;
using DataGap.Jellog.AutoMapper;
using DataGap.Jellog.Identity.Web;
using DataGap.Jellog.Modularity;
using DataGap.Jellog.OpenIddict.Pro.Web;
using DataGap.Jellog.VirtualFileSystem;

namespace MyCompanyName.MyProjectName.IdentityService.Web;

[DependsOn(
    typeof(JellogIdentityWebModule),
    typeof(JellogOpenIddictProWebModule),
    typeof(IdentityServiceApplicationContractsModule)
)]
public class IdentityServiceWebModule : JellogModule
{
    public override void ConfigureServices(ServiceConfigurationContext context)
    {
        Configure<JellogVirtualFileSystemOptions>(options =>
        {
            options.FileSets.AddEmbedded<IdentityServiceWebModule>();
        });

        context.Services.AddAutoMapperObjectMapper<IdentityServiceWebModule>();
        Configure<JellogAutoMapperOptions>(options =>
        {
            options.AddMaps<IdentityServiceWebModule>(validate: true);
        });
    }
}
