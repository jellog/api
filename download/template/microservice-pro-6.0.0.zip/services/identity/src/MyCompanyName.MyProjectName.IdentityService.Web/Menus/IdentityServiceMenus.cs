namespace MyCompanyName.MyProjectName.IdentityService.Web.Menus;

public class IdentityServiceMenus
{
    public const string Prefix = "IdentityService";
}
