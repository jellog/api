﻿using DataGap.Jellog.Application;
using DataGap.Jellog.Authorization;
using DataGap.Jellog.Modularity;

namespace MyCompanyName.MyProjectName.ProductService;

[DependsOn(
    typeof(ProductServiceDomainSharedModule),
    typeof(JellogDddApplicationContractsModule),
    typeof(JellogAuthorizationModule)
    )]
public class ProductServiceApplicationContractsModule : JellogModule
{

}
