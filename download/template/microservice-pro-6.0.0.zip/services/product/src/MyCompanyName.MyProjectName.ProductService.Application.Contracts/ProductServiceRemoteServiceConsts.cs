﻿namespace MyCompanyName.MyProjectName.ProductService;

public static class ProductServiceRemoteServiceConsts
{
    public const string RemoteServiceName = "ProductService";
}
