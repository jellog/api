using System;
using System.Threading.Tasks;
using DataGap.Jellog.Application.Dtos;
using DataGap.Jellog.Application.Services;

namespace MyCompanyName.MyProjectName.ProductService.Products;

public interface IProductAppService : ICrudAppService<ProductDto, Guid, GetProductsInput, ProductCreateDto, ProductUpdateDto>
{

}
