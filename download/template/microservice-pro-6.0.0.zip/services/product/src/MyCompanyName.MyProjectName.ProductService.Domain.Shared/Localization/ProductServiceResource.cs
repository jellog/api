﻿using DataGap.Jellog.Localization;

namespace MyCompanyName.MyProjectName.ProductService.Localization;

[LocalizationResourceName("ProductService")]
public class ProductServiceResource
{

}
