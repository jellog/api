﻿using DataGap.Jellog.Domain;
using DataGap.Jellog.Modularity;

namespace MyCompanyName.MyProjectName.ProductService;

[DependsOn(
    typeof(JellogDddDomainModule),
    typeof(ProductServiceDomainSharedModule)
)]
public class ProductServiceDomainModule : JellogModule
{

}
