using Microsoft.EntityFrameworkCore;
using MyCompanyName.MyProjectName.ProductService.Products;
using DataGap.Jellog.Data;
using DataGap.Jellog.EntityFrameworkCore;

namespace MyCompanyName.MyProjectName.ProductService.EntityFrameworkCore;

[ConnectionStringName(ProductServiceDbProperties.ConnectionStringName)]
public class ProductServiceDbContext : JellogDbContext<ProductServiceDbContext>
{
    public DbSet<Product> Products { get; set; }

    public ProductServiceDbContext(DbContextOptions<ProductServiceDbContext> options)
        : base(options)
    {

    }

    protected override void OnModelCreating(ModelBuilder builder)
    {
        base.OnModelCreating(builder);

        builder.ConfigureProductService();
    }
}
