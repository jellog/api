// This file is part of ProductPublicClientProxy, you can customize it here
// ReSharper disable once CheckNamespace
namespace MyCompanyName.MyProjectName.ProductService.Products.ClientProxies;

public partial class ProductPublicClientProxy
{
}
