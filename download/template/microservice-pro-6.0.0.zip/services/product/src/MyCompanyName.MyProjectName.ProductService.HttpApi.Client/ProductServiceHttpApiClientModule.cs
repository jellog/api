﻿using Microsoft.Extensions.DependencyInjection;
using DataGap.Jellog.Http.Client;
using DataGap.Jellog.Modularity;
using DataGap.Jellog.VirtualFileSystem;

namespace MyCompanyName.MyProjectName.ProductService;

[DependsOn(
    typeof(ProductServiceApplicationContractsModule),
    typeof(JellogHttpClientModule))]
public class ProductServiceHttpApiClientModule : JellogModule
{
    public override void ConfigureServices(ServiceConfigurationContext context)
    {
        context.Services.AddStaticHttpClientProxies(typeof(ProductServiceApplicationContractsModule).Assembly,
            ProductServiceRemoteServiceConsts.RemoteServiceName);

        Configure<JellogVirtualFileSystemOptions>(options =>
        {
            options.FileSets.AddEmbedded<ProductServiceHttpApiClientModule>();
        });
    }
}
