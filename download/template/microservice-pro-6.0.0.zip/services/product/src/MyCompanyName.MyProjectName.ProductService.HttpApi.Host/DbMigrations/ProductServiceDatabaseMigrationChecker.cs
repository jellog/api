﻿using System;
using Microsoft.Extensions.Logging;
using MyCompanyName.MyProjectName.ProductService.EntityFrameworkCore;
using MyCompanyName.MyProjectName.Shared.Hosting.Microservices.DbMigrations.EfCore;
using DataGap.Jellog.DistributedLocking;
using DataGap.Jellog.EventBus.Distributed;
using DataGap.Jellog.MultiTenancy;
using DataGap.Jellog.Uow;

namespace MyCompanyName.MyProjectName.ProductService.DbMigrations;

public class ProductServiceDatabaseMigrationChecker : PendingEfCoreMigrationsChecker<ProductServiceDbContext>
{
    public ProductServiceDatabaseMigrationChecker(
        ILoggerFactory loggerFactory,
        IUnitOfWorkManager unitOfWorkManager,
        IServiceProvider serviceProvider,
        ICurrentTenant currentTenant,
        IDistributedEventBus distributedEventBus,
        IJellogDistributedLock jellogDistributedLock) : base(
        loggerFactory,
        unitOfWorkManager,
        serviceProvider,
        currentTenant,
        distributedEventBus,
        jellogDistributedLock,
        ProductServiceDbProperties.ConnectionStringName)
    {
    }
}
