namespace MyCompanyName.MyProjectName.ProductService.Web.Menus;

public class ProductServiceMenus
{
    public const string Prefix = "ProductService";

    public const string ProductManagement = Prefix + ".ProductManagement";

    public const string Products = ProductManagement + ".Products";
}
