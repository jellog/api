using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Extensions.DependencyInjection;
using MyCompanyName.MyProjectName.ProductService.Localization;
using MyCompanyName.MyProjectName.ProductService.Permissions;
using MyCompanyName.MyProjectName.ProductService.Web.Menus;
using DataGap.Jellog.AspNetCore.Mvc.Localization;
using DataGap.Jellog.AspNetCore.Mvc.UI.Theme.Shared;
using DataGap.Jellog.AutoMapper;
using DataGap.Jellog.Modularity;
using DataGap.Jellog.UI.Navigation;
using DataGap.Jellog.VirtualFileSystem;

namespace MyCompanyName.MyProjectName.ProductService.Web;

[DependsOn(
    typeof(ProductServiceApplicationContractsModule),
    typeof(JellogAspNetCoreMvcUiThemeSharedModule),
    typeof(JellogAutoMapperModule)
    )]
public class ProductServiceWebModule : JellogModule
{
    public override void PreConfigureServices(ServiceConfigurationContext context)
    {
        context.Services.PreConfigure<JellogMvcDataAnnotationsLocalizationOptions>(options =>
        {
            options.AddAssemblyResource(typeof(ProductServiceResource), typeof(ProductServiceWebModule).Assembly);
        });

        PreConfigure<IMvcBuilder>(mvcBuilder =>
        {
            mvcBuilder.AddApplicationPartIfNotExists(typeof(ProductServiceWebModule).Assembly);
        });
    }

    public override void ConfigureServices(ServiceConfigurationContext context)
    {
        Configure<JellogNavigationOptions>(options =>
        {
            options.MenuContributors.Add(new ProductServiceMenuContributor());
        });

        Configure<JellogVirtualFileSystemOptions>(options =>
        {
            options.FileSets.AddEmbedded<ProductServiceWebModule>();
        });

        context.Services.AddAutoMapperObjectMapper<ProductServiceWebModule>();
        Configure<JellogAutoMapperOptions>(options =>
        {
            options.AddMaps<ProductServiceWebModule>(validate: true);
        });

        Configure<RazorPagesOptions>(options =>
        {
            options.Conventions.AuthorizePage("/Products/Index", ProductServicePermissions.Products.Default);
        });
    }
}
