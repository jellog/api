﻿using Microsoft.Data.Sqlite;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Infrastructure;
using Microsoft.EntityFrameworkCore.Storage;
using DataGap.Jellog.EntityFrameworkCore;
using DataGap.Jellog.EntityFrameworkCore.Sqlite;
using DataGap.Jellog.Modularity;

namespace MyCompanyName.MyProjectName.ProductService.EntityFrameworkCore;

[DependsOn(
    typeof(ProductServiceTestBaseModule),
    typeof(ProductServiceEntityFrameworkCoreModule),
    typeof(JellogEntityFrameworkCoreSqliteModule)
)]
public class ProductServiceEntityFrameworkCoreTestModule : JellogModule
{
    public override void ConfigureServices(ServiceConfigurationContext context)
    {
        var sqliteConnection = CreateDatabaseAndGetConnection();

        Configure<JellogDbContextOptions>(options =>
        {
            options.Configure<ProductServiceDbContext>(c =>
            {
                c.DbContextOptions.UseSqlite(sqliteConnection);
            });
        });
    }

    private static SqliteConnection CreateDatabaseAndGetConnection()
    {
        var connection = new SqliteConnection("Data Source=:memory:");
        connection.Open();

        new ProductServiceDbContext(
            new DbContextOptionsBuilder<ProductServiceDbContext>().UseSqlite(connection).Options
        ).GetService<IRelationalDatabaseCreator>().CreateTables();

        return connection;
    }
}
