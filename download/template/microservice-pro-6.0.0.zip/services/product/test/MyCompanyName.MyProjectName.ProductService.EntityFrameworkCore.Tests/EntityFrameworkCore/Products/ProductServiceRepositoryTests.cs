﻿using MyCompanyName.MyProjectName.ProductService.Products;

namespace MyCompanyName.MyProjectName.ProductService.EntityFrameworkCore.Products;

public class ProductServiceRepositoryTests : ProductServiceRepositoryTests<ProductServiceEntityFrameworkCoreTestModule>
{

}
