﻿using DataGap.Jellog.Modularity;
using DataGap.Saas.Host;
using DataGap.Saas.Tenant;
using DataGap.Payment.Admin;

namespace MyCompanyName.MyProjectName.SaasService;

[DependsOn(
    typeof(SaasTenantApplicationContractsModule),
    typeof(SaasHostApplicationContractsModule),
    typeof(SaasServiceDomainSharedModule),
    typeof(JellogPaymentAdminApplicationContractsModule)
)]
public class SaasServiceApplicationContractsModule : JellogModule
{
}
