﻿namespace MyCompanyName.MyProjectName.SaasService;

public static class SaasServiceRemoteServiceConsts
{
    public const string RemoteServiceName = "SaasService";
}
