using AutoMapper;

namespace MyCompanyName.MyProjectName.SaasService.Application;

public class SaasServiceApplicationAutoMapperProfile : Profile
{
    public SaasServiceApplicationAutoMapperProfile()
    {
        
    }
}
