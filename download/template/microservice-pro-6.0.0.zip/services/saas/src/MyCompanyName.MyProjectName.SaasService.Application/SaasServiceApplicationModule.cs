﻿using Microsoft.Extensions.DependencyInjection;
using DataGap.Jellog.AutoMapper;
using DataGap.Jellog.Modularity;
using DataGap.Saas.Host;
using DataGap.Saas.Tenant;
using DataGap.Payment.Admin;

namespace MyCompanyName.MyProjectName.SaasService.Application;

[DependsOn(
    typeof(SaasServiceApplicationContractsModule),
    typeof(SaasServiceDomainModule),
    typeof(SaasTenantApplicationModule),
    typeof(SaasHostApplicationModule),
    typeof(JellogPaymentAdminApplicationModule)
)]
public class SaasServiceApplicationModule : JellogModule
{
    public override void ConfigureServices(ServiceConfigurationContext context)
    {
        context.Services.AddAutoMapperObjectMapper<SaasServiceApplicationModule>();
        Configure<JellogAutoMapperOptions>(options =>
        {
            options.AddMaps<SaasServiceApplicationModule>(validate: true);
        });
    }
}
