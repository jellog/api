﻿using DataGap.Jellog.Application;
using DataGap.Jellog.Authorization;
using DataGap.Jellog.Modularity;

namespace MyCompanyName.MyProjectName.MicroserviceName;

[DependsOn(
    typeof(MicroserviceNameDomainSharedModule),
    typeof(JellogDddApplicationContractsModule),
    typeof(JellogAuthorizationModule)
    )]
public class MicroserviceNameApplicationContractsModule : JellogModule
{

}
