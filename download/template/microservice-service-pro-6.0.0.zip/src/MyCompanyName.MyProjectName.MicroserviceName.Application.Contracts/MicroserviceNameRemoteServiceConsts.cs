﻿namespace MyCompanyName.MyProjectName.MicroserviceName;

public static class MicroserviceNameRemoteServiceConsts
{
    public const string RemoteServiceName = "MicroserviceName";
}
