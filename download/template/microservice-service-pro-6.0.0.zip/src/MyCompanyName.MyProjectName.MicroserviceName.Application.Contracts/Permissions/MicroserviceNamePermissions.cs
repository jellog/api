using DataGap.Jellog.Reflection;

namespace MyCompanyName.MyProjectName.MicroserviceName.Permissions;

public class MicroserviceNamePermissions
{
    public const string GroupName = "MicroserviceName";

    public static string[] GetAll()
    {
        return ReflectionHelper.GetPublicConstantsRecursively(typeof(MicroserviceNamePermissions));
    }
}
