﻿namespace MyCompanyName.MyProjectName.MicroserviceName.Samples;

public class SampleDto
{
    public int Value { get; set; }
}
