﻿using MyCompanyName.MyProjectName.MicroserviceName.Localization;
using DataGap.Jellog.Application.Services;

namespace MyCompanyName.MyProjectName.MicroserviceName;

public abstract class MicroserviceNameAppService : ApplicationService
{
    protected MicroserviceNameAppService()
    {
        LocalizationResource = typeof(MicroserviceNameResource);
        ObjectMapperContext = typeof(MicroserviceNameApplicationModule);
    }
}
