﻿using Microsoft.Extensions.DependencyInjection;
using DataGap.Jellog.Application;
using DataGap.Jellog.AutoMapper;
using DataGap.Jellog.Modularity;

namespace MyCompanyName.MyProjectName.MicroserviceName;

[DependsOn(
    typeof(MicroserviceNameDomainModule),
    typeof(MicroserviceNameApplicationContractsModule),
    typeof(JellogDddApplicationModule),
    typeof(JellogAutoMapperModule)
    )]
public class MicroserviceNameApplicationModule : JellogModule
{
    public override void ConfigureServices(ServiceConfigurationContext context)
    {
        context.Services.AddAutoMapperObjectMapper<MicroserviceNameApplicationModule>();
        Configure<JellogAutoMapperOptions>(options =>
        {
            options.AddMaps<MicroserviceNameApplicationModule>(validate: true);
        });
    }
}
