namespace MyCompanyName.MyProjectName.MicroserviceName.Blazor.Menus;

public class MicroserviceNameMenus
{
    public const string Prefix = "MicroserviceName";
}
