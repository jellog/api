using AutoMapper;

namespace MyCompanyName.MyProjectName.MicroserviceName.Blazor;

public class MicroserviceNameBlazorAutoMapperProfile : Profile
{
    public MicroserviceNameBlazorAutoMapperProfile()
    {
    }
}
