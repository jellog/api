﻿using Microsoft.Extensions.DependencyInjection;
using MyCompanyName.MyProjectName.MicroserviceName.Blazor.Menus;
using DataGap.Jellog.AspNetCore.Components.Web.Theming;
using DataGap.Jellog.AspNetCore.Components.Web.Theming.Routing;
using DataGap.Jellog.AutoMapper;
using DataGap.Jellog.Modularity;
using DataGap.Jellog.UI.Navigation;

namespace MyCompanyName.MyProjectName.MicroserviceName.Blazor;

[DependsOn(
    typeof(MicroserviceNameApplicationContractsModule),
    typeof(JellogAspNetCoreComponentsWebThemingModule),
    typeof(JellogAutoMapperModule)
    )]
public class MicroserviceNameBlazorModule : JellogModule
{
    public override void ConfigureServices(ServiceConfigurationContext context)
    {
        context.Services.AddAutoMapperObjectMapper<MicroserviceNameBlazorModule>();

        Configure<JellogAutoMapperOptions>(options =>
        {
            options.AddProfile<MicroserviceNameBlazorAutoMapperProfile>(validate: true);
        });

        Configure<JellogNavigationOptions>(options =>
        {
            options.MenuContributors.Add(new MicroserviceNameMenuContributor());
        });

        Configure<JellogRouterOptions>(options =>
        {
            options.AdditionalAssemblies.Add(typeof(MicroserviceNameBlazorModule).Assembly);
        });
    }
}
