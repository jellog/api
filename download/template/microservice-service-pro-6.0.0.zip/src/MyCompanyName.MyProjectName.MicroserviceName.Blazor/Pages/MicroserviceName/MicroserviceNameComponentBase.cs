﻿using MyCompanyName.MyProjectName.MicroserviceName.Localization;
using DataGap.Jellog.AspNetCore.Components;

namespace MyCompanyName.MyProjectName.MicroserviceName.Blazor.Pages.MicroserviceName;

public class MicroserviceNameComponentBase : JellogComponentBase
{
    public MicroserviceNameComponentBase()
    {
        LocalizationResource = typeof(MicroserviceNameResource);
        ObjectMapperContext = typeof(MicroserviceNameBlazorModule);
    }
}
