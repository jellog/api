﻿using DataGap.Jellog.Localization;

namespace MyCompanyName.MyProjectName.MicroserviceName.Localization;

[LocalizationResourceName("MicroserviceName")]
public class MicroserviceNameResource
{

}
