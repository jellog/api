﻿using MyCompanyName.MyProjectName.MicroserviceName.Localization;
using DataGap.Jellog.Localization;
using DataGap.Jellog.Localization.ExceptionHandling;
using DataGap.Jellog.Modularity;
using DataGap.Jellog.Validation;
using DataGap.Jellog.Validation.Localization;
using DataGap.Jellog.VirtualFileSystem;

namespace MyCompanyName.MyProjectName.MicroserviceName;

[DependsOn(
    typeof(JellogValidationModule)
)]
public class MicroserviceNameDomainSharedModule : JellogModule
{
    public override void PreConfigureServices(ServiceConfigurationContext context)
    {
        MicroserviceNameModuleExtensionConfigurator.Configure();
    }

    public override void ConfigureServices(ServiceConfigurationContext context)
    {
        Configure<JellogVirtualFileSystemOptions>(options =>
        {
            options.FileSets.AddEmbedded<MicroserviceNameDomainSharedModule>();
        });

        Configure<JellogLocalizationOptions>(options =>
        {
            options.Resources
                .Add<MicroserviceNameResource>("en")
                .AddBaseTypes(typeof(JellogValidationResource))
                .AddVirtualJson("/Localization/MicroserviceName");
        });

        Configure<JellogExceptionLocalizationOptions>(options =>
        {
            options.MapCodeNamespace("MicroserviceName", typeof(MicroserviceNameResource));
        });
    }
}
