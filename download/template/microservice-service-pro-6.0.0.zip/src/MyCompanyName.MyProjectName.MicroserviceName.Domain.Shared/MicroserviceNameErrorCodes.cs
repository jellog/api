﻿namespace MyCompanyName.MyProjectName.MicroserviceName;

public static class MicroserviceNameErrorCodes
{
    //Add your business exception error codes here...
}
