﻿namespace MyCompanyName.MyProjectName.MicroserviceName;

public static class MicroserviceNameDbProperties
{
    public static string DbTablePrefix { get; set; } = "";

    public static string DbSchema { get; set; } = null;

    public const string ConnectionStringName = "MicroserviceName";
}
