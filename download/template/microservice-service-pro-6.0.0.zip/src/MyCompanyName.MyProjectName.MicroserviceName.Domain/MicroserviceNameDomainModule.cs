﻿using DataGap.Jellog.Domain;
using DataGap.Jellog.Modularity;

namespace MyCompanyName.MyProjectName.MicroserviceName;

[DependsOn(
    typeof(JellogDddDomainModule),
    typeof(MicroserviceNameDomainSharedModule)
)]
public class MicroserviceNameDomainModule : JellogModule
{
}
