using Microsoft.EntityFrameworkCore;
using DataGap.Jellog.Data;
using DataGap.Jellog.EntityFrameworkCore;

namespace MyCompanyName.MyProjectName.MicroserviceName.EntityFrameworkCore;

[ConnectionStringName(MicroserviceNameDbProperties.ConnectionStringName)]
public class MicroserviceNameDbContext : JellogDbContext<MicroserviceNameDbContext>
{

    public MicroserviceNameDbContext(DbContextOptions<MicroserviceNameDbContext> options)
        : base(options)
    {

    }

    protected override void OnModelCreating(ModelBuilder builder)
    {
        base.OnModelCreating(builder);

        builder.ConfigureMicroserviceName();
    }
}
