using Microsoft.EntityFrameworkCore;
using DataGap.Jellog;

namespace MyCompanyName.MyProjectName.MicroserviceName.EntityFrameworkCore;

public static class MicroserviceNameDbContextModelCreatingExtensions
{
    public static void ConfigureMicroserviceName(this ModelBuilder builder)
    {
        Check.NotNull(builder, nameof(builder));

        /* Configure your own tables/entities inside here */

        //builder.Entity<YourEntity>(b =>
        //{
        //    b.ToTable(MicroserviceNameConsts.DbTablePrefix + "YourEntities", MicroserviceNameConsts.DbSchema);
        //    b.ConfigureByConvention(); //auto configure for the base class props
        //    //...
        //});
    }
}
