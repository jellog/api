using Microsoft.Extensions.DependencyInjection;
using DataGap.Jellog.EntityFrameworkCore;
using DataGap.Jellog.EntityFrameworkCore.SqlServer;
using DataGap.Jellog.Modularity;

namespace MyCompanyName.MyProjectName.MicroserviceName.EntityFrameworkCore;

[DependsOn(
    typeof(JellogEntityFrameworkCoreSqlServerModule),
    typeof(JellogEntityFrameworkCoreModule),
    typeof(MicroserviceNameDomainModule)
)]
public class MicroserviceNameEntityFrameworkCoreModule : JellogModule
{
    public override void PreConfigureServices(ServiceConfigurationContext context)
    {
        MicroserviceNameEfCoreEntityExtensionMappings.Configure();
    }

    public override void ConfigureServices(ServiceConfigurationContext context)
    {
        context.Services.AddJellogDbContext<MicroserviceNameDbContext>(options =>
        {
                /* Remove "includeAllEntities: true" to create
                 * default repositories only for aggregate roots */
            options.AddDefaultRepositories(includeAllEntities: true);
        });

        Configure<JellogDbContextOptions>(options =>
        {
            options.Configure<MicroserviceNameDbContext>(c =>
            {
                c.UseSqlServer(b =>
                {
                    b.MigrationsHistoryTable("__MicroserviceName_Migrations");
                });
            });
        });
    }
}
