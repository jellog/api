﻿using Microsoft.Extensions.DependencyInjection;
using DataGap.Jellog.Http.Client;
using DataGap.Jellog.Modularity;
using DataGap.Jellog.VirtualFileSystem;

namespace MyCompanyName.MyProjectName.MicroserviceName;

[DependsOn(
    typeof(MicroserviceNameApplicationContractsModule),
    typeof(JellogHttpClientModule))]
public class MicroserviceNameHttpApiClientModule : JellogModule
{
    public override void ConfigureServices(ServiceConfigurationContext context)
    {
        context.Services.AddHttpClientProxies(typeof(MicroserviceNameApplicationContractsModule).Assembly,
            MicroserviceNameRemoteServiceConsts.RemoteServiceName);

        Configure<JellogVirtualFileSystemOptions>(options =>
        {
            options.FileSets.AddEmbedded<MicroserviceNameHttpApiClientModule>();
        });
    }
}
