﻿using System;
using Microsoft.Extensions.Logging;
using MyCompanyName.MyProjectName.MicroserviceName.EntityFrameworkCore;
using MyCompanyName.MyProjectName.Shared.Hosting.Microservices.DbMigrations.EfCore;
using DataGap.Jellog.DistributedLocking;
using DataGap.Jellog.EventBus.Distributed;
using DataGap.Jellog.MultiTenancy;
using DataGap.Jellog.Uow;

namespace MyCompanyName.MyProjectName.MicroserviceName.DbMigrations;

public class MicroserviceNameDatabaseMigrationChecker : PendingEfCoreMigrationsChecker<MicroserviceNameDbContext>
{
    public MicroserviceNameDatabaseMigrationChecker(
        ILoggerFactory loggerFactory,
        IUnitOfWorkManager unitOfWorkManager,
        IServiceProvider serviceProvider,
        ICurrentTenant currentTenant,
        IDistributedEventBus distributedEventBus,
        IJellogDistributedLock jellogDistributedLock)
        : base(
            loggerFactory,
            unitOfWorkManager,
            serviceProvider,
            currentTenant,
            distributedEventBus,
            jellogDistributedLock,
            MicroserviceNameDbProperties.ConnectionStringName)
    {

    }
}
