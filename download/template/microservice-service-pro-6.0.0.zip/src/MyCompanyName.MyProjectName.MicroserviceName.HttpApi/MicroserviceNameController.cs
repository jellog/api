﻿using MyCompanyName.MyProjectName.MicroserviceName.Localization;
using DataGap.Jellog.AspNetCore.Mvc;

namespace MyCompanyName.MyProjectName.MicroserviceName;

public abstract class MicroserviceNameController : JellogControllerBase
{
    protected MicroserviceNameController()
    {
        LocalizationResource = typeof(MicroserviceNameResource);
    }
}
