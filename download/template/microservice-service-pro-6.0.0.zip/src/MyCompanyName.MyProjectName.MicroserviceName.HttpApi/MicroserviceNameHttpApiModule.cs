﻿using Localization.Resources.JellogUi;
using Microsoft.Extensions.DependencyInjection;
using MyCompanyName.MyProjectName.MicroserviceName.Localization;
using DataGap.Jellog.AspNetCore.Mvc;
using DataGap.Jellog.Localization;
using DataGap.Jellog.Modularity;

namespace MyCompanyName.MyProjectName.MicroserviceName;

[DependsOn(
    typeof(MicroserviceNameApplicationContractsModule),
    typeof(JellogAspNetCoreMvcModule))]
public class MicroserviceNameHttpApiModule : JellogModule
{
    public override void PreConfigureServices(ServiceConfigurationContext context)
    {
        PreConfigure<IMvcBuilder>(mvcBuilder =>
        {
            mvcBuilder.AddApplicationPartIfNotExists(typeof(MicroserviceNameHttpApiModule).Assembly);
        });
    }

    public override void ConfigureServices(ServiceConfigurationContext context)
    {
        Configure<JellogLocalizationOptions>(options =>
        {
            options.Resources
                .Get<MicroserviceNameResource>()
                .AddBaseTypes(typeof(JellogUiResource));
        });
    }
}
