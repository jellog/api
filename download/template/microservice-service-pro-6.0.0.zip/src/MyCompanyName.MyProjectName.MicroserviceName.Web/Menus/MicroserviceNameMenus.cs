namespace MyCompanyName.MyProjectName.MicroserviceName.Web.Menus;

public class MicroserviceNameMenus
{
    public const string Prefix = "MicroserviceName";
}
