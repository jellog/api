using AutoMapper;

namespace MyCompanyName.MyProjectName.MicroserviceName.Web;

public class MicroserviceNameWebAutoMapperProfile : Profile
{
    public MicroserviceNameWebAutoMapperProfile()
    {
    }
}
