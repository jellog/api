using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Extensions.DependencyInjection;
using MyCompanyName.MyProjectName.MicroserviceName.Localization;
using MyCompanyName.MyProjectName.MicroserviceName.Permissions;
using MyCompanyName.MyProjectName.MicroserviceName.Web.Menus;
using DataGap.Jellog.AspNetCore.Mvc.Localization;
using DataGap.Jellog.AspNetCore.Mvc.UI.Theme.Shared;
using DataGap.Jellog.AutoMapper;
using DataGap.Jellog.Modularity;
using DataGap.Jellog.UI.Navigation;
using DataGap.Jellog.VirtualFileSystem;

namespace MyCompanyName.MyProjectName.MicroserviceName.Web;

[DependsOn(
    typeof(MicroserviceNameApplicationContractsModule),
    typeof(JellogAspNetCoreMvcUiThemeSharedModule),
    typeof(JellogAutoMapperModule)
    )]
public class MicroserviceNameWebModule : JellogModule
{
    public override void PreConfigureServices(ServiceConfigurationContext context)
    {
        context.Services.PreConfigure<JellogMvcDataAnnotationsLocalizationOptions>(options =>
        {
            options.AddAssemblyResource(typeof(MicroserviceNameResource), typeof(MicroserviceNameWebModule).Assembly);
        });

        PreConfigure<IMvcBuilder>(mvcBuilder =>
        {
            mvcBuilder.AddApplicationPartIfNotExists(typeof(MicroserviceNameWebModule).Assembly);
        });
    }

    public override void ConfigureServices(ServiceConfigurationContext context)
    {
        Configure<JellogNavigationOptions>(options =>
        {
            options.MenuContributors.Add(new MicroserviceNameMenuContributor());
        });

        Configure<JellogVirtualFileSystemOptions>(options =>
        {
            options.FileSets.AddEmbedded<MicroserviceNameWebModule>();
        });

        context.Services.AddAutoMapperObjectMapper<MicroserviceNameWebModule>();
        Configure<JellogAutoMapperOptions>(options =>
        {
            options.AddMaps<MicroserviceNameWebModule>(validate: true);
        });

        Configure<RazorPagesOptions>(options =>
        {
                // options.Conventions.AuthorizePage("/MicroserviceName/Index", MicroserviceNamePermissions.MicroserviceName.Default);
            });
    }
}
