﻿using MyCompanyName.MyProjectName.MicroserviceName.Localization;
using DataGap.Jellog.AspNetCore.Mvc.UI.RazorPages;

namespace MyCompanyName.MyProjectName.MicroserviceName.Web.Pages;

/* Inherit your PageModel classes from this class. */
public abstract class MicroserviceNamePageModel : JellogPageModel
{
    protected MicroserviceNamePageModel()
    {
        LocalizationResourceType = typeof(MicroserviceNameResource);
        ObjectMapperContext = typeof(MicroserviceNameWebModule);
    }
}
