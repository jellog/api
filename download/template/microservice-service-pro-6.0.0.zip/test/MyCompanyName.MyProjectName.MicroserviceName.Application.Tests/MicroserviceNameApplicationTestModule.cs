﻿using DataGap.Jellog.Modularity;

namespace MyCompanyName.MyProjectName.MicroserviceName;

[DependsOn(
    typeof(MicroserviceNameApplicationModule),
    typeof(MicroserviceNameDomainTestModule)
    )]
public class MicroserviceNameApplicationTestModule : JellogModule
{

}
