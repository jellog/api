﻿using Microsoft.EntityFrameworkCore;
using DataGap.Jellog.EntityFrameworkCore;

namespace MyCompanyName.MyProjectName.EntityFrameworkCore;

public class MyProjectNameHttpApiHostMigrationsDbContext : JellogDbContext<MyProjectNameHttpApiHostMigrationsDbContext>
{
    public MyProjectNameHttpApiHostMigrationsDbContext(DbContextOptions<MyProjectNameHttpApiHostMigrationsDbContext> options)
        : base(options)
    {

    }

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        base.OnModelCreating(modelBuilder);

        modelBuilder.ConfigureMyProjectName();
    }
}
