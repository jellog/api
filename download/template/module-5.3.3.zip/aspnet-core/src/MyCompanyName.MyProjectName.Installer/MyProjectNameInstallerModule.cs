﻿using DataGap.Jellog.Studio;
using DataGap.Jellog.Modularity;
using DataGap.Jellog.VirtualFileSystem;

namespace MyCompanyName.MyProjectName;

[DependsOn(
    typeof(JellogStudioModuleInstallerModule),
    typeof(JellogVirtualFileSystemModule)
    )]
public class MyProjectNameInstallerModule : JellogModule
{
    public override void ConfigureServices(ServiceConfigurationContext context)
    {
        Configure<JellogVirtualFileSystemOptions>(options =>
        {
            options.FileSets.AddEmbedded<MyProjectNameInstallerModule>();
        });
    }
}
