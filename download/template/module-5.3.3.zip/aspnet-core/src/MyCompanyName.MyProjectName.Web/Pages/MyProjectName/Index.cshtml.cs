namespace MyCompanyName.MyProjectName.Web.Pages.MyProjectName;

public class IndexModel : MyProjectNamePageModel
{
    public void OnGet()
    {
    }
}
