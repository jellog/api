﻿namespace MyCompanyName.MyProjectName.Blazor.Server.Host.Menus;

public class MyProjectNameMenus
{
    private const string Prefix = "MyProjectName";

    //Add your menu items here...

}
