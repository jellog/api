﻿using System.Threading.Tasks;
using Microsoft.Extensions.DependencyInjection;
using DataGap.Jellog.DependencyInjection;
using DataGap.Jellog.Studio.ModuleInstalling;

namespace MyCompanyName.MyProjectName;

[Dependency(ServiceLifetime.Transient, ReplaceServices = true)]
[ExposeServices(typeof(IModuleInstallingPipelineBuilder))]
public class MyProjectNameInstallerPipelineBuilder : ModuleInstallingPipelineBuilderBase, IModuleInstallingPipelineBuilder, ITransientDependency
{
    public async Task<ModuleInstallingPipeline> BuildAsync(ModuleInstallingContext context)
    {
        return GetBasePipeline(context);
    }
}
