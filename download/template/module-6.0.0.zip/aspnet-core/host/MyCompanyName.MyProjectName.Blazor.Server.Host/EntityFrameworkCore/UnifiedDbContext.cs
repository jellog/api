﻿using Microsoft.EntityFrameworkCore;
using MyCompanyName.MyProjectName.EntityFrameworkCore;
using DataGap.Jellog.AuditLogging.EntityFrameworkCore;
using DataGap.Jellog.EntityFrameworkCore;
using DataGap.Jellog.FeatureManagement.EntityFrameworkCore;
using DataGap.Jellog.Identity.EntityFrameworkCore;
using DataGap.Jellog.PermissionManagement.EntityFrameworkCore;
using DataGap.Jellog.SettingManagement.EntityFrameworkCore;
using DataGap.Jellog.TenantManagement.EntityFrameworkCore;

namespace MyCompanyName.MyProjectName.Blazor.Server.Host.EntityFrameworkCore;

public class UnifiedDbContext : JellogDbContext<UnifiedDbContext>
{
    public UnifiedDbContext(DbContextOptions<UnifiedDbContext> options)
        : base(options)
    {

    }

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        base.OnModelCreating(modelBuilder);

        modelBuilder.ConfigurePermissionManagement();
        modelBuilder.ConfigureSettingManagement();
        modelBuilder.ConfigureAuditLogging();
        modelBuilder.ConfigureIdentity();
        modelBuilder.ConfigureFeatureManagement();
        modelBuilder.ConfigureTenantManagement();
        modelBuilder.ConfigureMyProjectName();
    }
}
