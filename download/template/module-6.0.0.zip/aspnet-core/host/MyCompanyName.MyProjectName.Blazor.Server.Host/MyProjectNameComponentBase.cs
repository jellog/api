﻿using MyCompanyName.MyProjectName.Localization;
using DataGap.Jellog.AspNetCore.Components;

namespace MyCompanyName.MyProjectName.Blazor.Server.Host;

public abstract class MyProjectNameComponentBase : JellogComponentBase
{
    protected MyProjectNameComponentBase()
    {
        LocalizationResource = typeof(MyProjectNameResource);
    }
}
