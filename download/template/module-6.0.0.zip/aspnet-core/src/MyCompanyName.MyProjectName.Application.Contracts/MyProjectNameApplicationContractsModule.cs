﻿using DataGap.Jellog.Application;
using DataGap.Jellog.Modularity;
using DataGap.Jellog.Authorization;

namespace MyCompanyName.MyProjectName;

[DependsOn(
    typeof(MyProjectNameDomainSharedModule),
    typeof(JellogDddApplicationContractsModule),
    typeof(JellogAuthorizationModule)
    )]
public class MyProjectNameApplicationContractsModule : JellogModule
{

}
