﻿using DataGap.Jellog.AspNetCore.Components.Server.Theming;
using DataGap.Jellog.Modularity;

namespace MyCompanyName.MyProjectName.Blazor.Server;

[DependsOn(
    typeof(JellogAspNetCoreComponentsServerThemingModule),
    typeof(MyProjectNameBlazorModule)
    )]
public class MyProjectNameBlazorServerModule : JellogModule
{

}
