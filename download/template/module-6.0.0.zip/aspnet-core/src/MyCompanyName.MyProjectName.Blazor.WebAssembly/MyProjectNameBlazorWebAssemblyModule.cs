﻿using DataGap.Jellog.AspNetCore.Components.WebAssembly.Theming;
using DataGap.Jellog.Modularity;

namespace MyCompanyName.MyProjectName.Blazor.WebAssembly;

[DependsOn(
    typeof(MyProjectNameBlazorModule),
    typeof(MyProjectNameHttpApiClientModule),
    typeof(JellogAspNetCoreComponentsWebAssemblyThemingModule)
    )]
public class MyProjectNameBlazorWebAssemblyModule : JellogModule
{

}
