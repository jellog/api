﻿using Microsoft.Extensions.DependencyInjection;
using DataGap.Jellog.EntityFrameworkCore;
using DataGap.Jellog.Modularity;

namespace MyCompanyName.MyProjectName.EntityFrameworkCore;

[DependsOn(
    typeof(MyProjectNameDomainModule),
    typeof(JellogEntityFrameworkCoreModule)
)]
public class MyProjectNameEntityFrameworkCoreModule : JellogModule
{
    public override void ConfigureServices(ServiceConfigurationContext context)
    {
        context.Services.AddJellogDbContext<MyProjectNameDbContext>(options =>
        {
                /* Add custom repositories here. Example:
                 * options.AddRepository<Question, EfCoreQuestionRepository>();
                 */
        });
    }
}
