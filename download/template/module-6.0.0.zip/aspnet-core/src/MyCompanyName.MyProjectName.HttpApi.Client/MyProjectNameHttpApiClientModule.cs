﻿using Microsoft.Extensions.DependencyInjection;
using DataGap.Jellog.Http.Client;
using DataGap.Jellog.Modularity;
using DataGap.Jellog.VirtualFileSystem;

namespace MyCompanyName.MyProjectName;

[DependsOn(
    typeof(MyProjectNameApplicationContractsModule),
    typeof(JellogHttpClientModule))]
public class MyProjectNameHttpApiClientModule : JellogModule
{
    public override void ConfigureServices(ServiceConfigurationContext context)
    {
        context.Services.AddHttpClientProxies(
            typeof(MyProjectNameApplicationContractsModule).Assembly,
            MyProjectNameRemoteServiceConsts.RemoteServiceName
        );

        Configure<JellogVirtualFileSystemOptions>(options =>
        {
            options.FileSets.AddEmbedded<MyProjectNameHttpApiClientModule>();
        });

    }
}
