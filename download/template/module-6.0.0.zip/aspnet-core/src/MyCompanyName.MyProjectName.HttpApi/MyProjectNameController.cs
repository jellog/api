﻿using MyCompanyName.MyProjectName.Localization;
using DataGap.Jellog.AspNetCore.Mvc;

namespace MyCompanyName.MyProjectName;

public abstract class MyProjectNameController : JellogControllerBase
{
    protected MyProjectNameController()
    {
        LocalizationResource = typeof(MyProjectNameResource);
    }
}
