import { CoreModule } from '@jellog/ng.core';
import { ThemeSharedModule } from '@jellog/ng.theme.shared';
import { NgModule } from '@angular/core';
import { NgbDropdownModule } from '@ng-bootstrap/ng-bootstrap';
import { NgxValidateCoreModule } from '@ngx-validate/core';
import { CommercialUiModule } from '@dataGap/jellog.commercial.ng.ui';
import { ThemeLeptonModule } from '@dataGap/jellog.ng.theme.lepton';

@NgModule({
  declarations: [],
  imports: [
    CoreModule,
    CommercialUiModule,
    ThemeSharedModule,
    ThemeLeptonModule,
    NgbDropdownModule,
    NgxValidateCoreModule,
  ],
  exports: [
    CoreModule,
    CommercialUiModule,
    ThemeSharedModule,
    ThemeLeptonModule,
    NgbDropdownModule,
    NgxValidateCoreModule,
  ],
  providers: [],
})
export class SharedModule {}
