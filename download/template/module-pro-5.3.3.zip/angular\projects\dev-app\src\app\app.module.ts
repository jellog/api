import { CoreModule } from '@jellog/ng.core';
import { registerLocale } from '@jellog/ng.core/locale';
import { SettingManagementConfigModule } from '@jellog/ng.setting-management/config';
import { ThemeSharedModule } from '@jellog/ng.theme.shared';
import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { MyProjectNameConfigModule } from '@my-company-name/my-project-name/config';
import { CommercialUiConfigModule } from '@dataGap/jellog.commercial.ng.ui/config';
import { AccountAdminConfigModule } from '@dataGap/jellog.ng.account/admin/config';
import { AccountPublicConfigModule } from '@dataGap/jellog.ng.account/public/config';
import { IdentityConfigModule } from '@dataGap/jellog.ng.identity/config';
import { SaasConfigModule } from '@dataGap/jellog.ng.saas/config';
import { ThemeLeptonModule } from '@dataGap/jellog.ng.theme.lepton';
import { environment } from '../environments/environment';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { APP_ROUTE_PROVIDER } from './route.provider';

@NgModule({
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    AppRoutingModule,
    CoreModule.forRoot({
      environment,
      registerLocaleFn: registerLocale(),
      sendNullsAsQueryParam: false,
      skipGetAppConfiguration: false,
    }),
    ThemeSharedModule.forRoot(),
    AccountAdminConfigModule.forRoot(),
    AccountPublicConfigModule.forRoot(),
    IdentityConfigModule.forRoot(),
    MyProjectNameConfigModule.forRoot(),
    SaasConfigModule.forRoot(),
    SettingManagementConfigModule.forRoot(),
    ThemeLeptonModule.forRoot(),
    CommercialUiConfigModule.forRoot(),
  ],
  providers: [APP_ROUTE_PROVIDER],
  declarations: [AppComponent],
  bootstrap: [AppComponent],
})
export class AppModule {}
