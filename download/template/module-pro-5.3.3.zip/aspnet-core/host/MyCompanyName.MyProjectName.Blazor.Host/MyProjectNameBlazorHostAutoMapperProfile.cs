﻿using AutoMapper;

namespace MyCompanyName.MyProjectName.Blazor.Host;

public class MyProjectNameBlazorHostAutoMapperProfile : Profile
{
    public MyProjectNameBlazorHostAutoMapperProfile()
    {
        //Define your AutoMapper configuration here for the Blazor project.
    }
}
