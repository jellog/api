﻿using System.Threading.Tasks;
using MyCompanyName.MyProjectName.Localization;
using DataGap.Jellog.Identity.Pro.Blazor.Navigation;
using DataGap.Jellog.SettingManagement.Blazor.Menus;
using DataGap.Jellog.UI.Navigation;
using DataGap.Saas.Host.Blazor.Navigation;

namespace MyCompanyName.MyProjectName.Blazor.Server.Host.Menus;

public class MyProjectNameMenuContributor : IMenuContributor
{
    public async Task ConfigureMenuAsync(MenuConfigurationContext context)
    {
        if (context.Menu.Name == StandardMenus.Main)
        {
            await ConfigureMainMenuAsync(context);
        }
    }

    private Task ConfigureMainMenuAsync(MenuConfigurationContext context)
    {
        var l = context.GetLocalizer<MyProjectNameResource>();

        context.Menu.SetSubItemOrder(SaasHostMenus.GroupName, 2);


        //Administration
        var administration = context.Menu.GetAdministration();
        administration.Order = 4;

        //Administration->Identity
        administration.SetSubItemOrder(IdentityProMenus.GroupName, 1);

        //Administration->Settings
        administration.SetSubItemOrder(SettingManagementMenus.GroupName, 2);

        return Task.CompletedTask;
    }
}
