﻿using System;
using System.IO;
using Blazorise.Bootstrap5;
using Blazorise.Icons.FontAwesome;
using Microsoft.AspNetCore.Authentication.Google;
using Microsoft.AspNetCore.Authentication.MicrosoftAccount;
using Microsoft.AspNetCore.Authentication.Twitter;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Extensions.DependencyInjection;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.DependencyInjection.Extensions;
using Microsoft.Extensions.Hosting;
using Microsoft.OpenApi.Models;
using MyCompanyName.MyProjectName.Blazor.Server.Host.Menus;
using MyCompanyName.MyProjectName.EntityFrameworkCore;
using MyCompanyName.MyProjectName.Localization;
using MyCompanyName.MyProjectName.MultiTenancy;
using DataGap.Jellog;
using DataGap.Jellog.Account;
using DataGap.Jellog.Account.Pro.Admin.Blazor.Server;
using DataGap.Jellog.Account.Public.Web.ExternalProviders;
using DataGap.Jellog.Account.Web;
using DataGap.Jellog.AspNetCore.Authentication.JwtBearer;
using DataGap.Jellog.AspNetCore.Components.Server.LeptonTheme;
using DataGap.Jellog.AspNetCore.Components.Server.LeptonTheme.Bundling;
using DataGap.Jellog.AspNetCore.Components.Web.Theming.Routing;
using DataGap.Jellog.AspNetCore.Mvc.Localization;
using DataGap.Jellog.AspNetCore.Mvc.UI.Bundling;
using DataGap.Jellog.AspNetCore.Mvc.UI.Theme.Lepton;
using DataGap.Jellog.AspNetCore.Mvc.UI.Theme.Lepton.Bundling;
using DataGap.Jellog.AspNetCore.Mvc.UI.Theme.Shared;
using DataGap.Jellog.AspNetCore.Serilog;
using DataGap.Jellog.AuditLogging.EntityFrameworkCore;
using DataGap.Jellog.Autofac;
using DataGap.Jellog.BlobStoring.Database.EntityFrameworkCore;
using DataGap.Jellog.Data;
using DataGap.Jellog.Emailing;
using DataGap.Jellog.FeatureManagement;
using DataGap.Jellog.FeatureManagement.Blazor.Server;
using DataGap.Jellog.FeatureManagement.EntityFrameworkCore;
using DataGap.Jellog.Identity;
using DataGap.Jellog.Identity.EntityFrameworkCore;
using DataGap.Jellog.Identity.Pro.Blazor.Server;
using DataGap.Jellog.LeptonTheme.Management;
using DataGap.Jellog.LeptonTheme.Management.Blazor.Server;
using DataGap.Jellog.Localization;
using DataGap.Jellog.Modularity;
using DataGap.Jellog.PermissionManagement.Identity;
using DataGap.Jellog.SettingManagement;
using DataGap.Jellog.SettingManagement.Blazor.Server;
using DataGap.Jellog.SettingManagement.EntityFrameworkCore;
using DataGap.Jellog.Swashbuckle;
using DataGap.Jellog.Threading;
using DataGap.Jellog.UI.Navigation;
using DataGap.Jellog.VirtualFileSystem;
using DataGap.Saas.EntityFrameworkCore;
using DataGap.Saas.Host;
using DataGap.Saas.Host.Blazor.Server;
using DataGap.Jellog.EntityFrameworkCore;
using DataGap.Jellog.PermissionManagement;
using DataGap.Jellog.PermissionManagement.EntityFrameworkCore;
using DataGap.Jellog.UI.Navigation.Urls;

namespace MyCompanyName.MyProjectName.Blazor.Server.Host;

[DependsOn(
    typeof(MyProjectNameApplicationModule),
    typeof(MyProjectNameEntityFrameworkCoreModule),
    typeof(MyProjectNameHttpApiModule),
    typeof(JellogAspNetCoreMvcUiLeptonThemeModule),
    typeof(JellogAutofacModule),
    typeof(JellogSwashbuckleModule),
    typeof(JellogAspNetCoreAuthenticationJwtBearerModule),
    typeof(JellogAspNetCoreSerilogModule),
    typeof(JellogAspNetCoreComponentsServerLeptonThemeModule),
    typeof(JellogSettingManagementEntityFrameworkCoreModule),
    typeof(JellogSettingManagementApplicationModule),
    typeof(JellogSettingManagementBlazorServerModule),
    typeof(JellogIdentityApplicationModule),
    typeof(JellogIdentityProEntityFrameworkCoreModule),
    typeof(JellogPermissionManagementEntityFrameworkCoreModule),
    typeof(JellogPermissionManagementApplicationModule),
    typeof(JellogPermissionManagementDomainIdentityModule),
    typeof(JellogFeatureManagementBlazorServerModule),
    typeof(JellogFeatureManagementApplicationModule),
    typeof(JellogFeatureManagementEntityFrameworkCoreModule),
    typeof(JellogAccountPublicWebIdentityServerModule),
    typeof(JellogAccountAdminBlazorServerModule),
    typeof(JellogAccountPublicApplicationModule),
    typeof(JellogAccountAdminApplicationModule),
    typeof(JellogIdentityProBlazorServerModule),
    typeof(LeptonThemeManagementBlazorServerModule),
    typeof(LeptonThemeManagementApplicationModule),
    typeof(LeptonThemeManagementDomainModule),
    typeof(SaasHostBlazorServerModule),
    typeof(SaasHostApplicationModule),
    typeof(SaasEntityFrameworkCoreModule),
    typeof(BlobStoringDatabaseEntityFrameworkCoreModule),
    typeof(JellogAuditLoggingEntityFrameworkCoreModule),
    typeof(MyProjectNameBlazorServerModule)
)]
public class MyProjectNameBlazorHostModule : JellogModule
{
    public override void PreConfigureServices(ServiceConfigurationContext context)
    {
        context.Services.PreConfigure<JellogMvcDataAnnotationsLocalizationOptions>(options =>
        {
            options.AddAssemblyResource(
                typeof(MyProjectNameResource),
                typeof(MyProjectNameDomainModule).Assembly,
                typeof(MyProjectNameDomainSharedModule).Assembly,
                typeof(MyProjectNameApplicationModule).Assembly,
                typeof(MyProjectNameApplicationContractsModule).Assembly,
                typeof(MyProjectNameBlazorHostModule).Assembly
            );
        });
    }

    public override void ConfigureServices(ServiceConfigurationContext context)
    {
        var hostingEnvironment = context.Services.GetHostingEnvironment();
        var configuration = context.Services.GetConfiguration();

        Configure<JellogDbContextOptions>(options =>
        {
            options.UseSqlServer();
        });

        Configure<JellogBundlingOptions>(options =>
        {
                // MVC UI
                options.StyleBundles.Configure(
                LeptonThemeBundles.Styles.Global,
                bundle =>
                {
                    bundle.AddFiles("/global-styles.css");
                }
            );

                // Blazor UI
                options.StyleBundles.Configure(
                BlazorLeptonThemeBundles.Styles.Global,
                bundle =>
                {
                    bundle.AddFiles("/blazor-global-styles.css");
                        //You can remove the following line if you don't use Blazor CSS isolation for components
                        bundle.AddFiles("/MyCompanyName.MyProjectName.Blazor.Server.Host.styles.css");
                }
            );
        });

        context.Services.AddAuthentication()
            .AddJwtBearer(options =>
            {
                options.Authority = configuration["AuthServer:Authority"];
                options.RequireHttpsMetadata = Convert.ToBoolean(configuration["AuthServer:RequireHttpsMetadata"]);
                options.Audience = "MyProjectName";
            });

        context.Services.ForwardIdentityAuthenticationForBearer();

        if (hostingEnvironment.IsDevelopment())
        {
            Configure<JellogVirtualFileSystemOptions>(options =>
            {
                options.FileSets.ReplaceEmbeddedByPhysical<MyProjectNameDomainSharedModule>(Path.Combine(hostingEnvironment.ContentRootPath, string.Format("..{0}..{0}src{0}MyCompanyName.MyProjectName.Domain.Shared", Path.DirectorySeparatorChar)));
                options.FileSets.ReplaceEmbeddedByPhysical<MyProjectNameDomainModule>(Path.Combine(hostingEnvironment.ContentRootPath, string.Format("..{0}..{0}src{0}MyCompanyName.MyProjectName.Domain", Path.DirectorySeparatorChar)));
                options.FileSets.ReplaceEmbeddedByPhysical<MyProjectNameApplicationContractsModule>(Path.Combine(hostingEnvironment.ContentRootPath, string.Format("..{0}..{0}src{0}MyCompanyName.MyProjectName.Application.Contracts", Path.DirectorySeparatorChar)));
                options.FileSets.ReplaceEmbeddedByPhysical<MyProjectNameApplicationModule>(Path.Combine(hostingEnvironment.ContentRootPath, string.Format("..{0}..{0}src{0}MyCompanyName.MyProjectName.Application", Path.DirectorySeparatorChar)));
                options.FileSets.ReplaceEmbeddedByPhysical<MyProjectNameBlazorHostModule>(hostingEnvironment.ContentRootPath);
            });
        }

        context.Services.AddJellogSwaggerGen(
            options =>
            {
                options.SwaggerDoc("v1", new OpenApiInfo { Title = "MyProjectName API", Version = "v1" });
                options.DocInclusionPredicate((docName, description) => true);
                options.CustomSchemaIds(type => type.FullName);
            }
        );

        context.Services.AddAuthentication()
            .AddGoogle(GoogleDefaults.AuthenticationScheme, _ => { })
            .WithDynamicOptions<GoogleOptions, GoogleHandler>(
                GoogleDefaults.AuthenticationScheme,
                options =>
                {
                    options.WithProperty(x => x.ClientId);
                    options.WithProperty(x => x.ClientSecret, isSecret: true);
                }
            )
            .AddMicrosoftAccount(MicrosoftAccountDefaults.AuthenticationScheme, options =>
            {
                    //Personal Microsoft accounts as an example.
                    options.AuthorizationEndpoint = "https://login.microsoftonline.com/consumers/oauth2/v2.0/authorize";
                options.TokenEndpoint = "https://login.microsoftonline.com/consumers/oauth2/v2.0/token";
            })
            .WithDynamicOptions<MicrosoftAccountOptions, MicrosoftAccountHandler>(
                MicrosoftAccountDefaults.AuthenticationScheme,
                options =>
                {
                    options.WithProperty(x => x.ClientId);
                    options.WithProperty(x => x.ClientSecret, isSecret: true);
                }
            )
            .AddTwitter(TwitterDefaults.AuthenticationScheme, options => options.RetrieveUserDetails = true)
            .WithDynamicOptions<TwitterOptions, TwitterHandler>(
                TwitterDefaults.AuthenticationScheme,
                options =>
                {
                    options.WithProperty(x => x.ConsumerKey);
                    options.WithProperty(x => x.ConsumerSecret, isSecret: true);
                }
            );

        Configure<JellogLocalizationOptions>(options =>
        {
            options.Languages.Add(new LanguageInfo("ar", "ar", "العربية", "ae"));
            options.Languages.Add(new LanguageInfo("cs", "cs", "Čeština"));
            options.Languages.Add(new LanguageInfo("en", "en", "English"));
            options.Languages.Add(new LanguageInfo("en-GB", "en-GB", "English (UK)"));
            options.Languages.Add(new LanguageInfo("hu", "hu", "Magyar"));
            options.Languages.Add(new LanguageInfo("fi", "fi", "Finnish", "fi"));
            options.Languages.Add(new LanguageInfo("fr", "fr", "Français", "fr"));
            options.Languages.Add(new LanguageInfo("hi", "hi", "Hindi", "in"));
            options.Languages.Add(new LanguageInfo("it", "it", "Italiano", "it"));
            options.Languages.Add(new LanguageInfo("pt-BR", "pt-BR", "Português"));
            options.Languages.Add(new LanguageInfo("ru", "ru", "Русский", "ru"));
            options.Languages.Add(new LanguageInfo("sk", "sk", "Slovak", "sk"));
            options.Languages.Add(new LanguageInfo("tr", "tr", "Türkçe"));
            options.Languages.Add(new LanguageInfo("zh-Hans", "zh-Hans", "简体中文"));
            options.Languages.Add(new LanguageInfo("zh-Hant", "zh-Hant", "繁體中文"));
            options.Languages.Add(new LanguageInfo("de-DE", "de-DE", "Deutsch", "de"));
            options.Languages.Add(new LanguageInfo("es", "es", "Español"));
        });

        context.Services
            .AddBootstrap5Providers()
            .AddFontAwesomeIcons();

        Configure<JellogNavigationOptions>(options =>
        {
            options.MenuContributors.Add(new MyProjectNameMenuContributor());
        });

        Configure<JellogRouterOptions>(options =>
        {
            options.AppAssembly = typeof(MyProjectNameBlazorHostModule).Assembly;
        });

            Configure<AppUrlOptions>(options =>
            {
                options.Applications["MVC"].RootUrl = configuration["App:SelfUrl"];
                options.RedirectAllowedUrls.AddRange(configuration["App:RedirectAllowedUrls"].Split(','));
            });

#if DEBUG
        context.Services.Replace(ServiceDescriptor.Singleton<IEmailSender, NullEmailSender>());
#endif
    }

    public override void OnApplicationInitialization(ApplicationInitializationContext context)
    {
        var env = context.GetEnvironment();
        var app = context.GetApplicationBuilder();

        if (env.IsDevelopment())
        {
            app.UseDeveloperExceptionPage();
        }

        app.UseJellogRequestLocalization();

        if (!env.IsDevelopment())
        {
            app.UseErrorPage();
            app.UseHsts();
        }

        app.UseHttpsRedirection();
        app.UseCorrelationId();
        app.UseJellogSecurityHeaders();
        app.UseStaticFiles();
        app.UseRouting();
        app.UseAuthentication();
        app.UseJwtTokenMiddleware();

        if (MultiTenancyConsts.IsEnabled)
        {
            app.UseMultiTenancy();
        }

        app.UseUnitOfWork();
        app.UseIdentityServer();
        app.UseAuthorization();
        app.UseSwagger();
        app.UseJellogSwaggerUI(options =>
        {
            options.SwaggerEndpoint("/swagger/v1/swagger.json", "MyProjectName API");
        });
        app.UseAuditing();
        app.UseJellogSerilogEnrichers();
        app.UseConfiguredEndpoints();

        AsyncHelper.RunSync(async () =>
        {
            using (var scope = context.ServiceProvider.CreateScope())
            {
                await scope.ServiceProvider
                    .GetRequiredService<IDataSeeder>()
                    .SeedAsync();
            }
        });
    }
}
