﻿using System.Threading.Tasks;
using DataGap.Jellog.Data;
using DataGap.Jellog.DependencyInjection;
using DataGap.Jellog.MultiTenancy;
using DataGap.Jellog.Uow;

namespace MyCompanyName.MyProjectName.Seed;

public class MyProjectNameUnifiedDataSeedContributor : IDataSeedContributor, ITransientDependency
{
    private readonly MyProjectNameSampleIdentityDataSeeder _sampleIdentityDataSeeder;
    private readonly MyProjectNameSampleDataSeeder _myProjectNameSampleDataSeeder;
    private readonly IUnitOfWorkManager _unitOfWorkManager;
    private readonly ICurrentTenant _currentTenant;

    public MyProjectNameUnifiedDataSeedContributor(
        MyProjectNameSampleIdentityDataSeeder sampleIdentityDataSeeder,
        IUnitOfWorkManager unitOfWorkManager,
        MyProjectNameSampleDataSeeder myProjectNameSampleDataSeeder,
        ICurrentTenant currentTenant)
    {
        _sampleIdentityDataSeeder = sampleIdentityDataSeeder;
        _unitOfWorkManager = unitOfWorkManager;
        _myProjectNameSampleDataSeeder = myProjectNameSampleDataSeeder;
        _currentTenant = currentTenant;
    }

    public async Task SeedAsync(DataSeedContext context)
    {
        await _unitOfWorkManager.Current.SaveChangesAsync();

        using (_currentTenant.Change(context?.TenantId))
        {
            await _sampleIdentityDataSeeder.SeedAsync(context);
            await _unitOfWorkManager.Current.SaveChangesAsync();
            await _myProjectNameSampleDataSeeder.SeedAsync(context);
        }
    }
}
