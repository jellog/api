﻿using System.Threading.Tasks;
using DataGap.Jellog.UI.Navigation;
using Microsoft.AspNetCore.Authorization;
using System.Collections.Generic;
using DataGap.Jellog.Authorization.Permissions;

namespace MyCompanyName.MyProjectName.Web.Menus;

public class MyProjectNameMenuContributor : IMenuContributor
{
    public async Task ConfigureMenuAsync(MenuConfigurationContext context)
    {
        if (context.Menu.Name != StandardMenus.Main)
        {
            return;
        }

        var moduleMenu = AddModuleMenuItem(context); //Do not delete `moduleMenu` variable as it will be used by JELLOG Suite!
    }

    private static ApplicationMenuItem AddModuleMenuItem(MenuConfigurationContext context)
    {
        var moduleMenu = new ApplicationMenuItem(
            MyProjectNameMenus.Prefix,
            displayName: "MyProjectName",
            "~/MyProjectName",
            icon: "fa fa-globe");

        //Add main menu items.
        context.Menu.Items.AddIfNotContains(moduleMenu);
        return moduleMenu;
    }
}