﻿using System.Threading.Tasks;
using DataGap.Jellog.Data;
using DataGap.Jellog.DependencyInjection;
using DataGap.Jellog.MultiTenancy;

namespace MyCompanyName.MyProjectName.Seed;

public class MyProjectNameIdentityServerDataSeedContributor : IDataSeedContributor, ITransientDependency
{
    private readonly MyProjectNameSampleIdentityDataSeeder _myProjectNameSampleIdentityDataSeeder;
    private readonly MyProjectNameIdentityServerDataSeeder _myProjectNameIdentityServerDataSeeder;
    private readonly ICurrentTenant _currentTenant;

    public MyProjectNameIdentityServerDataSeedContributor(
        MyProjectNameIdentityServerDataSeeder myProjectNameIdentityServerDataSeeder,
        MyProjectNameSampleIdentityDataSeeder myProjectNameSampleIdentityDataSeeder,
        ICurrentTenant currentTenant)
    {
        _myProjectNameIdentityServerDataSeeder = myProjectNameIdentityServerDataSeeder;
        _myProjectNameSampleIdentityDataSeeder = myProjectNameSampleIdentityDataSeeder;
        _currentTenant = currentTenant;
    }

    public async Task SeedAsync(DataSeedContext context)
    {
        using (_currentTenant.Change(context?.TenantId))
        {
            await _myProjectNameSampleIdentityDataSeeder.SeedAsync(context);
            await _myProjectNameIdentityServerDataSeeder.SeedAsync(context);
        }
    }
}
