﻿using System.Threading.Tasks;
using Microsoft.AspNetCore.Identity;
using Microsoft.Extensions.Options;
using DataGap.Jellog.Data;
using DataGap.Jellog.DependencyInjection;
using DataGap.Jellog.Guids;
using DataGap.Jellog.Identity;
using IdentityUser = DataGap.Jellog.Identity.IdentityUser;

namespace MyCompanyName.MyProjectName.Seed;

/* Creates a few more sample users to test the application and the module.
 *
 * This class is shared among these projects:
 * - MyCompanyName.MyProjectName.IdentityServer
 * - MyCompanyName.MyProjectName.Web.Unified (used as linked file)
 */
public class MyProjectNameSampleIdentityDataSeeder : ITransientDependency
{
    private readonly IIdentityUserRepository _identityUserRepository;
    private readonly ILookupNormalizer _lookupNormalizer;
    private readonly IGuidGenerator _guidGenerator;
    private readonly IdentityUserManager _identityUserManager;
    private readonly IOptions<IdentityOptions> _identityOptions;

    public MyProjectNameSampleIdentityDataSeeder(
        IIdentityUserRepository identityUserRepository,
        ILookupNormalizer lookupNormalizer,
        IGuidGenerator guidGenerator,
        IdentityUserManager identityUserManager,
        IOptions<IdentityOptions> identityOptions)
    {
        _identityUserRepository = identityUserRepository;
        _lookupNormalizer = lookupNormalizer;
        _guidGenerator = guidGenerator;
        _identityUserManager = identityUserManager;
        _identityOptions = identityOptions;
    }

    public async Task SeedAsync(DataSeedContext context)
    {
        await CreateUserAsync("john", "John", "Nash", context);
        await CreateUserAsync("albert", "Albert", "Einstein", context);
    }

    private async Task CreateUserAsync(string userName, string name, string surname, DataSeedContext context)
    {
        await _identityOptions.SetAsync();

        if ((await _identityUserRepository.FindByNormalizedUserNameAsync(_lookupNormalizer.NormalizeName(userName))) != null)
        {
            return;
        }

        var user = new IdentityUser(
            _guidGenerator.Create(),
            userName,
            userName + "@jellog.io",
            context.TenantId
        );

        user.Name = name;
        user.Surname = surname;

        await _identityUserManager.CreateAsync(user,
            "1q2w3E*"
        );

        await _identityUserManager.AddToRoleAsync(user, "admin");
    }
}
