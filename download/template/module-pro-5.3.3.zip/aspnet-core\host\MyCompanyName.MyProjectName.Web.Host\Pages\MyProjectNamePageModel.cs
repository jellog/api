﻿using MyCompanyName.MyProjectName.Localization;
using DataGap.Jellog.AspNetCore.Mvc.UI.RazorPages;

namespace MyCompanyName.MyProjectName.Pages;

public abstract class MyProjectNamePageModel : JellogPageModel
{
    protected MyProjectNamePageModel()
    {
        LocalizationResourceType = typeof(MyProjectNameResource);
    }
}
