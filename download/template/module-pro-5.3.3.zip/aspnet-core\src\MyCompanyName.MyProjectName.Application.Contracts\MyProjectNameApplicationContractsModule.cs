﻿using DataGap.Jellog.Application;
using DataGap.Jellog.Authorization;
using DataGap.Jellog.Modularity;

namespace MyCompanyName.MyProjectName;

[DependsOn(
    typeof(MyProjectNameDomainSharedModule),
    typeof(JellogDddApplicationContractsModule),
    typeof(JellogAuthorizationAbstractionsModule)
    )]
public class MyProjectNameApplicationContractsModule : JellogModule
{

}
