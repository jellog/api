import { Environment } from '@jellog/ng.core';

const baseUrl = 'http://localhost:4200';

const oAuthConfig = {
  issuer: 'https://localhost:44301/',
  redirectUri: baseUrl,
  clientId: 'MyProjectName_App',
  responseType: 'code',
  scope: 'offline_access MyProjectName',
  requireHttps: true
};

export const environment = {
  production: false,
  application: {
    baseUrl,
    name: 'MyProjectName',
    logoUrl: '',
  },
  oAuthConfig,
  apis: {
    default: {
      url: 'https://localhost:44301',
      rootNamespace: 'MyCompanyName.MyProjectName',
    },
    JellogAccountPublic: {
      url: oAuthConfig.issuer,
      rootNamespace: 'JellogAccountPublic',
    },
    MyProjectName: {
      url: 'https://localhost:44300',
      rootNamespace: 'MyCompanyName.MyProjectName',
    },
  },
} as Environment;
