export const enum eMyProjectNameRouteNames {
  MyProjectName = 'MyProjectName::Menu:MyProjectName',
}
