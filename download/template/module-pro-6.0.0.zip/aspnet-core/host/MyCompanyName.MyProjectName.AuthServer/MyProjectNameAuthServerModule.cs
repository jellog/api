using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.DataProtection;
using Microsoft.AspNetCore.Extensions.DependencyInjection;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.DependencyInjection.Extensions;
using Microsoft.Extensions.Hosting;
using MyCompanyName.MyProjectName.MultiTenancy;
using StackExchange.Redis;
using Microsoft.OpenApi.Models;
using OpenIddict.Validation.AspNetCore;
using DataGap.Jellog;
using DataGap.Jellog.Account;
using DataGap.Jellog.Account.Admin.Web;
using DataGap.Jellog.Account.Web;
using DataGap.Jellog.AspNetCore.Mvc;
using DataGap.Jellog.AspNetCore.Mvc.UI.MultiTenancy;
using DataGap.Jellog.AspNetCore.Mvc.UI.Theme.Lepton;
using DataGap.Jellog.AspNetCore.Serilog;
using DataGap.Jellog.Auditing;
using DataGap.Jellog.AuditLogging.EntityFrameworkCore;
using DataGap.Jellog.Autofac;
using DataGap.Jellog.BlobStoring.Database.EntityFrameworkCore;
using DataGap.Jellog.Caching;
using DataGap.Jellog.Caching.StackExchangeRedis;
using DataGap.Jellog.Data;
using DataGap.Jellog.Emailing;
using DataGap.Jellog.EntityFrameworkCore;
using DataGap.Jellog.EntityFrameworkCore.SqlServer;
using DataGap.Jellog.FeatureManagement;
using DataGap.Jellog.FeatureManagement.EntityFrameworkCore;
using DataGap.Jellog.Identity;
using DataGap.Jellog.Identity.EntityFrameworkCore;
using DataGap.Jellog.LeptonTheme;
using DataGap.Jellog.LeptonTheme.Management;
using DataGap.Jellog.Localization;
using DataGap.Jellog.Modularity;
using DataGap.Jellog.MultiTenancy;
using DataGap.Jellog.OpenIddict.EntityFrameworkCore;
using DataGap.Jellog.PermissionManagement;
using DataGap.Jellog.PermissionManagement.EntityFrameworkCore;
using DataGap.Jellog.PermissionManagement.HttpApi;
using DataGap.Jellog.PermissionManagement.Identity;
using DataGap.Jellog.SettingManagement;
using DataGap.Jellog.SettingManagement.EntityFrameworkCore;
using DataGap.Jellog.Swashbuckle;
using DataGap.Jellog.Threading;
using DataGap.Jellog.UI.Navigation.Urls;
using DataGap.Saas.EntityFrameworkCore;
using DataGap.Saas.Host;

namespace MyCompanyName.MyProjectName;

[DependsOn(
    typeof(JellogAccountPublicWebOpenIddictModule),
    typeof(JellogAccountPublicApplicationModule),
    typeof(JellogAccountPublicHttpApiModule),
    typeof(JellogAccountAdminWebModule),
    typeof(JellogAccountAdminApplicationModule),
    typeof(JellogAccountAdminHttpApiModule),
    typeof(JellogAspNetCoreMvcUiMultiTenancyModule),
    typeof(JellogAspNetCoreMvcModule),
    typeof(JellogAspNetCoreMvcUiLeptonThemeModule),
    typeof(JellogAuditLoggingEntityFrameworkCoreModule),
    typeof(JellogAutofacModule),
    typeof(JellogCachingStackExchangeRedisModule),
    typeof(JellogEntityFrameworkCoreSqlServerModule),
    typeof(JellogIdentityProEntityFrameworkCoreModule),
    typeof(JellogIdentityApplicationModule),
    typeof(JellogIdentityHttpApiModule),
    typeof(JellogOpenIddictEntityFrameworkCoreModule),
    typeof(LeptonThemeManagementHttpApiModule),
    typeof(LeptonThemeManagementApplicationModule),
    typeof(LeptonThemeManagementDomainModule),
    typeof(JellogPermissionManagementDomainIdentityModule),
    typeof(JellogPermissionManagementEntityFrameworkCoreModule),
    typeof(JellogPermissionManagementApplicationModule),
    typeof(JellogPermissionManagementHttpApiModule),
    typeof(JellogSettingManagementEntityFrameworkCoreModule),
    typeof(JellogSettingManagementApplicationModule),
    typeof(JellogSettingManagementHttpApiModule),
    typeof(JellogSettingManagementEntityFrameworkCoreModule),
    typeof(JellogFeatureManagementHttpApiModule),
    typeof(JellogFeatureManagementApplicationModule),
    typeof(JellogFeatureManagementEntityFrameworkCoreModule),
    typeof(SaasEntityFrameworkCoreModule),
    typeof(SaasHostApplicationModule),
    typeof(SaasHostHttpApiModule),
    typeof(BlobStoringDatabaseEntityFrameworkCoreModule),
    typeof(MyProjectNameApplicationContractsModule),
    typeof(JellogSwashbuckleModule),
    typeof(JellogAspNetCoreSerilogModule)
    )]
public class MyProjectNameAuthServerModule : JellogModule
{
    public override void PreConfigureServices(ServiceConfigurationContext context)
    {
        PreConfigure<OpenIddictBuilder>(builder =>
        {
            builder.AddValidation(options =>
            {
                options.AddAudiences("MyProjectName");
                options.UseLocalServer();
                options.UseAspNetCore();
            });
        });
    }

    public override void ConfigureServices(ServiceConfigurationContext context)
    {
        var hostingEnvironment = context.Services.GetHostingEnvironment();
        var configuration = context.Services.GetConfiguration();

        context.Services.ForwardIdentityAuthenticationForBearer(OpenIddictValidationAspNetCoreDefaults.AuthenticationScheme);

        Configure<JellogDbContextOptions>(options =>
        {
            options.UseSqlServer();
        });

        context.Services.AddJellogSwaggerGenWithOAuth(
            configuration["AuthServer:Authority"],
            new Dictionary<string, string>
            {
                {"MyProjectName", "MyProjectName API"}
            },
            options =>
            {
                options.SwaggerDoc("v1", new OpenApiInfo { Title = "MyProjectName API", Version = "v1" });
                options.DocInclusionPredicate((docName, description) => true);
                options.CustomSchemaIds(type => type.FullName);
            });

        Configure<JellogLocalizationOptions>(options =>
        {
            options.Languages.Add(new LanguageInfo("ar", "ar", "العربية", "ae"));
            options.Languages.Add(new LanguageInfo("cs", "cs", "Čeština", flagIcon: "cz"));
            options.Languages.Add(new LanguageInfo("en", "en", "English", flagIcon: "gb"));
            options.Languages.Add(new LanguageInfo("fi", "fi", "Finnish", "fi"));
            options.Languages.Add(new LanguageInfo("fr", "fr", "Français", "fr"));
            options.Languages.Add(new LanguageInfo("hi", "hi", "Hindi", "in"));
            options.Languages.Add(new LanguageInfo("it", "it", "Italiano", "it"));
            options.Languages.Add(new LanguageInfo("pt-BR", "pt-BR", "Português (Brasil)", flagIcon: "br"));
            options.Languages.Add(new LanguageInfo("ru", "ru", "Русский", "ru"));
            options.Languages.Add(new LanguageInfo("sk", "sk", "Slovak", flagIcon: "sk"));
            options.Languages.Add(new LanguageInfo("sl", "sl", "Slovenščina", "si"));
            options.Languages.Add(new LanguageInfo("tr", "tr", "Türkçe", flagIcon: "tr"));
            options.Languages.Add(new LanguageInfo("zh-Hans", "zh-Hans", "简体中文", flagIcon: "cn"));
            options.Languages.Add(new LanguageInfo("zh-Hant", "zh-Hant", "繁體中文", flagIcon: "tw"));
        });

        Configure<JellogAuditingOptions>(options =>
        {
            //options.IsEnabledForGetRequests = true;
            options.ApplicationName = "AuthServer";
        });

        Configure<JellogMultiTenancyOptions>(options =>
        {
            options.IsEnabled = MultiTenancyConsts.IsEnabled;
        });

        Configure<AppUrlOptions>(options =>
        {
            options.Applications["MVC"].RootUrl = configuration["App:SelfUrl"];
        });

        Configure<JellogDistributedCacheOptions>(options =>
        {
            options.KeyPrefix = "MyProjectName:";
        });

        var dataProtectionBuilder = context.Services.AddDataProtection().SetApplicationName("MyProjectName");
        if (!hostingEnvironment.IsDevelopment())
        {
            var redis = ConnectionMultiplexer.Connect(configuration["Redis:Configuration"]);
            dataProtectionBuilder.PersistKeysToStackExchangeRedis(redis, "MyProjectName-Protection-Keys");
        }

        context.Services.AddCors(options =>
        {
            options.AddDefaultPolicy(builder =>
            {
                builder
                    .WithOrigins(
                        configuration["App:CorsOrigins"]
                            .Split(",", StringSplitOptions.RemoveEmptyEntries)
                            .Select(o => o.RemovePostFix("/"))
                            .ToArray()
                    )
                    .WithJellogExposedHeaders()
                    .SetIsOriginAllowedToAllowWildcardSubdomains()
                    .AllowAnyHeader()
                    .AllowAnyMethod()
                    .AllowCredentials();
            });
        });

#if DEBUG
        context.Services.Replace(ServiceDescriptor.Singleton<IEmailSender, NullEmailSender>());
#endif
    }

    public override void OnApplicationInitialization(ApplicationInitializationContext context)
    {
        var app = context.GetApplicationBuilder();

        if (!context.GetEnvironment().IsDevelopment())
        {
            app.UseHsts();
        }
        app.UseHttpsRedirection();
        app.UseCorrelationId();
        app.UseJellogSecurityHeaders();
        app.UseStaticFiles();
        app.UseRouting();
        app.UseCors();
        app.UseAuthentication();
        app.UseJellogOpenIddictValidation();

        if (MultiTenancyConsts.IsEnabled)
        {
            app.UseMultiTenancy();
        }

        app.UseJellogRequestLocalization();
        app.UseAuthorization();
        app.UseSwagger();
        app.UseJellogSwaggerUI(options =>
        {
            options.SwaggerEndpoint("/swagger/v1/swagger.json", "MyProjectName API");
            options.OAuthClientId(context.GetConfiguration()["AuthServer:SwaggerClientId"]);
        });
        app.UseAuditing();
        app.UseJellogSerilogEnrichers();
        app.UseConfiguredEndpoints();

        SeedData(context);
    }

    private void SeedData(ApplicationInitializationContext context)
    {
        AsyncHelper.RunSync(async () =>
        {
            using (var scope = context.ServiceProvider.CreateScope())
            {
                await scope.ServiceProvider
                    .GetRequiredService<IDataSeeder>()
                    .SeedAsync();
            }
        });
    }
}
