﻿using System.Threading.Tasks;
using DataGap.Jellog.Data;
using DataGap.Jellog.DependencyInjection;
using DataGap.Jellog.MultiTenancy;

namespace MyCompanyName.MyProjectName.Seed;

public class MyProjectNameAuthServerDataSeedContributor : IDataSeedContributor, ITransientDependency
{
    private readonly MyProjectNameSampleIdentityDataSeeder _myProjectNameSampleIdentityDataSeeder;
    private readonly MyProjectNameAuthServerDataSeeder _myProjectNameAuthServerDataSeeder;
    private readonly ICurrentTenant _currentTenant;

    public MyProjectNameAuthServerDataSeedContributor(
        MyProjectNameAuthServerDataSeeder myProjectNameAuthServerDataSeeder,
        MyProjectNameSampleIdentityDataSeeder myProjectNameSampleIdentityDataSeeder,
        ICurrentTenant currentTenant)
    {
        _myProjectNameAuthServerDataSeeder = myProjectNameAuthServerDataSeeder;
        _myProjectNameSampleIdentityDataSeeder = myProjectNameSampleIdentityDataSeeder;
        _currentTenant = currentTenant;
    }

    public async Task SeedAsync(DataSeedContext context)
    {
        using (_currentTenant.Change(context?.TenantId))
        {
            await _myProjectNameSampleIdentityDataSeeder.SeedAsync(context);
            await _myProjectNameAuthServerDataSeeder.SeedAsync(context);
        }
    }
}
