"Updating the database..."
dotnet ef database update
"The database update completed."
Pause