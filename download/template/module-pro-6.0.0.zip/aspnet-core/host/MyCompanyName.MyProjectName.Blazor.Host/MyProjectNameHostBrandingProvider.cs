﻿using DataGap.Jellog.Ui.Branding;

namespace MyCompanyName.MyProjectName.Blazor.Host;

public class MyProjectNameHostBrandingProvider : DefaultBrandingProvider
{
    public override string AppName => "MyProjectName";
}
