﻿namespace MyCompanyName.MyProjectName.Blazor.Server.Host.Pages;

public partial class Index
{

}
