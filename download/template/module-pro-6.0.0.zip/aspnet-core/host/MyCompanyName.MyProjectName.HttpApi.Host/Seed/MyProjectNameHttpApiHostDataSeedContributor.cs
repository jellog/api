﻿using System.Threading.Tasks;
using DataGap.Jellog.Data;
using DataGap.Jellog.DependencyInjection;
using DataGap.Jellog.MultiTenancy;

namespace MyCompanyName.MyProjectName.Seed;

public class MyProjectNameHttpApiHostDataSeedContributor : IDataSeedContributor, ITransientDependency
{
    private readonly MyProjectNameSampleDataSeeder _myProjectNameSampleDataSeeder;
    private readonly ICurrentTenant _currentTenant;

    public MyProjectNameHttpApiHostDataSeedContributor(
        MyProjectNameSampleDataSeeder myProjectNameSampleDataSeeder,
        ICurrentTenant currentTenant)
    {
        _myProjectNameSampleDataSeeder = myProjectNameSampleDataSeeder;
        _currentTenant = currentTenant;
    }

    public async Task SeedAsync(DataSeedContext context)
    {
        using (_currentTenant.Change(context?.TenantId))
        {
            await _myProjectNameSampleDataSeeder.SeedAsync(context);
        }
    }
}
