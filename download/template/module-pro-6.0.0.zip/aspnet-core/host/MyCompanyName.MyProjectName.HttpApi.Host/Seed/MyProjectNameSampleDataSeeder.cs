﻿using System.Threading.Tasks;
using DataGap.Jellog.Data;
using DataGap.Jellog.DependencyInjection;

namespace MyCompanyName.MyProjectName.Seed;

/* You can use this file to seed some sample data
 * to test your module easier.
 *
 * This class is shared among these projects:
 * - MyCompanyName.MyProjectName.AuthServer
 * - MyCompanyName.MyProjectName.Web.Unified (used as linked file)
 */
public class MyProjectNameSampleDataSeeder : ITransientDependency
{
    public async Task SeedAsync(DataSeedContext context)
    {

    }
}
