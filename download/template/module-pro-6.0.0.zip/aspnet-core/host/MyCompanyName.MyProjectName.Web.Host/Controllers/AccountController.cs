﻿using DataGap.Jellog.AspNetCore.Mvc.Authentication;

namespace MyCompanyName.MyProjectName.Controllers;

public class AccountController : ChallengeAccountController
{

}
