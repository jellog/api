using System.IO;
using Microsoft.AspNetCore.Builder;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.DependencyInjection.Extensions;
using Microsoft.Extensions.Hosting;
using MyCompanyName.MyProjectName.EntityFrameworkCore;
using MyCompanyName.MyProjectName.MultiTenancy;
using MyCompanyName.MyProjectName.Web;
using Microsoft.OpenApi.Models;
using DataGap.Jellog;
using DataGap.Jellog.Account;
using DataGap.Jellog.Account.Admin.Web;
using DataGap.Jellog.Account.Public.Web;
using DataGap.Jellog.AspNetCore.Mvc.UI.Theme.Lepton;
using DataGap.Jellog.AspNetCore.Mvc.UI.Theme.Shared;
using DataGap.Jellog.AspNetCore.Serilog;
using DataGap.Jellog.Auditing;
using DataGap.Jellog.AuditLogging;
using DataGap.Jellog.AuditLogging.EntityFrameworkCore;
using DataGap.Jellog.AuditLogging.Web;
using DataGap.Jellog.Autofac;
using DataGap.Jellog.BlobStoring.Database.EntityFrameworkCore;
using DataGap.Jellog.Data;
using DataGap.Jellog.Emailing;
using DataGap.Jellog.EntityFrameworkCore;
using DataGap.Jellog.EntityFrameworkCore.SqlServer;
using DataGap.Jellog.FeatureManagement;
using DataGap.Jellog.FeatureManagement.EntityFrameworkCore;
using DataGap.Jellog.Identity;
using DataGap.Jellog.Identity.EntityFrameworkCore;
using DataGap.Jellog.Identity.Web;
using DataGap.Jellog.LeptonTheme;
using DataGap.Jellog.Localization;
using DataGap.Jellog.Modularity;
using DataGap.Jellog.MultiTenancy;
using DataGap.Jellog.PermissionManagement;
using DataGap.Jellog.PermissionManagement.EntityFrameworkCore;
using DataGap.Jellog.PermissionManagement.Identity;
using DataGap.Jellog.SettingManagement.EntityFrameworkCore;
using DataGap.Jellog.Threading;
using DataGap.Jellog.VirtualFileSystem;
using DataGap.Saas.EntityFrameworkCore;
using DataGap.Saas.Host;
using DataGap.Jellog.LeptonTheme.Management;
using DataGap.Jellog.SettingManagement;
using DataGap.Jellog.Swashbuckle;

namespace MyCompanyName.MyProjectName;

[DependsOn(
    typeof(MyProjectNameWebModule),
    typeof(MyProjectNameApplicationModule),
    typeof(MyProjectNameHttpApiModule),
    typeof(MyProjectNameEntityFrameworkCoreModule),
    typeof(JellogAuditLoggingWebModule),
    typeof(JellogAuditLoggingHttpApiModule),
    typeof(JellogAuditLoggingApplicationModule),
    typeof(JellogAuditLoggingEntityFrameworkCoreModule),
    typeof(JellogAutofacModule),
    typeof(JellogAccountPublicWebModule),
    typeof(JellogAccountPublicApplicationModule),
    typeof(JellogAccountPublicHttpApiModule),
    typeof(JellogAccountAdminWebModule),
    typeof(JellogAccountAdminApplicationModule),
    typeof(JellogAccountAdminHttpApiModule),
    typeof(JellogEntityFrameworkCoreSqlServerModule),
    typeof(JellogSettingManagementHttpApiModule),
    typeof(JellogSettingManagementEntityFrameworkCoreModule),
    typeof(JellogSettingManagementApplicationModule),
    typeof(JellogPermissionManagementEntityFrameworkCoreModule),
    typeof(JellogPermissionManagementApplicationModule),
    typeof(JellogIdentityWebModule),
    typeof(JellogIdentityApplicationModule),
    typeof(JellogIdentityHttpApiModule),
    typeof(JellogIdentityProEntityFrameworkCoreModule),
    typeof(JellogPermissionManagementDomainIdentityModule),
    typeof(LeptonThemeManagementWebModule),
    typeof(LeptonThemeManagementApplicationModule),
    typeof(LeptonThemeManagementHttpApiModule),
    typeof(LeptonThemeManagementDomainModule),
    typeof(JellogFeatureManagementWebModule),
    typeof(JellogFeatureManagementApplicationModule),
    typeof(JellogFeatureManagementHttpApiModule),
    typeof(JellogFeatureManagementEntityFrameworkCoreModule),
    typeof(SaasHostWebModule),
    typeof(SaasHostApplicationModule),
    typeof(SaasHostHttpApiModule),
    typeof(SaasEntityFrameworkCoreModule),
    typeof(JellogAspNetCoreMvcUiLeptonThemeModule),
    typeof(BlobStoringDatabaseEntityFrameworkCoreModule),
    typeof(JellogSwashbuckleModule),
    typeof(JellogAspNetCoreSerilogModule)
    )]
public class MyProjectNameWebUnifiedModule : JellogModule
{
    public override void ConfigureServices(ServiceConfigurationContext context)
    {
        var hostingEnvironment = context.Services.GetHostingEnvironment();
        var configuration = context.Services.GetConfiguration();

        Configure<JellogDbContextOptions>(options =>
        {
            options.UseSqlServer();
        });

        if (hostingEnvironment.IsDevelopment())
        {
            Configure<JellogVirtualFileSystemOptions>(options =>
            {
                options.FileSets.ReplaceEmbeddedByPhysical<MyProjectNameDomainSharedModule>(Path.Combine(hostingEnvironment.ContentRootPath, string.Format("..{0}..{0}src{0}MyCompanyName.MyProjectName.Domain.Shared", Path.DirectorySeparatorChar)));
                options.FileSets.ReplaceEmbeddedByPhysical<MyProjectNameDomainModule>(Path.Combine(hostingEnvironment.ContentRootPath, string.Format("..{0}..{0}src{0}MyCompanyName.MyProjectName.Domain", Path.DirectorySeparatorChar)));
                options.FileSets.ReplaceEmbeddedByPhysical<MyProjectNameApplicationContractsModule>(Path.Combine(hostingEnvironment.ContentRootPath, string.Format("..{0}..{0}src{0}MyCompanyName.MyProjectName.Application.Contracts", Path.DirectorySeparatorChar)));
                options.FileSets.ReplaceEmbeddedByPhysical<MyProjectNameApplicationModule>(Path.Combine(hostingEnvironment.ContentRootPath, string.Format("..{0}..{0}src{0}MyCompanyName.MyProjectName.Application", Path.DirectorySeparatorChar)));
                options.FileSets.ReplaceEmbeddedByPhysical<MyProjectNameWebModule>(Path.Combine(hostingEnvironment.ContentRootPath, string.Format("..{0}..{0}src{0}MyCompanyName.MyProjectName.Web", Path.DirectorySeparatorChar)));
            });
        }

        context.Services.AddJellogSwaggerGen(
            options =>
            {
                options.SwaggerDoc("v1", new OpenApiInfo { Title = "MyProjectName API", Version = "v1" });
                options.DocInclusionPredicate((docName, description) => true);
                options.CustomSchemaIds(type => type.FullName);
            });

        Configure<JellogLocalizationOptions>(options =>
        {
            options.Languages.Add(new LanguageInfo("ar", "ar", "العربية", "ae"));
            options.Languages.Add(new LanguageInfo("cs", "cs", "Čeština", flagIcon: "cz"));
            options.Languages.Add(new LanguageInfo("en", "en", "English", flagIcon: "gb"));
            options.Languages.Add(new LanguageInfo("fi", "fi", "Finnish", "fi"));
            options.Languages.Add(new LanguageInfo("fr", "fr", "Français", "fr"));
            options.Languages.Add(new LanguageInfo("hi", "hi", "Hindi", "in"));
            options.Languages.Add(new LanguageInfo("it", "it", "Italiano", "it"));
            options.Languages.Add(new LanguageInfo("pt-BR", "pt-BR", "Português (Brasil)", flagIcon: "br"));
            options.Languages.Add(new LanguageInfo("ru", "ru", "Русский", "ru"));
            options.Languages.Add(new LanguageInfo("sk", "sk", "Slovak", flagIcon: "sk"));
            options.Languages.Add(new LanguageInfo("sl", "sl", "Slovenščina", "si"));
            options.Languages.Add(new LanguageInfo("tr", "tr", "Türkçe", flagIcon: "tr"));
            options.Languages.Add(new LanguageInfo("zh-Hans", "zh-Hans", "简体中文", flagIcon: "cn"));
            options.Languages.Add(new LanguageInfo("zh-Hant", "zh-Hant", "繁體中文", flagIcon: "tw"));
            options.Languages.Add(new LanguageInfo("es", "es", "Español", "es"));
        });

        Configure<JellogMultiTenancyOptions>(options =>
        {
            options.IsEnabled = MultiTenancyConsts.IsEnabled;
        });

#if DEBUG
        context.Services.Replace(ServiceDescriptor.Singleton<IEmailSender, NullEmailSender>());
#endif
    }

    public override void OnApplicationInitialization(ApplicationInitializationContext context)
    {
        var app = context.GetApplicationBuilder();

        if (context.GetEnvironment().IsDevelopment())
        {
            app.UseDeveloperExceptionPage();
        }
        else
        {
            app.UseErrorPage();
            app.UseHsts();
        }

        app.UseHttpsRedirection();
        app.UseJellogSecurityHeaders();
        app.UseStaticFiles();
        app.UseRouting();
        app.UseAuthentication();

        if (MultiTenancyConsts.IsEnabled)
        {
            app.UseMultiTenancy();
        }

        app.UseJellogRequestLocalization();
        app.UseAuthorization();

        app.UseSwagger();
        app.UseJellogSwaggerUI(options =>
        {
            options.SwaggerEndpoint("/swagger/v1/swagger.json", "MyProjectName API");
        });

        app.UseAuditing();
        app.UseJellogSerilogEnrichers();

        app.UseConfiguredEndpoints();

        SeedData(context);
    }

    private void SeedData(ApplicationInitializationContext context)
    {
        AsyncHelper.RunSync(async () =>
        {
            using (var scope = context.ServiceProvider.CreateScope())
            {
                await scope.ServiceProvider
                    .GetRequiredService<IDataSeeder>()
                    .SeedAsync();
            }
        });
    }
}
