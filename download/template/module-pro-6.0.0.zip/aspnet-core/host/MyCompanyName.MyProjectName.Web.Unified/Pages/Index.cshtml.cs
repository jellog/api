using Microsoft.AspNetCore.Mvc.RazorPages;

namespace MyCompanyName.MyProjectName.Pages;

public class IndexModel : PageModel
{
    public void OnGet()
    {
    }
}
