﻿namespace MyCompanyName.MyProjectName.Samples;

public class SampleDto
{
    public int Value { get; set; }
}
