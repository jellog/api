﻿using Microsoft.Extensions.DependencyInjection;
using DataGap.Jellog.Application;
using DataGap.Jellog.AutoMapper;
using DataGap.Jellog.Modularity;

namespace MyCompanyName.MyProjectName;

[DependsOn(
    typeof(MyProjectNameDomainModule),
    typeof(MyProjectNameApplicationContractsModule),
    typeof(JellogDddApplicationModule),
    typeof(JellogAutoMapperModule)
    )]
public class MyProjectNameApplicationModule : JellogModule
{
    public override void ConfigureServices(ServiceConfigurationContext context)
    {
        context.Services.AddAutoMapperObjectMapper<MyProjectNameApplicationModule>();
        Configure<JellogAutoMapperOptions>(options =>
        {
            options.AddMaps<MyProjectNameApplicationModule>(validate: true);
        });
    }
}
