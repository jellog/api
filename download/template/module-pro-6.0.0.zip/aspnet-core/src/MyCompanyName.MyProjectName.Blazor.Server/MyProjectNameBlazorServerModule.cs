﻿using DataGap.Jellog.AspNetCore.Components.Server.Theming;
using DataGap.Jellog.Modularity;

namespace MyCompanyName.MyProjectName.Blazor.Server;

[DependsOn(
    typeof(MyProjectNameBlazorModule),
    typeof(JellogAspNetCoreComponentsServerThemingModule)
    )]
public class MyProjectNameBlazorServerModule : JellogModule
{

}
