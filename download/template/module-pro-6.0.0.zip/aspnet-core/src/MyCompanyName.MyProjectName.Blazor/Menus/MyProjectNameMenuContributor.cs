﻿using System.Threading.Tasks;
using MyCompanyName.MyProjectName.Localization;
using DataGap.Jellog.UI.Navigation;

namespace MyCompanyName.MyProjectName.Blazor.Menus;

public class MyProjectNameMenuContributor : IMenuContributor
{
    public async Task ConfigureMenuAsync(MenuConfigurationContext context)
    {
        if (context.Menu.Name == StandardMenus.Main)
        {
            await ConfigureMainMenuAsync(context);
        }
    }

    private static async Task ConfigureMainMenuAsync(MenuConfigurationContext context)
    {
        //Add main menu items.
        var l = context.GetLocalizer<MyProjectNameResource>();

        context.Menu.AddItem(new ApplicationMenuItem(MyProjectNameMenus.Prefix, displayName: "Sample Page", "/MyProjectName", icon: "fa fa-globe"));

        await Task.CompletedTask;
    }
}
