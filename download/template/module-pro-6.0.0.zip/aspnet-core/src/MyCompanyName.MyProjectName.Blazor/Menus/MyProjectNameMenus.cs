﻿namespace MyCompanyName.MyProjectName.Blazor.Menus;

public class MyProjectNameMenus
{
    public const string Prefix = "MyProjectName";

    //Add your menu items here...
    //public const string Home = Prefix + ".MyNewMenuItem";

}
