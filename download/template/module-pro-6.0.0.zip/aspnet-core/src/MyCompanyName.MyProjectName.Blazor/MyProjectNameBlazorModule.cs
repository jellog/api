﻿using Microsoft.Extensions.DependencyInjection;
using MyCompanyName.MyProjectName.Blazor.Menus;
using DataGap.Jellog.AspNetCore.Components.Web.Theming;
using DataGap.Jellog.AspNetCore.Components.Web.Theming.Routing;
using DataGap.Jellog.AutoMapper;
using DataGap.Jellog.Modularity;
using DataGap.Jellog.UI.Navigation;

namespace MyCompanyName.MyProjectName.Blazor;

[DependsOn(
    typeof(MyProjectNameApplicationContractsModule),
    typeof(JellogAspNetCoreComponentsWebThemingModule),
    typeof(JellogAutoMapperModule)
    )]
public class MyProjectNameBlazorModule : JellogModule
{
    public override void ConfigureServices(ServiceConfigurationContext context)
    {
        context.Services.AddAutoMapperObjectMapper<MyProjectNameBlazorModule>();

        Configure<JellogAutoMapperOptions>(options =>
        {
            options.AddProfile<MyProjectNameBlazorAutoMapperProfile>(validate: true);
        });

        Configure<JellogNavigationOptions>(options =>
        {
            options.MenuContributors.Add(new MyProjectNameMenuContributor());
        });

        Configure<JellogRouterOptions>(options =>
        {
            options.AdditionalAssemblies.Add(typeof(MyProjectNameBlazorModule).Assembly);
        });
    }
}
