﻿using DataGap.Jellog.Modularity;
using DataGap.Jellog.Localization;
using MyCompanyName.MyProjectName.Localization;
using DataGap.Jellog.Localization.ExceptionHandling;
using DataGap.Jellog.Validation;
using DataGap.Jellog.Validation.Localization;
using DataGap.Jellog.VirtualFileSystem;

namespace MyCompanyName.MyProjectName;

[DependsOn(
    typeof(JellogValidationModule)
)]
public class MyProjectNameDomainSharedModule : JellogModule
{
    public override void ConfigureServices(ServiceConfigurationContext context)
    {
        Configure<JellogVirtualFileSystemOptions>(options =>
        {
            options.FileSets.AddEmbedded<MyProjectNameDomainSharedModule>();
        });

        Configure<JellogLocalizationOptions>(options =>
        {
            options.Resources
                .Add<MyProjectNameResource>("en")
                .AddBaseTypes(typeof(JellogValidationResource))
                .AddVirtualJson("/Localization/MyProjectName");
        });

        Configure<JellogExceptionLocalizationOptions>(options =>
        {
            options.MapCodeNamespace("MyProjectName", typeof(MyProjectNameResource));
        });
    }
}
