﻿namespace MyCompanyName.MyProjectName;

public static class MyProjectNameDbProperties
{
    public static string DbTablePrefix { get; set; } = "MyProjectName";

    public static string DbSchema { get; set; } = null;

    public const string ConnectionStringName = "MyProjectName";
}
