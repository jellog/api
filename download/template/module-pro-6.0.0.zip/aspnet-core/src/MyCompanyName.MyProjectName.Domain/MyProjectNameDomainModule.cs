﻿using DataGap.Jellog.Domain;
using DataGap.Jellog.Modularity;

namespace MyCompanyName.MyProjectName;

[DependsOn(
    typeof(JellogDddDomainModule),
    typeof(MyProjectNameDomainSharedModule)
)]
public class MyProjectNameDomainModule : JellogModule
{

}
