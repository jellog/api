﻿using DataGap.Jellog.Data;
using DataGap.Jellog.MongoDB;

namespace MyCompanyName.MyProjectName.MongoDB;

[ConnectionStringName(MyProjectNameDbProperties.ConnectionStringName)]
public class MyProjectNameMongoDbContext : JellogMongoDbContext, IMyProjectNameMongoDbContext
{
    /* Add mongo collections here. Example:
     * public IMongoCollection<Question> Questions => Collection<Question>();
     */

    protected override void CreateModel(IMongoModelBuilder modelBuilder)
    {
        base.CreateModel(modelBuilder);

        modelBuilder.ConfigureMyProjectName();
    }
}
