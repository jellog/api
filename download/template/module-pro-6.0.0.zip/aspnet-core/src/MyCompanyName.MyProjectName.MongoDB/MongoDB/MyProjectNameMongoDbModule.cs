﻿using Microsoft.Extensions.DependencyInjection;
using DataGap.Jellog.Modularity;
using DataGap.Jellog.MongoDB;

namespace MyCompanyName.MyProjectName.MongoDB;

[DependsOn(
    typeof(MyProjectNameDomainModule),
    typeof(JellogMongoDbModule)
    )]
public class MyProjectNameMongoDbModule : JellogModule
{
    public override void ConfigureServices(ServiceConfigurationContext context)
    {
        context.Services.AddMongoDbContext<MyProjectNameMongoDbContext>(options =>
        {
                /* Add custom repositories here. Example:
                 * options.AddRepository<Question, MongoQuestionRepository>();
                 */
        });
    }
}
