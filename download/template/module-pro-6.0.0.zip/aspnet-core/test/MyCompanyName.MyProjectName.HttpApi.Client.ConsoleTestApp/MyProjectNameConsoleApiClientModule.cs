﻿using DataGap.Jellog.Autofac;
using DataGap.Jellog.Http.Client.IdentityModel;
using DataGap.Jellog.Modularity;

namespace MyCompanyName.MyProjectName;

[DependsOn(
    typeof(JellogAutofacModule),
    typeof(MyProjectNameHttpApiClientModule),
    typeof(JellogHttpClientIdentityModelModule)
    )]
public class MyProjectNameConsoleApiClientModule : JellogModule
{

}
