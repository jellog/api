﻿using Microsoft.Extensions.DependencyInjection;
using DataGap.Jellog.Autofac;
using DataGap.Jellog.Modularity;

namespace MyCompanyName.MyProjectName;

[DependsOn(typeof(JellogAutofacModule))]
public class MyProjectNameModule : JellogModule
{
    public override void ConfigureServices(ServiceConfigurationContext context)
    {
        context.Services.AddSingleton<MainWindow>();
    }
}
